
import React, { useState, useEffect, Suspense, lazy } from 'react';
import { Helmet } from 'react-helmet-async';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/supabaseClient';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import { Search } from 'lucide-react';
import ErrorBoundary from '@/components/ErrorBoundary';
import { SystemMonitorProvider } from '@/contexts/SystemMonitorContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';

// Core Components
import Sidebar from '@/components/Sidebar';
import AuthModal from '@/components/AuthModal';
import SmartSearch from '@/components/SmartSearch';
import BottomNav from '@/components/BottomNav';
import InstallPrompt from '@/components/InstallPrompt';

// Lazy Loaded Components
const LocationSelector = lazy(() => import('@/components/LocationSelector'));
const RestaurantList = lazy(() => import('@/components/RestaurantList'));
const Cart = lazy(() => import('@/components/Cart'));
const RestaurantDashboard = lazy(() => import('@/components/RestaurantDashboard'));
const DeliveryDashboard = lazy(() => import('@/components/DeliveryDashboard'));
const CashierDashboard = lazy(() => import('@/components/CashierDashboard'));
const UmrahBooking = lazy(() => import('@/components/UmrahBooking'));
const CarMarketplace = lazy(() => import('@/components/CarMarketplace'));
const AdminDashboard = lazy(() => import('@/components/AdminDashboard'));
const CustomerDashboard = lazy(() => import('@/components/CustomerDashboard'));
const SupportDashboard = lazy(() => import('@/components/SupportDashboard'));
const AllPostsFeed = lazy(() => import('@/components/AllPostsFeed'));
const SettingsPage = lazy(() => import('@/components/SettingsPage'));

const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-[50vh]">
    <div className="relative w-16 h-16">
      <div className="absolute top-0 left-0 w-full h-full border-4 border-indigo-200 rounded-full"></div>
      <div className="absolute top-0 left-0 w-full h-full border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
    </div>
  </div>
);

function App() {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  
  // Auth from Context
  const { session, signOut } = useAuth();
  
  // State
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');
  
  const [currentSection, setCurrentSection] = useState('feed'); 
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  
  // Data State
  const [cart, setCart] = useState(() => {
    try { return JSON.parse(localStorage.getItem('fastpost-cart')) || []; } catch { return []; }
  });
  const [orders, setOrders] = useState([]);
  const [userLocation, setUserLocation] = useState(localStorage.getItem('fastpost-location') || null);
  const [isLocationSelectorOpen, setIsLocationSelectorOpen] = useState(!userLocation);

  // Handle User Profile Fetching & Role Persistence via Realtime
  useEffect(() => {
    let channel;

    const fetchUserProfile = async () => {
      if (!session?.user) {
        setCurrentUser(null);
        setUserRole('customer');
        if (['dashboard', 'profile', 'settings'].includes(currentSection)) {
            setCurrentSection('feed');
        }
        return;
      }

      try {
        const { data, error } = await supabase.from('users').select('*').eq('id', session.user.id).single();
        
        if (error) {
            console.error("Error fetching user profile:", error);
            return;
        }
        
        if (data) {
          // If deleted (soft delete), force logout
          if (data.deleted_at) {
              await signOut();
              toast({ variant: "destructive", title: "Account Deactivated", description: "This account has been deleted." });
              return;
          }

          setCurrentUser(data);
          setUserRole(data.role || 'customer');
          
          if (data.language && i18n.language !== data.language) {
              i18n.changeLanguage(data.language);
              document.dir = ['ar', 'ur', 'ckb', 'fa'].includes(data.language) ? 'rtl' : 'ltr';
          }
          
          // Role-based Redirect Logic on First Load
          if (['admin', 'restaurant_owner', 'umrah_company', 'driver', 'support'].includes(data.role) && currentSection === 'feed') {
             setCurrentSection('dashboard');
          } else if (data.role === 'car_dealer' && currentSection === 'feed') {
             setCurrentSection('dashboard');
          }

          // Setup Realtime Listener for Role Changes (Role Persistence)
          channel = supabase.channel(`public:users:${data.id}`)
            .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'users', filter: `id=eq.${data.id}` }, (payload) => {
                const updatedUser = payload.new;
                if (updatedUser.deleted_at) {
                    signOut();
                    toast({ variant: "destructive", title: "Session Ended", description: "Your account has been deactivated." });
                } else {
                    setCurrentUser(prev => ({ ...prev, ...updatedUser }));
                    if (updatedUser.role !== userRole) {
                        setUserRole(updatedUser.role);
                        toast({ title: "Role Updated", description: `Your role has been updated to ${updatedUser.role}` });
                    }
                }
            })
            .subscribe();
        }
      } catch (err) {
        console.error("Unexpected error fetching profile:", err);
      }
    };

    fetchUserProfile();

    return () => {
        if (channel) supabase.removeChannel(channel);
    };
  }, [session, i18n, signOut]);

  // Cart Logic
  useEffect(() => { localStorage.setItem('fastpost-cart', JSON.stringify(cart)); }, [cart]);
  const addToCart = (item, restaurant, selectedOptions = []) => {
      setCart(prev => [...prev, { ...item, restaurantId: restaurant.id, totalPrice: item.price }]);
      toast({ title: t('added_to_cart'), description: item.name });
  };

  // Routing Logic
  const renderMainContent = () => {
     if (userRole === 'admin') {
        if (currentSection === 'dashboard') return <AdminDashboard user={currentUser} activeSection="overview" />;
        if (['feed', 'food', 'cars', 'umrah'].includes(currentSection)) {
            // fall through
        } else {
            return <AdminDashboard user={currentUser} activeSection={currentSection} />;
        }
     }

     if (userRole === 'support') {
       if (currentSection === 'dashboard' || currentSection === 'tickets') {
          return <SupportDashboard user={currentUser} activeSection={currentSection === 'dashboard' ? 'tickets' : currentSection} />;
       }
     }

     if (userRole === 'restaurant_owner') {
        if (['dashboard', 'orders', 'menu', 'settings'].includes(currentSection)) {
            return <RestaurantDashboard user={currentUser} activeTab={currentSection === 'dashboard' ? 'overview' : currentSection} orders={orders} setOrders={setOrders} addToCart={addToCart} />;
        }
     }

     if (userRole === 'umrah_company') {
        if (currentSection === 'dashboard' || currentSection === 'trips' || currentSection === 'finance' || currentSection === 'guides') {
             return <UmrahBooking view="dashboard" user={currentUser} />;
        }
     }
     
     if (userRole === 'car_dealer') {
         if (currentSection === 'dashboard' || currentSection === 'inventory' || currentSection === 'sales') {
            return <CarMarketplace view="dashboard" user={currentUser} />;
         }
     }

     if (userRole === 'driver') {
         if (currentSection === 'dashboard' || currentSection === 'earnings' || currentSection === 'history') {
             return <DeliveryDashboard user={currentUser} activeTab={currentSection === 'dashboard' ? 'overview' : currentSection} />;
         }
     }

     if (userRole === 'cashier') return <CashierDashboard user={currentUser} />;
     
     switch(currentSection) {
        case 'feed': return <AllPostsFeed addToCart={addToCart} isAuthenticated={!!session} />;
        case 'food': return <RestaurantList userLocation={userLocation} addToCart={addToCart} />;
        case 'orders': return <CustomerDashboard user={currentUser} orders={orders} activeTab="orders" />;
        case 'favorites': return <CustomerDashboard user={currentUser} orders={orders} activeTab="favorites" />;
        case 'wallet': return <CustomerDashboard user={currentUser} orders={orders} activeTab="wallet" />;
        case 'umrah': return <UmrahBooking view="customer" user={currentUser} />;
        case 'cars': return <CarMarketplace view="customer" user={currentUser} />;
        case 'profile': return <SettingsPage user={currentUser} />;
        case 'settings': return <SettingsPage user={currentUser} />;
        default: return <AllPostsFeed addToCart={addToCart} isAuthenticated={!!session} />;
     }
  };

  const isDesktop = typeof window !== 'undefined' && window.innerWidth > 768;

  return (
    <ErrorBoundary>
      <SystemMonitorProvider>
        <div className={`min-h-screen bg-slate-50 dark:bg-slate-950 font-sans transition-colors duration-300 ${isSidebarOpen && isDesktop ? (document.dir === 'rtl' ? 'mr-64' : 'ml-64') : (isDesktop ? (document.dir === 'rtl' ? 'mr-20' : 'ml-20') : '')}`}>
          <Helmet>
            <title>{t('app_name')}</title>
            <meta name="theme-color" content="#4F46E5" />
          </Helmet>

          <div className="hidden md:block">
             <Sidebar 
                userRole={userRole} 
                activeSection={currentSection} 
                onNavigate={setCurrentSection}
                isOpen={isSidebarOpen}
                user={currentUser}
             />
          </div>

          <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 h-16 flex items-center justify-between shadow-sm">
             <div className="flex items-center gap-4">
                 <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="hidden md:flex text-slate-500">
                    {document.dir === 'rtl' ? (isSidebarOpen ? '→' : '←') : (isSidebarOpen ? '←' : '→')}
                 </Button>
                 <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-emerald-500 capitalize">
                    {t(currentSection === 'feed' ? 'app_name' : currentSection)}
                 </h1>
             </div>

             <div className="flex items-center gap-3">
                 <Button 
                    variant="outline" 
                    className="hidden md:flex gap-2 text-slate-500 w-64 justify-start bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                    onClick={() => setIsSearchOpen(true)}
                 >
                    <Search className="w-4 h-4" />
                    <span className="text-xs">{t('search_placeholder')}</span>
                 </Button>
                 
                 {!session && (
                    <Button onClick={() => setIsAuthModalOpen(true)} size="sm" className="btn-primary">
                       {t('login')}
                    </Button>
                 )}
             </div>
          </header>

          <main className="p-4 md:p-8 pb-24 md:pb-8 max-w-7xl mx-auto">
             <Suspense fallback={<LoadingFallback />}>
                <AnimatePresence mode="wait">
                   <motion.div
                     key={currentSection}
                     initial={{ opacity: 0, y: 10 }}
                     animate={{ opacity: 1, y: 0 }}
                     exit={{ opacity: 0, y: -10 }}
                     transition={{ duration: 0.2 }}
                   >
                      {renderMainContent()}
                   </motion.div>
                </AnimatePresence>
             </Suspense>
          </main>

          <div className="md:hidden">
             <BottomNav 
                currentSection={currentSection} 
                setCurrentSection={setCurrentSection} 
                userRole={userRole}
                cartCount={cart.length} 
             />
          </div>

          <SmartSearch 
            isOpen={isSearchOpen} 
            onClose={() => setIsSearchOpen(false)} 
            onSearch={(q) => {
              // Search logic handled by component
            }} 
          />
          <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
          <LocationSelector isOpen={isLocationSelectorOpen} onSelect={(city) => { setUserLocation(city); setIsLocationSelectorOpen(false); localStorage.setItem('fastpost-location', city); }} cities={['Baghdad', 'Basra', 'Erbil']} />
          <Toaster />
          <InstallPrompt />
        </div>
      </SystemMonitorProvider>
    </ErrorBoundary>
  );
}

export default App;
