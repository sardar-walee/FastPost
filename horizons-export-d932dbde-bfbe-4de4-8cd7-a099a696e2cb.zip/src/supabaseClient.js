
import { customSupabaseClient } from '@/lib/customSupabaseClient';

export const supabase = customSupabaseClient;
