
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Edit, Trash2, Image as ImageIcon, Search, Filter, Upload, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const MenuManager = ({ restaurantId }) => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const { toast } = useToast();
  
  // Modal State
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  
  const [formData, setFormData] = useState({
    name: '', price: '', description: '', category: 'Main', 
    image_url: '', preparation_time: 15, is_available: true
  });

  useEffect(() => {
    fetchItems();
  }, [restaurantId]);

  const fetchItems = async () => {
    const { data } = await supabase.from('menu_items').select('*').eq('restaurant_id', restaurantId).order('name');
    if (data) setItems(data);
    setLoading(false);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB Limit
         toast({ variant: 'destructive', title: 'File too large', description: 'Image must be under 2MB' });
         return;
      }
      setSelectedFile(file);
      const objectUrl = URL.createObjectURL(file);
      setImagePreview(objectUrl);
    }
  };

  const uploadImage = async () => {
      if (!selectedFile) return formData.image_url;
      setIsUploading(true);
      try {
          const fileExt = selectedFile.name.split('.').pop();
          const fileName = `${restaurantId}/${Date.now()}.${fileExt}`;
          const { error: uploadError } = await supabase.storage.from('menu-items').upload(fileName, selectedFile);
          
          if (uploadError) throw uploadError;
          
          const { data: { publicUrl } } = supabase.storage.from('menu-items').getPublicUrl(fileName);
          return publicUrl;
      } catch (error) {
          toast({ variant: 'destructive', title: 'Upload Failed', description: error.message });
          return null;
      } finally {
          setIsUploading(false);
      }
  };

  const handleSave = async () => {
    if (!formData.name || !formData.price) {
        toast({ variant: 'destructive', title: 'Error', description: 'Name and Price are required' });
        return;
    }

    let imageUrl = formData.image_url;
    if (selectedFile) {
        const uploadedUrl = await uploadImage();
        if (!uploadedUrl) return; // Stop if upload failed
        imageUrl = uploadedUrl;
    }

    const payload = {
        ...formData,
        image_url: imageUrl,
        restaurant_id: restaurantId,
        price: parseFloat(formData.price)
    };

    let error;
    if (editingItem) {
        const { error: err } = await supabase.from('menu_items').update(payload).eq('id', editingItem.id);
        error = err;
    } else {
        const { error: err } = await supabase.from('menu_items').insert([payload]);
        error = err;
    }

    if (error) {
        toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else {
        toast({ title: 'Success', description: 'Menu item saved successfully' });
        setIsDialogOpen(false);
        fetchItems();
    }
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;
    const { error } = await supabase.from('menu_items').delete().eq('id', itemToDelete);
    if (!error) {
        toast({ title: 'Deleted', description: 'Item removed from menu' });
        fetchItems();
    }
    setDeleteConfirmOpen(false);
    setItemToDelete(null);
  };

  const openDeleteDialog = (id) => {
    setItemToDelete(id);
    setDeleteConfirmOpen(true);
  };

  const openDialog = (item = null) => {
    setEditingItem(item);
    setSelectedFile(null);
    if (item) {
        setFormData({
            name: item.name, price: item.price, description: item.description || '', 
            category: item.category || 'Main', image_url: item.image_url || '',
            preparation_time: item.preparation_time || 15, is_available: item.is_available
        });
        setImagePreview(item.image_url);
    } else {
        setFormData({
            name: '', price: '', description: '', category: 'Main', 
            image_url: '', preparation_time: 15, is_available: true
        });
        setImagePreview(null);
    }
    setIsDialogOpen(true);
  };

  const filteredItems = items.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));

  // Mobile List Item Component
  const MobileMenuItem = ({ item }) => (
    <div className="bg-white p-4 rounded-xl border shadow-sm mb-3 flex flex-col gap-3">
        <div className="flex gap-3">
            <div className="w-16 h-16 rounded-lg bg-slate-100 flex-shrink-0 overflow-hidden">
                {item.image_url ? 
                    <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" /> : 
                    <ImageIcon className="w-6 h-6 m-auto mt-5 text-slate-300" />
                }
            </div>
            <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start">
                    <h4 className="font-bold text-slate-900 truncate pr-2">{item.name}</h4>
                    <span className="font-bold text-emerald-600 whitespace-nowrap">
                        {new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(item.price)}
                    </span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-[10px] h-5 px-1.5">{item.category}</Badge>
                    <Badge variant={item.is_available ? 'default' : 'secondary'} className={`text-[10px] h-5 px-1.5 ${item.is_available ? 'bg-emerald-500' : ''}`}>
                        {item.is_available ? 'Avail' : 'Sold Out'}
                    </Badge>
                </div>
            </div>
        </div>
        <div className="flex gap-2 pt-2 border-t border-slate-100">
             <Button variant="outline" size="sm" className="flex-1 h-8 text-xs" onClick={() => openDialog(item)}>Edit</Button>
             <Button variant="outline" size="sm" className="h-8 w-10 text-red-500 hover:text-red-600 hover:bg-red-50" onClick={() => openDeleteDialog(item.id)}>
                 <Trash2 className="w-4 h-4" />
             </Button>
        </div>
    </div>
  );

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
       <div className="flex flex-col md:flex-row justify-between md:items-center gap-3 bg-white p-4 rounded-xl border shadow-sm sticky top-0 z-10 md:static">
          <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <Input placeholder="Search menu..." className="pl-9 bg-slate-50 border-slate-200" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Button onClick={() => openDialog()} className="bg-emerald-600 hover:bg-emerald-700 w-full md:w-auto shadow-lg shadow-emerald-200">
              <Plus className="w-4 h-4 mr-2" /> Add New Dish
          </Button>
       </div>

       {/* Desktop View */}
       <div className="hidden md:block bg-white rounded-xl border shadow-sm overflow-hidden">
          <Table>
             <TableHeader>
                <TableRow>
                   <TableHead>Image</TableHead>
                   <TableHead>Name</TableHead>
                   <TableHead>Category</TableHead>
                   <TableHead>Price</TableHead>
                   <TableHead>Status</TableHead>
                   <TableHead className="text-right">Actions</TableHead>
                </TableRow>
             </TableHeader>
             <TableBody>
                {filteredItems.map(item => (
                   <TableRow key={item.id}>
                      <TableCell>
                         <div className="w-12 h-12 rounded-lg bg-slate-100 overflow-hidden">
                            {item.image_url ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" /> : <ImageIcon className="w-6 h-6 m-auto mt-3 text-slate-300" />}
                         </div>
                      </TableCell>
                      <TableCell className="font-medium">
                         {item.name}
                         <p className="text-xs text-slate-500 line-clamp-1">{item.description}</p>
                      </TableCell>
                      <TableCell><Badge variant="outline">{item.category}</Badge></TableCell>
                      <TableCell>{new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(item.price)}</TableCell>
                      <TableCell>
                         <Badge variant={item.is_available ? 'default' : 'secondary'} className={item.is_available ? 'bg-emerald-500' : ''}>
                            {item.is_available ? 'Available' : 'Sold Out'}
                         </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                         <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="icon" onClick={() => openDialog(item)}><Edit className="w-4 h-4 text-slate-500" /></Button>
                            <Button variant="ghost" size="icon" onClick={() => openDeleteDialog(item.id)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                         </div>
                      </TableCell>
                   </TableRow>
                ))}
                {filteredItems.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-8 text-slate-500">No items found.</TableCell></TableRow>}
             </TableBody>
          </Table>
       </div>

       {/* Mobile View */}
       <div className="md:hidden space-y-3 pb-20">
            {filteredItems.map(item => <MobileMenuItem key={item.id} item={item} />)}
            {filteredItems.length === 0 && <div className="text-center py-12 text-slate-500 bg-white rounded-xl border border-dashed">No items found</div>}
       </div>

       <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-lg w-[95vw] rounded-2xl p-4 md:p-6 overflow-y-auto max-h-[90vh]">
             <DialogHeader><DialogTitle>{editingItem ? 'Edit Item' : 'Add New Dish'}</DialogTitle></DialogHeader>
             <div className="grid gap-4 py-4">
                {/* Image Upload */}
                <div className="col-span-1 md:col-span-2">
                    <Label className="mb-2 block">Dish Image</Label>
                    <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 flex flex-col items-center justify-center bg-slate-50 relative group cursor-pointer h-48">
                        {imagePreview ? (
                            <>
                                <img src={imagePreview} alt="Preview" className="w-full h-full object-contain rounded-lg" />
                                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                                    <span className="text-white text-sm font-medium">Click to change</span>
                                </div>
                            </>
                        ) : (
                            <div className="text-center">
                                <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                                <p className="text-sm text-slate-500">Click to upload image</p>
                                <p className="text-xs text-slate-400 mt-1">PNG, JPG up to 2MB</p>
                            </div>
                        )}
                        <input type="file" accept="image/*" onChange={handleImageChange} className="absolute inset-0 opacity-0 cursor-pointer" />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="space-y-2">
                      <Label>Name</Label>
                      <Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Dish Name" className="h-10 text-base" />
                   </div>
                   <div className="space-y-2">
                      <Label>Price (IQD)</Label>
                      <Input type="number" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} placeholder="0" className="h-10 text-base" />
                   </div>
                </div>
                <div className="space-y-2">
                   <Label>Category</Label>
                   <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                      <SelectTrigger className="h-10 text-base"><SelectValue /></SelectTrigger>
                      <SelectContent>
                         {['Main', 'Appetizer', 'Dessert', 'Drink', 'Side'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                      </SelectContent>
                   </Select>
                </div>
                <div className="space-y-2">
                   <Label>Description</Label>
                   <Input value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Ingredients, taste..." className="h-10 text-base" />
                </div>
                
                <div className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border">
                   <Label className="cursor-pointer" onClick={() => setFormData(prev => ({...prev, is_available: !prev.is_available}))}>Available for Order</Label>
                   <Switch checked={formData.is_available} onCheckedChange={c => setFormData({...formData, is_available: c})} />
                </div>
             </div>
             <DialogFooter className="flex-col gap-2 sm:flex-row">
                <Button variant="outline" className="w-full sm:w-auto h-12 md:h-10" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleSave} disabled={isUploading} className="w-full sm:w-auto h-12 md:h-10">
                    {isUploading ? 'Uploading...' : 'Save Item'}
                </Button>
             </DialogFooter>
          </DialogContent>
       </Dialog>

       <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <AlertDialogContent className="w-[90vw] max-w-md rounded-2xl">
             <AlertDialogHeader>
                <AlertDialogTitle>Delete Menu Item</AlertDialogTitle>
                <AlertDialogDescription>
                   Are you sure you want to delete this item? This action cannot be undone.
                </AlertDialogDescription>
             </AlertDialogHeader>
             <div className="flex justify-end gap-3 mt-4">
                <AlertDialogCancel className="h-10">Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteConfirm} className="bg-red-600 hover:bg-red-700 h-10">Delete</AlertDialogAction>
             </div>
          </AlertDialogContent>
       </AlertDialog>
    </div>
  );
};

export default MenuManager;
