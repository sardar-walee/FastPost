
import React, { useState } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { MapPin, Navigation } from 'lucide-react';
import IraqMap from '@/components/ui/IraqMap';

const SettingsManager = ({ restaurant, onUpdate }) => {
  const [formData, setFormData] = useState({ ...restaurant });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSave = async () => {
    setLoading(true);
    const { error } = await supabase.from('restaurants').update(formData).eq('id', restaurant.id);
    setLoading(false);
    if (error) {
       toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else {
       toast({ title: 'Success', description: 'Settings updated successfully.' });
       onUpdate();
    }
  };

  const handleGetCurrentLocation = () => {
    if (navigator.geolocation) {
      setLoading(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData(prev => ({
            ...prev,
            lat: position.coords.latitude,
            lng: position.coords.longitude
          }));
          setLoading(false);
          toast({ title: "Location Found", description: "Coordinates updated to your current location." });
        },
        (error) => {
          setLoading(false);
          toast({ variant: "destructive", title: "Location Error", description: error.message });
        }
      );
    } else {
      toast({ variant: "destructive", title: "Error", description: "Geolocation is not supported by this browser." });
    }
  };

  return (
    <div className="space-y-6 max-w-4xl animate-in fade-in duration-500">
       <Card>
          <CardHeader><CardTitle>General Information</CardTitle></CardHeader>
          <CardContent className="space-y-4">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Restaurant Name</Label><Input value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} /></div>
                <div className="space-y-2"><Label>Phone Number</Label><Input value={formData.phone || ''} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="+964..." /></div>
             </div>
             <div className="space-y-2"><Label>Address</Label><Input value={formData.location || ''} onChange={e => setFormData({...formData, location: e.target.value})} /></div>
             <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border">
                <div className="space-y-0.5">
                    <Label className="text-base">Online Status</Label>
                    <p className="text-xs text-slate-500">Toggle to open/close your restaurant for orders</p>
                </div>
                <Switch checked={formData.is_online} onCheckedChange={c => setFormData({...formData, is_online: c})} />
             </div>
          </CardContent>
       </Card>

       <Card>
          <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Location & Delivery</CardTitle>
              <Button variant="outline" size="sm" onClick={handleGetCurrentLocation} disabled={loading}>
                  <Navigation className="w-4 h-4 mr-2" /> Get Current Location
              </Button>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="h-72 rounded-xl overflow-hidden border shadow-inner relative">
                <IraqMap 
                   center={[formData.lat || 33.3152, formData.lng || 44.3661]} 
                   zoom={13}
                   markers={[{ id: 'rest', lat: formData.lat || 33.3152, lng: formData.lng || 44.3661, type: 'restaurant', title: 'Your Restaurant' }]}
                   serviceRadius={(formData.service_radius_km || 5) * 1000}
                />
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Latitude</Label><Input type="number" value={formData.lat || ''} onChange={e => setFormData({...formData, lat: parseFloat(e.target.value)})} /></div>
                <div className="space-y-2"><Label>Longitude</Label><Input type="number" value={formData.lng || ''} onChange={e => setFormData({...formData, lng: parseFloat(e.target.value)})} /></div>
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Service Radius (KM)</Label><Input type="number" value={formData.service_radius_km || 5} onChange={e => setFormData({...formData, service_radius_km: e.target.value})} /></div>
                <div className="space-y-2"><Label>Delivery Fee per KM (IQD)</Label><Input type="number" value={formData.delivery_fee_per_km || 500} onChange={e => setFormData({...formData, delivery_fee_per_km: e.target.value})} /></div>
             </div>
          </CardContent>
       </Card>

       <div className="flex justify-end pb-10">
          <Button size="lg" onClick={handleSave} disabled={loading} className="bg-emerald-600 hover:bg-emerald-700">
              {loading ? 'Saving...' : 'Save Changes'}
          </Button>
       </div>
    </div>
  );
};

export default SettingsManager;
