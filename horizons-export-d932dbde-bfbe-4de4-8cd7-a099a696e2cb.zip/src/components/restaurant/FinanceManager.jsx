
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { DollarSign, TrendingUp, TrendingDown, Wallet, Calendar, Plus, Download, ArrowUpRight } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const FinanceManager = ({ restaurantId }) => {
  const [expenses, setExpenses] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [restaurant, setRestaurant] = useState(null);
  
  // Modal States
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);
  
  // Forms
  const [expenseForm, setExpenseForm] = useState({ category: 'supplies', amount: '', description: '', date: new Date().toISOString().split('T')[0] });
  const [withdrawalForm, setWithdrawalForm] = useState({ amount: '', bank_info: '' });
  
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
  }, [restaurantId]);

  const fetchData = async () => {
    setLoading(true);
    // Fetch Restaurant Wallet
    const { data: restData } = await supabase.from('restaurants').select('wallet_balance, name').eq('id', restaurantId).single();
    setRestaurant(restData);

    // Fetch Expenses
    const { data: expData } = await supabase.from('expenses').select('*').eq('restaurant_id', restaurantId).order('date', { ascending: false });
    setExpenses(expData || []);

    // Fetch Withdrawals
    const { data: withData } = await supabase.from('withdrawals').select('*').eq('restaurant_id', restaurantId).order('created_at', { ascending: false });
    setWithdrawals(withData || []);
    
    setLoading(false);
  };

  const handleAddExpense = async () => {
    if (!expenseForm.amount || !expenseForm.category) {
       toast({ variant: 'destructive', title: 'Error', description: 'Please fill required fields' });
       return;
    }
    
    const { error } = await supabase.from('expenses').insert([{
        restaurant_id: restaurantId,
        ...expenseForm,
        status: 'approved'
    }]);

    if (error) {
        toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else {
        toast({ title: 'Success', description: 'Expense recorded' });
        setIsExpenseModalOpen(false);
        fetchData();
        setExpenseForm({ category: 'supplies', amount: '', description: '', date: new Date().toISOString().split('T')[0] });
    }
  };

  const handleWithdrawal = async () => {
    if (!withdrawalForm.amount || parseFloat(withdrawalForm.amount) <= 0) {
        toast({ variant: 'destructive', title: 'Invalid Amount', description: 'Please enter a valid amount.' });
        return;
    }
    
    if (parseFloat(withdrawalForm.amount) > (restaurant?.wallet_balance || 0)) {
        toast({ variant: 'destructive', title: 'Insufficient Funds', description: 'Withdrawal amount exceeds balance.' });
        return;
    }

    const { error } = await supabase.from('withdrawals').insert([{
        restaurant_id: restaurantId,
        amount: parseFloat(withdrawalForm.amount),
        bank_info: { account: withdrawalForm.bank_info },
        status: 'pending'
    }]);

    if (error) {
        toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else {
        toast({ title: 'Request Sent', description: 'Withdrawal request submitted for approval.' });
        setIsWithdrawalModalOpen(false);
        fetchData();
        setWithdrawalForm({ amount: '', bank_info: '' });
    }
  };

  const calculateTotals = () => {
     const totalExpenses = expenses.reduce((sum, exp) => sum + Number(exp.amount), 0);
     const totalWithdrawn = withdrawals.filter(w => w.status === 'completed').reduce((sum, w) => sum + Number(w.amount), 0);
     const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending').reduce((sum, w) => sum + Number(w.amount), 0);
     return { totalExpenses, totalWithdrawn, pendingWithdrawals };
  };

  const { totalExpenses, totalWithdrawn, pendingWithdrawals } = calculateTotals();
  const balance = restaurant?.wallet_balance || 0;
  const formatCurrency = (val) => new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(val);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white border-0 shadow-lg">
             <CardContent className="p-6">
                 <div className="flex justify-between items-start">
                     <div>
                         <p className="text-indigo-100 text-sm font-medium">Available Balance</p>
                         <h3 className="text-3xl font-bold mt-2">{formatCurrency(balance)}</h3>
                     </div>
                     <Wallet className="w-10 h-10 text-white/20" />
                 </div>
                 <Button 
                    onClick={() => setIsWithdrawalModalOpen(true)} 
                    className="mt-6 w-full bg-white/20 hover:bg-white/30 text-white border-0"
                 >
                    Request Withdrawal
                 </Button>
             </CardContent>
          </Card>
          
          <Card>
             <CardContent className="p-6">
                 <div className="flex justify-between items-start">
                     <div>
                         <p className="text-slate-500 text-sm font-medium">Total Expenses</p>
                         <h3 className="text-3xl font-bold mt-2 text-slate-800">{formatCurrency(totalExpenses)}</h3>
                     </div>
                     <div className="p-2 bg-red-100 rounded-lg"><TrendingDown className="w-6 h-6 text-red-600" /></div>
                 </div>
                 <div className="mt-6 text-xs text-slate-400">Recorded this month</div>
             </CardContent>
          </Card>

          <Card>
             <CardContent className="p-6">
                 <div className="flex justify-between items-start">
                     <div>
                         <p className="text-slate-500 text-sm font-medium">Pending Withdrawals</p>
                         <h3 className="text-3xl font-bold mt-2 text-slate-800">{formatCurrency(pendingWithdrawals)}</h3>
                     </div>
                     <div className="p-2 bg-amber-100 rounded-lg"><ArrowUpRight className="w-6 h-6 text-amber-600" /></div>
                 </div>
                 <div className="mt-6 text-xs text-slate-400">Processing requests</div>
             </CardContent>
          </Card>
       </div>

       <Tabs defaultValue="expenses" className="w-full">
          <div className="flex items-center justify-between mb-4">
             <TabsList>
                <TabsTrigger value="expenses">Expenses</TabsTrigger>
                <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
             </TabsList>
             <div className="flex gap-2">
                 <Button variant="outline" size="sm" onClick={() => toast({ title: "Exporting...", description: "CSV download started" })}><Download className="w-4 h-4 mr-2"/> Export</Button>
                 <Button onClick={() => setIsExpenseModalOpen(true)} size="sm" className="bg-emerald-600 hover:bg-emerald-700"><Plus className="w-4 h-4 mr-2"/> Add Expense</Button>
             </div>
          </div>

          <TabsContent value="expenses" className="mt-0">
             <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
                <Table>
                   <TableHeader>
                      <TableRow><TableHead>Date</TableHead><TableHead>Category</TableHead><TableHead>Description</TableHead><TableHead className="text-right">Amount</TableHead></TableRow>
                   </TableHeader>
                   <TableBody>
                      {expenses.map(exp => (
                         <TableRow key={exp.id}>
                            <TableCell>{new Date(exp.date).toLocaleDateString()}</TableCell>
                            <TableCell><span className="capitalize px-2 py-1 bg-slate-100 rounded text-xs font-medium text-slate-600">{exp.category}</span></TableCell>
                            <TableCell className="max-w-[200px] truncate" title={exp.description}>{exp.description || '-'}</TableCell>
                            <TableCell className="text-right font-medium text-red-600">-{formatCurrency(exp.amount)}</TableCell>
                         </TableRow>
                      ))}
                      {expenses.length === 0 && <TableRow><TableCell colSpan={4} className="text-center py-8 text-slate-400">No expenses recorded.</TableCell></TableRow>}
                   </TableBody>
                </Table>
             </div>
          </TabsContent>

          <TabsContent value="withdrawals" className="mt-0">
             <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
                <Table>
                   <TableHeader>
                      <TableRow><TableHead>Date Requested</TableHead><TableHead>Status</TableHead><TableHead>Bank Info</TableHead><TableHead className="text-right">Amount</TableHead></TableRow>
                   </TableHeader>
                   <TableBody>
                      {withdrawals.map(w => (
                         <TableRow key={w.id}>
                            <TableCell>{new Date(w.created_at).toLocaleDateString()}</TableCell>
                            <TableCell>
                                <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                                    w.status === 'completed' ? 'bg-green-100 text-green-700' : 
                                    w.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                                }`}>
                                    {w.status}
                                </span>
                            </TableCell>
                            <TableCell className="text-sm text-slate-500">{w.bank_info?.account || 'N/A'}</TableCell>
                            <TableCell className="text-right font-bold">{formatCurrency(w.amount)}</TableCell>
                         </TableRow>
                      ))}
                      {withdrawals.length === 0 && <TableRow><TableCell colSpan={4} className="text-center py-8 text-slate-400">No withdrawal history.</TableCell></TableRow>}
                   </TableBody>
                </Table>
             </div>
          </TabsContent>
       </Tabs>

       {/* Add Expense Modal */}
       <Dialog open={isExpenseModalOpen} onOpenChange={setIsExpenseModalOpen}>
          <DialogContent>
             <DialogHeader><DialogTitle>Record New Expense</DialogTitle></DialogHeader>
             <div className="space-y-4 py-4">
                 <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-2">
                         <Label>Amount (IQD)</Label>
                         <Input type="number" value={expenseForm.amount} onChange={e => setExpenseForm({...expenseForm, amount: e.target.value})} placeholder="0.00" />
                     </div>
                     <div className="space-y-2">
                         <Label>Date</Label>
                         <Input type="date" value={expenseForm.date} onChange={e => setExpenseForm({...expenseForm, date: e.target.value})} />
                     </div>
                 </div>
                 <div className="space-y-2">
                     <Label>Category</Label>
                     <Select value={expenseForm.category} onValueChange={v => setExpenseForm({...expenseForm, category: v})}>
                        <SelectTrigger><SelectValue/></SelectTrigger>
                        <SelectContent>
                           <SelectItem value="supplies">Supplies & Ingredients</SelectItem>
                           <SelectItem value="utilities">Utilities (Water/Elec)</SelectItem>
                           <SelectItem value="rent">Rent</SelectItem>
                           <SelectItem value="salaries">Staff Salaries</SelectItem>
                           <SelectItem value="marketing">Marketing</SelectItem>
                           <SelectItem value="maintenance">Maintenance</SelectItem>
                           <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                     </Select>
                 </div>
                 <div className="space-y-2">
                     <Label>Description</Label>
                     <Input value={expenseForm.description} onChange={e => setExpenseForm({...expenseForm, description: e.target.value})} placeholder="Details about expense" />
                 </div>
             </div>
             <DialogFooter><Button onClick={handleAddExpense}>Save Expense</Button></DialogFooter>
          </DialogContent>
       </Dialog>

       {/* Withdrawal Modal */}
       <Dialog open={isWithdrawalModalOpen} onOpenChange={setIsWithdrawalModalOpen}>
          <DialogContent>
             <DialogHeader><DialogTitle>Request Withdrawal</DialogTitle></DialogHeader>
             <div className="space-y-4 py-4">
                 <div className="p-4 bg-slate-50 rounded-lg text-sm text-slate-600 mb-2">
                     Current Balance: <span className="font-bold text-indigo-600">{formatCurrency(balance)}</span>
                 </div>
                 <div className="space-y-2">
                     <Label>Amount to Withdraw</Label>
                     <Input type="number" value={withdrawalForm.amount} onChange={e => setWithdrawalForm({...withdrawalForm, amount: e.target.value})} placeholder="Minimum 25,000 IQD" />
                 </div>
                 <div className="space-y-2">
                     <Label>Bank Account / Wallet Info</Label>
                     <Input value={withdrawalForm.bank_info} onChange={e => setWithdrawalForm({...withdrawalForm, bank_info: e.target.value})} placeholder="IBAN or Wallet Number" />
                 </div>
             </div>
             <DialogFooter>
                 <Button variant="outline" onClick={() => setIsWithdrawalModalOpen(false)}>Cancel</Button>
                 <Button onClick={handleWithdrawal} disabled={!withdrawalForm.amount || parseFloat(withdrawalForm.amount) > balance}>Submit Request</Button>
             </DialogFooter>
          </DialogContent>
       </Dialog>
    </div>
  );
};

export default FinanceManager;
