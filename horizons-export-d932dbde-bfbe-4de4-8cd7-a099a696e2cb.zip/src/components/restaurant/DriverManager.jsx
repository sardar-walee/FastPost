
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { 
  User, CheckCircle, XCircle, Truck, Phone, Star, MapPin, Search, AlertTriangle
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';

const DriverManager = ({ restaurantId }) => {
  const [activeDrivers, setActiveDrivers] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    if (restaurantId) {
        fetchData();
        
        // Realtime subscription for requests
        const sub = supabase.channel(`driver-manager-${restaurantId}`)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'driver_requests', filter: `restaurant_id=eq.${restaurantId}` }, () => {
                fetchData();
            })
            .subscribe();
            
        return () => sub.unsubscribe();
    }
  }, [restaurantId]);

  const fetchData = async () => {
    // 1. Fetch Active Drivers
    // Fixed: Nested query to fetch driver_profiles through users table
    const { data: active, error } = await supabase
        .from('restaurant_drivers')
        .select(`
            *,
            users:driver_id (
                full_name,
                phone,
                email,
                avatar_url,
                driver_profiles (
                    vehicle_model,
                    is_online,
                    rating
                )
            )
        `)
        .eq('restaurant_id', restaurantId)
        .eq('status', 'active');
    
    if (error) {
        console.error("Error fetching drivers:", error);
        toast({ variant: "destructive", title: "Error fetching drivers", description: error.message });
    }

    const formattedActive = active?.map(a => {
        // Handle potential array or single object for driver_profiles depending on relationship cardinality
        const profile = Array.isArray(a.users?.driver_profiles) 
            ? a.users?.driver_profiles[0] 
            : a.users?.driver_profiles;

        return {
            id: a.driver_id,
            relation_id: a.id,
            name: a.users?.full_name,
            phone: a.users?.phone,
            vehicle: profile?.vehicle_model || 'Unknown',
            online: profile?.is_online,
            rating: profile?.rating,
            deliveries: a.total_deliveries_for_restaurant
        };
    }) || [];
    setActiveDrivers(formattedActive);

    // 2. Fetch Pending Requests
    const { data: requests } = await supabase
        .from('driver_requests')
        .select('*, users:driver_id(full_name, phone, email)')
        .eq('restaurant_id', restaurantId)
        .eq('status', 'pending');
    setPendingRequests(requests || []);
  };

  const handleApprove = async (requestId) => {
    // Call the Postgres function we created
    const { error } = await supabase.rpc('approve_driver_request', { request_id: requestId });
    
    if (error) {
        toast({ variant: "destructive", title: "Error", description: error.message });
    } else {
        toast({ title: "Driver Approved", description: "Driver has been added to your fleet." });
        fetchData();
    }
  };

  const handleReject = async (requestId) => {
    const { error } = await supabase.from('driver_requests').update({ status: 'rejected' }).eq('id', requestId);
    if (!error) {
        toast({ title: "Request Rejected", description: "Driver notified." });
        fetchData();
    }
  };

  const removeDriver = async (relationId) => {
    const { error } = await supabase.from('restaurant_drivers').update({ status: 'suspended' }).eq('id', relationId);
    if (!error) {
        toast({ title: "Driver Removed", description: "Driver access suspended." });
        fetchData();
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
       <div className="flex justify-between items-center">
          <div>
              <h2 className="text-xl font-bold">Fleet Management</h2>
              <p className="text-sm text-slate-500">Manage your external delivery drivers.</p>
          </div>
          <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                  {activeDrivers.length} Active Drivers
              </Badge>
          </div>
       </div>

       <Tabs defaultValue="active" className="w-full">
           <TabsList className="w-full md:w-auto bg-slate-100 p-1 mb-4">
               <TabsTrigger value="active" className="px-6">Active Fleet</TabsTrigger>
               <TabsTrigger value="requests" className="px-6 flex items-center gap-2">
                   Requests 
                   {pendingRequests.length > 0 && <span className="bg-red-500 text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full">{pendingRequests.length}</span>}
               </TabsTrigger>
           </TabsList>

           <TabsContent value="active" className="space-y-4">
               <div className="flex gap-2 mb-4">
                   <div className="relative flex-1 max-w-sm">
                       <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                       <Input placeholder="Search drivers..." className="pl-9" />
                   </div>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                   {activeDrivers.map(driver => (
                       <Card key={driver.id} className="overflow-hidden">
                           <div className={`h-2 w-full ${driver.online ? 'bg-emerald-500' : 'bg-slate-200'}`} />
                           <CardContent className="p-4 space-y-3">
                               <div className="flex justify-between items-start">
                                   <div className="flex items-center gap-3">
                                       <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center">
                                           <User className="w-5 h-5 text-slate-600"/>
                                       </div>
                                       <div>
                                           <h4 className="font-bold text-sm">{driver.name}</h4>
                                           <p className="text-xs text-slate-500">{driver.vehicle}</p>
                                       </div>
                                   </div>
                                   <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded text-amber-700 text-xs font-bold">
                                       <Star className="w-3 h-3 fill-amber-700" /> {driver.rating || 5.0}
                                   </div>
                               </div>
                               
                               <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 bg-slate-50 p-2 rounded">
                                   <div className="flex items-center gap-2">
                                       <Phone className="w-3 h-3 text-slate-400"/> {driver.phone || 'No Phone'}
                                   </div>
                                   <div className="flex items-center gap-2">
                                       <Truck className="w-3 h-3 text-slate-400"/> {driver.deliveries || 0} Trips
                                   </div>
                               </div>

                               <div className="flex gap-2 pt-2">
                                   <Button variant="outline" size="sm" className="flex-1 text-xs">View History</Button>
                                   <Button variant="ghost" size="sm" onClick={() => removeDriver(driver.relation_id)} className="text-red-500 hover:text-red-700 hover:bg-red-50 h-8 w-8 p-0">
                                       <XCircle className="w-4 h-4"/>
                                   </Button>
                               </div>
                           </CardContent>
                       </Card>
                   ))}
                   {activeDrivers.length === 0 && (
                       <div className="col-span-full py-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed">
                           <Truck className="w-12 h-12 mx-auto opacity-20 mb-2"/>
                           <p>No active drivers found.</p>
                       </div>
                   )}
               </div>
           </TabsContent>

           <TabsContent value="requests" className="space-y-4">
               {pendingRequests.map(req => (
                   <Card key={req.id} className="hover:border-indigo-300 transition-colors">
                       <CardContent className="p-4 flex flex-col md:flex-row justify-between items-center gap-4">
                           <div className="flex items-center gap-4">
                               <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600">
                                   <User className="w-6 h-6"/>
                               </div>
                               <div>
                                   <h4 className="font-bold">{req.users?.full_name}</h4>
                                   <p className="text-sm text-slate-500">Wants to join your fleet</p>
                                   <div className="flex items-center gap-4 mt-1 text-xs text-slate-400">
                                       <span className="flex items-center gap-1"><Phone className="w-3 h-3"/> {req.users?.phone}</span>
                                       <span>Applied: {new Date(req.created_at).toLocaleDateString()}</span>
                                   </div>
                               </div>
                           </div>
                           <div className="flex gap-2 w-full md:w-auto">
                               <Button onClick={() => handleApprove(req.id)} className="bg-emerald-600 hover:bg-emerald-700 flex-1 md:flex-none">
                                   <CheckCircle className="w-4 h-4 mr-2"/> Approve
                               </Button>
                               <Button onClick={() => handleReject(req.id)} variant="outline" className="text-red-500 hover:bg-red-50 hover:text-red-600 flex-1 md:flex-none">
                                   <XCircle className="w-4 h-4 mr-2"/> Reject
                               </Button>
                           </div>
                       </CardContent>
                   </Card>
               ))}
               {pendingRequests.length === 0 && (
                   <div className="text-center py-12 text-slate-400 bg-slate-50 rounded-xl border border-dashed">
                       <CheckCircle className="w-12 h-12 mx-auto opacity-20 mb-2"/>
                       <p>No pending requests.</p>
                   </div>
               )}
           </TabsContent>
       </Tabs>
    </div>
  );
};

export default DriverManager;
