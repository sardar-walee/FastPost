
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Ticket, Plus, Tag, Calendar, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';

const MarketingManager = ({ restaurantId }) => {
  const [promotions, setPromotions] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({ title: '', discount_value: '', discount_type: 'percentage', description: '' });
  const { toast } = useToast();

  useEffect(() => {
    fetchPromotions();
  }, [restaurantId]);

  const fetchPromotions = async () => {
    const { data } = await supabase.from('promotions').select('*').eq('restaurant_id', restaurantId);
    if (data) setPromotions(data);
  };

  const handleSave = async () => {
    if (!formData.title || !formData.discount_value) return;
    const payload = { ...formData, restaurant_id: restaurantId };
    
    const { error } = await supabase.from('promotions').insert([payload]);
    if (!error) {
        toast({ title: 'Success', description: 'Promotion created.' });
        setIsDialogOpen(false);
        fetchPromotions();
    }
  };

  const handleDelete = async (id) => {
      await supabase.from('promotions').delete().eq('id', id);
      fetchPromotions();
  };

  return (
    <div className="space-y-6">
       <div className="flex justify-between items-center">
          <div><h2 className="text-2xl font-bold">Marketing Campaigns</h2><p className="text-slate-500">Manage discounts and offers</p></div>
          <Button onClick={() => { setFormData({ title: '', discount_value: '', discount_type: 'percentage', description: '' }); setIsDialogOpen(true); }} className="bg-purple-600"><Plus className="w-4 h-4 mr-2"/> New Promotion</Button>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {promotions.map(promo => (
             <Card key={promo.id} className="border-l-4 border-l-purple-500 hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2 flex flex-row justify-between items-start">
                   <CardTitle className="text-lg font-bold">{promo.title}</CardTitle>
                   <Button variant="ghost" size="icon" className="h-6 w-6 text-red-400" onClick={() => handleDelete(promo.id)}><Trash2 className="w-3 h-3"/></Button>
                </CardHeader>
                <CardContent>
                   <p className="text-slate-500 text-sm mb-4">{promo.description || 'No description'}</p>
                   <div className="flex items-center justify-between">
                       <span className="bg-purple-100 text-purple-700 font-bold px-3 py-1 rounded-full text-sm">
                           {promo.discount_value}{promo.discount_type === 'percentage' ? '%' : ' IQD'} OFF
                       </span>
                       <span className="text-xs text-slate-400 flex items-center gap-1"><Calendar className="w-3 h-3"/> Active</span>
                   </div>
                </CardContent>
             </Card>
          ))}
          {promotions.length === 0 && <div className="col-span-full py-12 text-center text-slate-400">No active promotions.</div>}
       </div>

       <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
             <DialogHeader><DialogTitle>Create Promotion</DialogTitle></DialogHeader>
             <div className="space-y-4 py-4">
                <div className="space-y-2"><Label>Title</Label><Input value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="e.g. Summer Sale" /></div>
                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2"><Label>Discount Value</Label><Input type="number" value={formData.discount_value} onChange={e => setFormData({...formData, discount_value: e.target.value})} /></div>
                   <div className="space-y-2"><Label>Type</Label>
                       <select className="w-full h-10 border rounded-md px-3 text-sm" value={formData.discount_type} onChange={e => setFormData({...formData, discount_type: e.target.value})}>
                          <option value="percentage">Percentage (%)</option>
                          <option value="fixed">Fixed Amount</option>
                       </select>
                   </div>
                </div>
                <div className="space-y-2"><Label>Description</Label><Input value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} /></div>
             </div>
             <DialogFooter><Button onClick={handleSave}>Launch Campaign</Button></DialogFooter>
          </DialogContent>
       </Dialog>
    </div>
  );
};

export default MarketingManager;
