
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { MapPin, Phone, Clock, Package, Navigation, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import IraqMap from '@/components/ui/IraqMap';
import { generateRoute } from '@/lib/locationUtils';

const OrderManager = ({ restaurantId }) => {
  const [orders, setOrders] = useState([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [route, setRoute] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchOrders();
    const sub = supabase.channel('orders_realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `restaurant_id=eq.${restaurantId}` }, () => {
          fetchOrders();
      })
      .subscribe();
    return () => sub.unsubscribe();
  }, [restaurantId]);

  useEffect(() => {
    if (selectedOrder) {
        // Calculate route for visualization
        const start = [selectedOrder.restaurant_lat || 33.3152, selectedOrder.restaurant_lng || 44.3661];
        const end = [selectedOrder.customer_lat || 33.3152, selectedOrder.customer_lng || 44.3661];
        setRoute(generateRoute(start, end));
    } else {
        setRoute(null);
    }
  }, [selectedOrder]);

  const fetchOrders = async () => {
    // Explicitly specify the relationship for users to avoid PGRST201 error
    const { data } = await supabase
      .from('orders')
      .select('*, users:users!orders_user_id_fkey(full_name, phone)')
      .eq('restaurant_id', restaurantId)
      .order('created_at', { ascending: false });
    if (data) setOrders(data);
  };

  const updateStatus = async (id, status) => {
    const { error } = await supabase.from('orders').update({ status }).eq('id', id);
    if (!error) {
        toast({ title: 'Status Updated', description: `Order marked as ${status}` });
        if (selectedOrder?.id === id) {
             // Keep modal open but update local state to reflect change immediately
             setSelectedOrder(prev => ({...prev, status}));
             // Also close modal if delivered/cancelled to clear view if desired, but typically better to keep open for confirmation
        }
        fetchOrders();
    }
  };

  const filteredOrders = orders.filter(o => statusFilter === 'all' ? true : o.status === statusFilter);

  const getStatusColor = (status) => {
     switch(status) {
         case 'pending': return 'bg-amber-500';
         case 'confirmed': return 'bg-blue-500';
         case 'preparing': return 'bg-indigo-500';
         case 'ready': return 'bg-purple-500';
         case 'delivering': return 'bg-orange-500';
         case 'delivered': return 'bg-emerald-500';
         case 'cancelled': return 'bg-red-500';
         default: return 'bg-slate-500';
     }
  };

  return (
    <div className="space-y-4 md:space-y-6 animate-in fade-in duration-500">
       <div className="bg-white p-2 rounded-xl border shadow-sm sticky top-0 z-10 overflow-hidden">
         <div className="flex overflow-x-auto scrollbar-hide -mx-2 px-2">
            <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-full">
               <TabsList className="h-10 w-full md:w-auto bg-slate-100 justify-start md:justify-center p-1">
                  {['all', 'pending', 'confirmed', 'preparing', 'ready', 'delivering', 'delivered'].map(s => (
                     <TabsTrigger key={s} value={s} className="capitalize px-3 py-1.5 text-xs md:text-sm min-w-fit">{s}</TabsTrigger>
                  ))}
               </TabsList>
            </Tabs>
         </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 pb-20">
          {filteredOrders.map(order => (
             <Card key={order.id} className="hover:shadow-md transition-all cursor-pointer border-l-4 border-l-indigo-500 active:scale-[0.98]" onClick={() => setSelectedOrder(order)}>
                <CardContent className="p-4 space-y-3">
                   <div className="flex justify-between items-start">
                      <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                      <span className="text-xs text-slate-500 font-medium">{new Date(order.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                   </div>
                   <div>
                      <h4 className="font-bold text-slate-800 text-lg">Order #{order.id.slice(0,6)}</h4>
                      <p className="text-sm text-slate-600 flex items-center gap-1"><Phone className="w-3 h-3 text-slate-400"/> {order.users?.full_name || 'Guest User'}</p>
                   </div>
                   <div className="flex justify-between items-center text-sm pt-3 border-t border-slate-100 mt-1">
                      <span className="text-slate-500 bg-slate-100 px-2 py-0.5 rounded text-xs font-medium">{order.items?.length || 0} Items</span>
                      <span className="font-bold text-emerald-600 text-base">{new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(order.total_price)}</span>
                   </div>
                </CardContent>
             </Card>
          ))}
          {filteredOrders.length === 0 && <div className="col-span-full text-center py-16 text-slate-400 bg-slate-50/50 rounded-xl border border-dashed flex flex-col items-center justify-center">
             <Package className="w-12 h-12 opacity-20 mb-2"/>
             <p>No orders found in this category.</p>
          </div>}
       </div>

       <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
          <DialogContent className="max-w-3xl w-[95vw] h-[90vh] md:h-auto md:max-h-[90vh] p-0 overflow-hidden flex flex-col rounded-2xl">
             <DialogHeader className="p-4 border-b flex flex-row items-center justify-between bg-slate-50">
                <div>
                   <DialogTitle className="text-lg font-bold flex items-center gap-2">
                      Order #{selectedOrder?.id.slice(0,6)}
                   </DialogTitle>
                   <p className="text-xs text-slate-500 mt-1">{selectedOrder && new Date(selectedOrder.created_at).toLocaleString()}</p>
                </div>
                <div className="flex items-center gap-2">
                   {selectedOrder && <Badge className={getStatusColor(selectedOrder.status)}>{selectedOrder.status}</Badge>}
                   <DialogClose asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full"><X className="w-4 h-4"/></Button>
                   </DialogClose>
                </div>
             </DialogHeader>
             
             {selectedOrder && (
                 <div className="flex-1 overflow-y-auto p-4 bg-slate-50/50">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            {/* Order Items */}
                            <div className="bg-white p-4 rounded-xl shadow-sm border space-y-3">
                               <h4 className="font-bold flex items-center gap-2 text-slate-800 text-sm uppercase tracking-wide"><Package className="w-4 h-4 text-indigo-500"/> Order Items</h4>
                               <div className="space-y-3 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
                                  {selectedOrder.items?.map((item, i) => (
                                      <div key={i} className="flex justify-between items-center text-sm border-b border-slate-50 pb-2 last:border-0 last:pb-0">
                                          <div className="flex items-center gap-2">
                                              <span className="font-bold bg-slate-100 text-slate-600 w-6 h-6 flex items-center justify-center rounded text-xs">{item.quantity}x</span>
                                              <span className="font-medium">{item.name}</span>
                                          </div>
                                          <span className="text-slate-500 text-xs font-mono">{item.price}</span>
                                      </div>
                                  ))}
                               </div>
                               <div className="border-t border-slate-100 pt-3 flex justify-between items-center">
                                      <span className="text-sm font-medium text-slate-500">Total Amount</span>
                                      <span className="font-bold text-xl text-emerald-600">{new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(selectedOrder.total_price)}</span>
                               </div>
                            </div>

                            {/* Customer Info */}
                            <div className="space-y-3 text-sm bg-white p-4 rounded-xl shadow-sm border">
                                <h4 className="font-bold text-slate-800 text-sm uppercase tracking-wide">Customer Details</h4>
                                <div className="grid grid-cols-1 gap-3">
                                   <div className="flex items-center gap-3 p-2 bg-slate-50 rounded-lg">
                                      <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center border shadow-sm"><Phone className="w-4 h-4 text-slate-400"/></div>
                                      <div>
                                         <p className="text-xs text-slate-400">Phone Number</p>
                                         <p className="font-medium text-slate-700">{selectedOrder.users?.phone || selectedOrder.contact_phone || 'No Phone'}</p>
                                      </div>
                                      <Button size="sm" variant="ghost" className="ml-auto text-indigo-600 h-8 text-xs">Call</Button>
                                   </div>
                                   <div className="flex items-center gap-3 p-2 bg-slate-50 rounded-lg">
                                      <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center border shadow-sm"><MapPin className="w-4 h-4 text-slate-400"/></div>
                                      <div>
                                         <p className="text-xs text-slate-400">Delivery Address</p>
                                         <p className="font-medium text-slate-700 line-clamp-1">{selectedOrder.delivery_address || 'No Address'}</p>
                                      </div>
                                   </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div className="h-48 md:h-64 rounded-xl overflow-hidden border shadow-sm relative bg-slate-100">
                               <div className="absolute top-2 left-2 z-[400] bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-bold shadow-sm flex items-center gap-1 border">
                                   <Navigation className="w-3 h-3 text-emerald-600"/> {selectedOrder.distance_km ? `${selectedOrder.distance_km} km` : 'Calculating route...'}
                               </div>
                               <IraqMap 
                                  center={[selectedOrder.customer_lat || 33.3152, selectedOrder.customer_lng || 44.3661]} 
                                  zoom={12} 
                                  markers={[
                                      { id: 'cust', lat: selectedOrder.customer_lat || 33.3152, lng: selectedOrder.customer_lng || 44.3661, type: 'customer', title: 'Customer' },
                                      { id: 'rest', lat: selectedOrder.restaurant_lat || 33.3152, lng: selectedOrder.restaurant_lng || 44.3661, type: 'restaurant', title: 'Restaurant' }
                                  ]}
                                  activeRoute={route}
                                  className="w-full h-full"
                               />
                            </div>
                        </div>
                    </div>
                 </div>
             )}

             <div className="p-4 bg-white border-t mt-auto shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
                 {selectedOrder && (
                    <div className="grid grid-cols-2 gap-3">
                        {selectedOrder.status === 'pending' && <Button onClick={() => updateStatus(selectedOrder.id, 'confirmed')} className="bg-blue-600 w-full col-span-2 hover:bg-blue-700 h-12 text-base shadow-lg shadow-blue-200">Confirm Order</Button>}
                        {selectedOrder.status === 'confirmed' && <Button onClick={() => updateStatus(selectedOrder.id, 'preparing')} className="bg-indigo-600 w-full col-span-2 hover:bg-indigo-700 h-12 text-base shadow-lg shadow-indigo-200">Start Preparing</Button>}
                        {selectedOrder.status === 'preparing' && <Button onClick={() => updateStatus(selectedOrder.id, 'ready')} className="bg-purple-600 w-full col-span-2 hover:bg-purple-700 h-12 text-base shadow-lg shadow-purple-200">Mark Ready</Button>}
                        {selectedOrder.status === 'ready' && <Button onClick={() => updateStatus(selectedOrder.id, 'delivering')} className="bg-orange-600 w-full col-span-2 hover:bg-orange-700 h-12 text-base shadow-lg shadow-orange-200">Dispatch Driver</Button>}
                        {selectedOrder.status === 'delivering' && <Button onClick={() => updateStatus(selectedOrder.id, 'delivered')} className="bg-emerald-600 w-full col-span-2 hover:bg-emerald-700 h-12 text-base shadow-lg shadow-emerald-200">Confirm Delivery</Button>}
                        
                        {['pending', 'confirmed'].includes(selectedOrder.status) && (
                            <Button variant="destructive" onClick={() => updateStatus(selectedOrder.id, 'cancelled')} className="w-full col-span-2 h-12 opacity-90 hover:opacity-100">Cancel Order</Button>
                        )}
                    </div>
                 )}
             </div>
          </DialogContent>
       </Dialog>
    </div>
  );
};

export default OrderManager;
