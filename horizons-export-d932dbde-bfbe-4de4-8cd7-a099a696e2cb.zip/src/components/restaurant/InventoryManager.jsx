
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Edit, Trash2, AlertTriangle, CheckCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Label } from '@/components/ui/label';

const InventoryManager = ({ restaurantId }) => {
  const [items, setItems] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({ name: '', quantity: '', unit: 'kg', cost_per_unit: '', min_stock_alert: '' });
  const { toast } = useToast();

  useEffect(() => {
    fetchInventory();
  }, [restaurantId]);

  const fetchInventory = async () => {
    const { data } = await supabase.from('inventory_items').select('*').eq('restaurant_id', restaurantId);
    if (data) setItems(data);
  };

  const handleSave = async () => {
    if (!formData.name) return;
    const payload = { ...formData, restaurant_id: restaurantId };
    
    let error;
    if (editingItem) {
        const { error: err } = await supabase.from('inventory_items').update(payload).eq('id', editingItem.id);
        error = err;
    } else {
        const { error: err } = await supabase.from('inventory_items').insert([payload]);
        error = err;
    }

    if (!error) {
        toast({ title: 'Saved', description: 'Inventory updated' });
        setIsDialogOpen(false);
        fetchInventory();
    }
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;
    await supabase.from('inventory_items').delete().eq('id', itemToDelete);
    fetchInventory();
    setDeleteConfirmOpen(false);
    setItemToDelete(null);
  };

  const openDeleteDialog = (id) => {
    setItemToDelete(id);
    setDeleteConfirmOpen(true);
  };

  const openDialog = (item = null) => {
     setEditingItem(item);
     if(item) setFormData({ name: item.name, quantity: item.quantity, unit: item.unit, cost_per_unit: item.cost_per_unit || '', min_stock_alert: item.min_stock_alert || '' });
     else setFormData({ name: '', quantity: '', unit: 'kg', cost_per_unit: '', min_stock_alert: '' });
     setIsDialogOpen(true);
  };

  return (
    <div className="space-y-4">
       <div className="flex justify-between items-center bg-white p-4 rounded-xl border shadow-sm">
          <h2 className="text-lg font-bold">Inventory Tracking</h2>
          <Button onClick={() => openDialog()} className="bg-blue-600"><Plus className="w-4 h-4 mr-2"/> Add Item</Button>
       </div>

       <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
          <Table>
             <TableHeader><TableRow><TableHead>Item Name</TableHead><TableHead>Quantity</TableHead><TableHead>Unit Cost</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
             <TableBody>
                {items.map(item => {
                   const isLow = item.quantity <= (item.min_stock_alert || 5);
                   return (
                      <TableRow key={item.id} className={isLow ? 'bg-red-50/50' : ''}>
                         <TableCell className="font-medium">{item.name}</TableCell>
                         <TableCell>{item.quantity} {item.unit}</TableCell>
                         <TableCell>{item.cost_per_unit ? `${item.cost_per_unit} IQD` : '-'}</TableCell>
                         <TableCell>
                            {isLow ? (
                               <span className="flex items-center text-red-600 text-xs font-bold gap-1"><AlertTriangle className="w-3 h-3"/> Low Stock</span>
                            ) : (
                               <span className="flex items-center text-emerald-600 text-xs font-bold gap-1"><CheckCircle className="w-3 h-3"/> In Stock</span>
                            )}
                         </TableCell>
                         <TableCell className="text-right">
                            <Button variant="ghost" size="icon" onClick={() => openDialog(item)}><Edit className="w-4 h-4 text-slate-500"/></Button>
                            <Button variant="ghost" size="icon" onClick={() => openDeleteDialog(item.id)}><Trash2 className="w-4 h-4 text-red-500"/></Button>
                         </TableCell>
                      </TableRow>
                   );
                })}
             </TableBody>
          </Table>
       </div>

       <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
             <DialogHeader><DialogTitle>{editingItem ? 'Edit Item' : 'Add Inventory Item'}</DialogTitle></DialogHeader>
             <div className="grid gap-4 py-4">
                <div className="space-y-2"><Label>Item Name</Label><Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} /></div>
                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2"><Label>Quantity</Label><Input type="number" value={formData.quantity} onChange={e => setFormData({...formData, quantity: e.target.value})} /></div>
                   <div className="space-y-2"><Label>Unit (kg, pcs, L)</Label><Input value={formData.unit} onChange={e => setFormData({...formData, unit: e.target.value})} /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2"><Label>Cost Per Unit</Label><Input type="number" value={formData.cost_per_unit} onChange={e => setFormData({...formData, cost_per_unit: e.target.value})} /></div>
                   <div className="space-y-2"><Label>Alert Threshold</Label><Input type="number" value={formData.min_stock_alert} onChange={e => setFormData({...formData, min_stock_alert: e.target.value})} /></div>
                </div>
             </div>
             <DialogFooter><Button onClick={handleSave}>Save Item</Button></DialogFooter>
          </DialogContent>
       </Dialog>

       <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <AlertDialogContent>
             <AlertDialogHeader>
                <AlertDialogTitle>Delete Inventory Item</AlertDialogTitle>
                <AlertDialogDescription>
                   Are you sure you want to delete this inventory item? This action cannot be undone.
                </AlertDialogDescription>
             </AlertDialogHeader>
             <div className="flex justify-end gap-3">
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteConfirm} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
             </div>
          </AlertDialogContent>
       </AlertDialog>
    </div>
  );
};

export default InventoryManager;
