
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart2, TrendingUp, Users, DollarSign } from 'lucide-react';

const AnalyticsManager = ({ restaurantId, fullView = false }) => {
  // Mock data for analytics visuals - In real app, aggregate via SQL or Edge Function
  return (
    <div className="space-y-6">
       {!fullView && <h2 className="text-xl font-bold mb-4">Quick Insights</h2>}
       
       {fullView && (
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
               <Card><CardContent className="p-6 text-center"><h3 className="text-3xl font-bold text-emerald-600">4.8</h3><p className="text-slate-500">Average Rating</p></CardContent></Card>
               <Card><CardContent className="p-6 text-center"><h3 className="text-3xl font-bold text-blue-600">85%</h3><p className="text-slate-500">Return Customers</p></CardContent></Card>
               <Card><CardContent className="p-6 text-center"><h3 className="text-3xl font-bold text-purple-600">22m</h3><p className="text-slate-500">Avg Prep Time</p></CardContent></Card>
           </div>
       )}

       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="shadow-sm">
             <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4"/> Weekly Revenue</CardTitle></CardHeader>
             <CardContent>
                <div className="h-48 flex items-end justify-between gap-2 pt-4">
                   {[40, 65, 45, 80, 55, 90, 75].map((h, i) => (
                      <div key={i} className="w-full bg-slate-100 rounded-t-lg relative group">
                         <div style={{ height: `${h}%` }} className="absolute bottom-0 w-full bg-indigo-500 rounded-t-lg group-hover:bg-indigo-600 transition-all"></div>
                      </div>
                   ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-slate-400">
                   <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
                </div>
             </CardContent>
          </Card>

          <Card className="shadow-sm">
             <CardHeader><CardTitle className="text-base flex items-center gap-2"><Users className="w-4 h-4"/> Customer Traffic</CardTitle></CardHeader>
             <CardContent>
                <div className="h-48 flex items-end justify-between gap-2 pt-4">
                   {[30, 45, 60, 50, 80, 95, 85].map((h, i) => (
                      <div key={i} className="w-full bg-slate-100 rounded-t-lg relative group">
                         <div style={{ height: `${h}%` }} className="absolute bottom-0 w-full bg-emerald-500 rounded-t-lg group-hover:bg-emerald-600 transition-all"></div>
                      </div>
                   ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-slate-400">
                   <span>12pm</span><span>2pm</span><span>4pm</span><span>6pm</span><span>8pm</span><span>10pm</span><span>12am</span>
                </div>
             </CardContent>
          </Card>
       </div>
    </div>
  );
};

export default AnalyticsManager;
