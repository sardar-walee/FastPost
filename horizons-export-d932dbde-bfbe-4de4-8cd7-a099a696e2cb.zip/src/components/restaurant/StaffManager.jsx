
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Edit, Trash2, User, Phone, Mail, DollarSign, Key, Shield } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Switch } from '@/components/ui/switch';

const StaffManager = ({ restaurantId }) => {
  const [staff, setStaff] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [staffToDelete, setStaffToDelete] = useState(null);
  const [editingStaff, setEditingStaff] = useState(null);
  
  // Expanded Form Data including Credentials
  const [formData, setFormData] = useState({ 
      full_name: '', email: '', role: 'staff', phone: '', salary: '', 
      username: '', password: '', create_login: false 
  });
  
  const { toast } = useToast();

  useEffect(() => {
    fetchStaff();
  }, [restaurantId]);

  const fetchStaff = async () => {
    const { data } = await supabase.from('employees').select('*').eq('restaurant_id', restaurantId);
    if (data) setStaff(data);
  };

  const handleSave = async () => {
    if (!formData.email || !formData.full_name) {
        toast({ variant: 'destructive', title: 'Validation Error', description: 'Name and Email are required.' });
        return;
    }
    
    // Hash password simply for demonstration (In production use proper auth/hashing)
    const passwordHash = formData.create_login && formData.password ? btoa(formData.password) : null; 

    const payload = { 
        full_name: formData.full_name,
        email: formData.email,
        role: formData.role,
        phone_number: formData.phone,
        salary: formData.salary ? parseFloat(formData.salary) : null,
        restaurant_id: restaurantId,
        username: formData.create_login ? formData.username : null,
        // Only update password if provided
        ...(passwordHash && { password_hash: passwordHash })
    };

    let error;
    if (editingStaff) {
       const { error: err } = await supabase.from('employees').update(payload).eq('id', editingStaff.id);
       error = err;
    } else {
       const { error: err } = await supabase.from('employees').insert([payload]);
       error = err;
    }

    if (error) {
       toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else {
       toast({ title: 'Success', description: 'Staff member saved successfully.' });
       setIsDialogOpen(false);
       fetchStaff();
    }
  };

  const handleDeleteConfirm = async () => {
    if (!staffToDelete) return;
    const { error } = await supabase.from('employees').delete().eq('id', staffToDelete);
    if (!error) {
      toast({ title: 'Deleted', description: 'Staff member removed.' });
      fetchStaff();
    }
    setDeleteConfirmOpen(false);
    setStaffToDelete(null);
  };

  const openDeleteDialog = (id) => {
    setStaffToDelete(id);
    setDeleteConfirmOpen(true);
  };

  const openDialog = (member = null) => {
     setEditingStaff(member);
     if (member) {
         setFormData({ 
             full_name: member.full_name, 
             email: member.email, 
             role: member.role, 
             phone: member.phone_number || '', 
             salary: member.salary || '',
             username: member.username || '',
             password: '', // Never show existing password
             create_login: !!member.username
         });
     } else {
         setFormData({ full_name: '', email: '', role: 'staff', phone: '', salary: '', username: '', password: '', create_login: false });
     }
     setIsDialogOpen(true);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
       <div className="flex justify-between items-center bg-white p-4 rounded-xl border shadow-sm">
          <div>
              <h2 className="text-lg font-bold">Staff Directory</h2>
              <p className="text-xs text-slate-500">Manage your team members and roles</p>
          </div>
          <Button onClick={() => openDialog()} className="bg-emerald-600 hover:bg-emerald-700"><Plus className="w-4 h-4 mr-2"/> Add Staff</Button>
       </div>

       <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
          <Table>
             <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Role</TableHead><TableHead>Login</TableHead><TableHead>Contact</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
             </TableHeader>
             <TableBody>
                {staff.map(s => (
                   <TableRow key={s.id}>
                      <TableCell className="font-medium flex items-center gap-3">
                         <div className="w-9 h-9 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 border border-indigo-100">
                             <User className="w-4 h-4"/>
                         </div>
                         <div>
                             <div className="font-bold">{s.full_name}</div>
                             <div className="text-xs text-slate-400">ID: {s.id.slice(0,6)}</div>
                         </div>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="capitalize bg-slate-50">{s.role}</Badge></TableCell>
                      <TableCell>
                          {s.username ? (
                              <Badge className="bg-green-100 text-green-700 hover:bg-green-200 border-0 flex w-fit items-center gap-1">
                                  <Key className="w-3 h-3" /> Active
                              </Badge>
                          ) : (
                              <Badge variant="outline" className="text-slate-400 border-dashed">No Access</Badge>
                          )}
                      </TableCell>
                      <TableCell>
                          <div className="flex flex-col gap-1 text-xs text-slate-600">
                              <span className="flex items-center gap-1"><Mail className="w-3 h-3"/> {s.email}</span>
                              {s.phone_number && <span className="flex items-center gap-1"><Phone className="w-3 h-3"/> {s.phone_number}</span>}
                          </div>
                      </TableCell>
                      <TableCell className="text-right">
                         <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="icon" onClick={() => openDialog(s)}><Edit className="w-4 h-4 text-slate-500"/></Button>
                            <Button variant="ghost" size="icon" onClick={() => openDeleteDialog(s.id)}><Trash2 className="w-4 h-4 text-red-500"/></Button>
                         </div>
                      </TableCell>
                   </TableRow>
                ))}
                {staff.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-8 text-slate-400">No staff members found.</TableCell></TableRow>}
             </TableBody>
          </Table>
       </div>

       <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
             <DialogHeader><DialogTitle>{editingStaff ? 'Edit Staff Member' : 'Add New Staff'}</DialogTitle></DialogHeader>
             <div className="grid gap-6 py-4">
                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2"><Label>Full Name</Label><Input value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})} placeholder="e.g. Ali Ahmed" /></div>
                   <div className="space-y-2"><Label>Email</Label><Input value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="staff@example.com" /></div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2">
                      <Label>Role</Label>
                      <Select value={formData.role} onValueChange={v => setFormData({...formData, role: v})}>
                         <SelectTrigger><SelectValue /></SelectTrigger>
                         <SelectContent>
                            <SelectItem value="manager">Manager</SelectItem>
                            <SelectItem value="chef">Chef</SelectItem>
                            <SelectItem value="cashier">Cashier</SelectItem>
                            <SelectItem value="waiter">Waiter</SelectItem>
                            <SelectItem value="driver">Driver</SelectItem>
                         </SelectContent>
                      </Select>
                   </div>
                   <div className="space-y-2">
                       <Label>Phone Number</Label>
                       <Input value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="0770..." />
                   </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <Shield className="w-5 h-5 text-indigo-600" />
                            <div>
                                <h4 className="font-bold text-sm text-slate-800">Login Credentials</h4>
                                <p className="text-xs text-slate-500">Allow this staff member to log in to the system</p>
                            </div>
                        </div>
                        <Switch checked={formData.create_login} onCheckedChange={c => setFormData({...formData, create_login: c})} />
                    </div>

                    {formData.create_login && (
                        <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-200">
                            <div className="space-y-2">
                                <Label>Username</Label>
                                <Input value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})} placeholder="username" />
                            </div>
                            <div className="space-y-2">
                                <Label>Password {editingStaff && '(Leave empty to keep)'}</Label>
                                <Input type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="••••••" />
                            </div>
                        </div>
                    )}
                </div>
             </div>
             <DialogFooter>
                 <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                 <Button onClick={handleSave}>Save Staff Member</Button>
             </DialogFooter>
          </DialogContent>
       </Dialog>

       <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <AlertDialogContent>
             <AlertDialogHeader>
                <AlertDialogTitle>Remove Staff Member</AlertDialogTitle>
                <AlertDialogDescription>
                   Are you sure you want to remove this staff member? This action cannot be undone.
                </AlertDialogDescription>
             </AlertDialogHeader>
             <div className="flex justify-end gap-3">
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteConfirm} className="bg-red-600 hover:bg-red-700">Remove</AlertDialogAction>
             </div>
          </AlertDialogContent>
       </AlertDialog>
    </div>
  );
};

export default StaffManager;
