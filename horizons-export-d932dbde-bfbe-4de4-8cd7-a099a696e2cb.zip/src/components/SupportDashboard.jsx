
import React, { useState } from 'react';
import { 
  Ticket, MessageSquare, Users, BookOpen, CheckCircle, 
  Clock, AlertCircle, Search, Filter 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';

const SupportDashboard = ({ user, activeSection = 'tickets' }) => {
  const [tickets, setTickets] = useState([
    { id: 1, subject: "Order #12345 Not Delivered", user: "Ahmed Ali", status: "open", priority: "high", created: "2 hrs ago" },
    { id: 2, subject: "Payment Failed", user: "Sarah Smith", status: "pending", priority: "medium", created: "5 hrs ago" },
    { id: 3, subject: "Account Access Issue", user: "John Doe", status: "resolved", priority: "low", created: "1 day ago" },
  ]);

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Open Tickets</p>
              <h3 className="text-2xl font-bold text-slate-800">12</h3>
            </div>
            <Ticket className="w-8 h-8 text-indigo-500 opacity-20" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Avg Response</p>
              <h3 className="text-2xl font-bold text-slate-800">15m</h3>
            </div>
            <Clock className="w-8 h-8 text-emerald-500 opacity-20" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Resolved Today</p>
              <h3 className="text-2xl font-bold text-slate-800">45</h3>
            </div>
            <CheckCircle className="w-8 h-8 text-blue-500 opacity-20" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Active Chats</p>
              <h3 className="text-2xl font-bold text-slate-800">3</h3>
            </div>
            <MessageSquare className="w-8 h-8 text-orange-500 opacity-20" />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Tickets</CardTitle>
          <CardDescription>Latest support requests needing attention</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {tickets.map(ticket => (
              <div key={ticket.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border">
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarFallback>{ticket.user[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-semibold text-slate-800">{ticket.subject}</h4>
                    <p className="text-sm text-slate-500">{ticket.user} • {ticket.created}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={ticket.priority === 'high' ? 'destructive' : 'secondary'}>
                    {ticket.priority}
                  </Badge>
                  <Badge className={
                    ticket.status === 'open' ? 'bg-green-500' : 
                    ticket.status === 'pending' ? 'bg-amber-500' : 'bg-slate-500'
                  }>
                    {ticket.status}
                  </Badge>
                  <Button variant="outline" size="sm">View</Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderTickets = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Ticket Management</h2>
        <div className="flex gap-2">
           <div className="relative">
             <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
             <Input placeholder="Search tickets..." className="pl-9 w-64" />
           </div>
           <Button variant="outline"><Filter className="w-4 h-4 mr-2"/> Filter</Button>
        </div>
      </div>
      {/* Expanded Ticket List logic would go here */}
      <div className="bg-white rounded-xl border p-8 text-center text-slate-500">
         <Ticket className="w-12 h-12 mx-auto mb-4 text-slate-300" />
         <p>Comprehensive ticket list view would be implemented here.</p>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard': return renderOverview();
      case 'tickets': return renderTickets();
      default: return renderOverview();
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {renderContent()}
    </div>
  );
};

export default SupportDashboard;
