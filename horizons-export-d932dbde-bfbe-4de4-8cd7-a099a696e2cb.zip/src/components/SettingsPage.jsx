
import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Palette, Globe, Bell, LogOut, Check, Trash2, AlertTriangle, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';

const SettingsPage = ({ user, onClose }) => {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const { signOut } = useAuth();
  
  const [language, setLanguage] = useState(i18n.language);
  const [preferences, setPreferences] = useState({
    orders: true,
    promos: true,
    security: true,
    ai_recommendations: true
  });
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (user) {
      fetchUserSettings();
    }
  }, [user]);

  const fetchUserSettings = async () => {
    try {
      const { data } = await supabase.from('users').select('language, notification_preferences').eq('id', user.id).single();
      if (data) {
        if (data.language) setLanguage(data.language);
        if (data.notification_preferences) setPreferences(data.notification_preferences);
      }
    } catch (error) {
      console.error("Error fetching settings:", error);
    }
  };

  const handleThemeChange = async (newTheme) => {
    setTheme(newTheme);
    if (user) await supabase.from('users').update({ theme: newTheme }).eq('id', user.id);
    toast({ title: t('save'), description: t('success') });
  };

  const handleLanguageChange = async (newLang) => {
    setLanguage(newLang);
    i18n.changeLanguage(newLang);
    document.dir = ['ar', 'ur', 'ckb', 'fa'].includes(newLang) ? 'rtl' : 'ltr';
    if (user) await supabase.from('users').update({ language: newLang }).eq('id', user.id);
    toast({ title: t('save'), description: t('success') });
  };

  const handlePrefChange = async (key, value) => {
    const newPrefs = { ...preferences, [key]: value };
    setPreferences(newPrefs);
    if (user) await supabase.from('users').update({ notification_preferences: newPrefs }).eq('id', user.id);
  };

  const handleLogout = async () => {
    setIsLoggingOut(true);
    await signOut();
    if (onClose) onClose();
    setIsLoggingOut(false);
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirmation.toLowerCase() !== 'delete') {
        toast({ variant: "destructive", title: "Incorrect confirmation", description: "Please type 'delete' to confirm." });
        return;
    }
    
    setIsDeleting(true);
    try {
        // Soft delete the user
        const { error } = await supabase.from('users').update({ deleted_at: new Date().toISOString() }).eq('id', user.id);
        
        if (error) throw error;
        
        toast({ title: "Account Deleted", description: "Your account has been deactivated." });
        await signOut();
    } catch (error) {
        toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
        setIsDeleting(false);
        setIsDeleteModalOpen(false);
    }
  };

  const themes = [
    { name: 'light', color: 'bg-white border-slate-200' },
    { name: 'dark', color: 'bg-slate-900 border-slate-700' },
    { name: 'blue', color: 'bg-blue-500 border-blue-600' },
    { name: 'green', color: 'bg-emerald-500 border-emerald-600' },
    { name: 'purple', color: 'bg-violet-500 border-violet-600' },
    { name: 'orange', color: 'bg-orange-500 border-orange-600' },
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6 pb-24 animate-in fade-in zoom-in-95 duration-300">
       <div className="flex items-center justify-between">
           <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">{t('settings')}</h1>
           {onClose && <Button onClick={onClose} variant="outline">{t('close')}</Button>}
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {/* Appearance */}
           <Card className="glass-card">
               <CardHeader>
                   <CardTitle className="flex items-center gap-2 text-primary"><Palette className="w-5 h-5"/> {t('theme')}</CardTitle>
                   <CardDescription>Select your preferred visual style</CardDescription>
               </CardHeader>
               <CardContent className="grid grid-cols-3 gap-4">
                   {themes.map((tItem) => (
                       <button
                          key={tItem.name}
                          onClick={() => handleThemeChange(tItem.name)}
                          className={`
                            relative h-16 rounded-xl border-2 flex flex-col items-center justify-center font-medium capitalize transition-all duration-200
                            ${theme === tItem.name 
                                ? 'border-primary ring-2 ring-primary/20 scale-105' 
                                : 'border-transparent hover:border-slate-300 dark:hover:border-slate-600 hover:scale-105'
                            }
                            ${tItem.name === 'light' ? 'bg-slate-50 text-slate-900' : ''}
                            ${tItem.name === 'dark' ? 'bg-slate-950 text-slate-100' : ''}
                            ${!['light', 'dark'].includes(tItem.name) ? `${tItem.color} text-white` : ''}
                          `}
                       >
                          {theme === tItem.name && <div className="absolute -top-2 -right-2 bg-primary text-white rounded-full p-0.5 shadow-md"><Check className="w-3 h-3" /></div>}
                          <span className="text-sm font-semibold">{t(tItem.name) || tItem.name}</span>
                       </button>
                   ))}
               </CardContent>
           </Card>

           {/* Language */}
           <Card className="glass-card">
               <CardHeader>
                   <CardTitle className="flex items-center gap-2 text-primary"><Globe className="w-5 h-5"/> {t('language')}</CardTitle>
                   <CardDescription>{t('language_select')}</CardDescription>
               </CardHeader>
               <CardContent>
                   <Select value={language} onValueChange={handleLanguageChange}>
                       <SelectTrigger className="w-full">
                           <SelectValue placeholder={t('language')} />
                       </SelectTrigger>
                       <SelectContent>
                           <SelectItem value="en">English (US)</SelectItem>
                           <SelectItem value="ar">العربية (Arabic)</SelectItem>
                           <SelectItem value="ckb">کوردی سۆرانی (Sorani)</SelectItem>
                           <SelectItem value="kmr">Kurdî Badînî (Badini)</SelectItem>
                           <SelectItem value="tr">Türkçe (Turkish)</SelectItem>
                           <SelectItem value="fa">فارسی (Persian)</SelectItem>
                       </SelectContent>
                   </Select>
               </CardContent>
           </Card>

           {/* Notifications */}
           <Card className="glass-card md:col-span-2">
               <CardHeader>
                   <CardTitle className="flex items-center gap-2 text-primary"><Bell className="w-5 h-5"/> {t('notification_preferences')}</CardTitle>
                   <CardDescription>Manage how you receive updates</CardDescription>
               </CardHeader>
               <CardContent className="space-y-6">
                   {['orders', 'promos', 'ai_recommendations'].map(key => (
                       <div key={key} className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                           <Label className="flex flex-col gap-1 cursor-pointer" htmlFor={`pref-${key}`}>
                               <span className="text-base font-medium capitalize">{t(key) || key.replace('_', ' ')}</span>
                               <span className="font-normal text-sm text-slate-500">Enable or disable {key.replace('_', ' ')} notifications</span>
                           </Label>
                           <Switch id={`pref-${key}`} checked={preferences[key]} onCheckedChange={c => handlePrefChange(key, c)} />
                       </div>
                   ))}
               </CardContent>
           </Card>

           {/* Account Actions */}
           {user && (
               <Card className="glass-card md:col-span-2 border-red-100 dark:border-red-900/30">
                   <CardHeader>
                       <CardTitle className="flex items-center gap-2 text-red-600"><LogOut className="w-5 h-5"/> {t('account_actions')}</CardTitle>
                   </CardHeader>
                   <CardContent className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h4 className="font-semibold text-slate-800 dark:text-white">Sign out</h4>
                            <p className="text-sm text-slate-500">End your current session securely.</p>
                        </div>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button variant="outline" className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700">
                                    {t('logout')}
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>Confirm Logout</AlertDialogTitle>
                                    <AlertDialogDescription>Are you sure you want to log out?</AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={handleLogout} className="bg-red-600 hover:bg-red-700 text-white" disabled={isLoggingOut}>
                                        {isLoggingOut ? 'Logging out...' : 'Log out'}
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                   </CardContent>
                   <div className="h-px bg-red-100 dark:bg-red-900/30 mx-6" />
                   <CardContent className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h4 className="font-semibold text-red-700 dark:text-red-400">Delete Account</h4>
                            <p className="text-sm text-red-600/70">Permanently remove your account and data.</p>
                        </div>
                        <Button variant="destructive" onClick={() => setIsDeleteModalOpen(true)}>
                            <Trash2 className="w-4 h-4 mr-2"/> Delete Account
                        </Button>
                   </CardContent>
               </Card>
           )}
       </div>

       {/* Delete Account Dialog */}
       <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
           <DialogContent className="border-red-200">
               <DialogHeader>
                   <DialogTitle className="flex items-center gap-2 text-red-600">
                       <AlertTriangle className="w-5 h-5"/> Danger Zone
                   </DialogTitle>
                   <DialogDescription>
                       This action cannot be undone. This will permanently deactivate your account and remove your data from our servers.
                   </DialogDescription>
               </DialogHeader>
               <div className="space-y-4 py-4">
                   <Label>Type <span className="font-bold font-mono">delete</span> to confirm:</Label>
                   <Input 
                       value={deleteConfirmation} 
                       onChange={(e) => setDeleteConfirmation(e.target.value)} 
                       placeholder="delete"
                       className="border-red-200 focus-visible:ring-red-500"
                   />
               </div>
               <DialogFooter>
                   <Button variant="ghost" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
                   <Button 
                       variant="destructive" 
                       onClick={handleDeleteAccount}
                       disabled={deleteConfirmation.toLowerCase() !== 'delete' || isDeleting}
                       className="bg-red-600 hover:bg-red-700"
                   >
                       {isDeleting ? <Loader2 className="w-4 h-4 animate-spin"/> : "Permanently Delete"}
                   </Button>
               </DialogFooter>
           </DialogContent>
       </Dialog>
    </div>
  );
};

export default SettingsPage;
