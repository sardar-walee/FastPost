
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Package, Heart, MapPin, Wallet, CreditCard, Clock, ChevronRight, Plus, ArrowUpRight, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';

const CustomerDashboard = ({ user, orders = [], activeTab = 'orders' }) => {
  const [currentTab, setCurrentTab] = useState(activeTab);

  const renderOrders = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
       <div className="flex items-center justify-between">
           <h3 className="text-lg font-bold text-slate-800">Order History</h3>
           <Button variant="ghost" size="sm" className="text-indigo-600 hover:bg-indigo-50">View All</Button>
       </div>
       
       {orders.length === 0 ? (
          <div className="text-center py-16 bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center">
             <div className="w-16 h-16 bg-white rounded-full shadow-sm flex items-center justify-center mb-4">
                <Package className="w-8 h-8 text-slate-300" />
             </div>
             <h4 className="text-slate-900 font-semibold text-lg">No orders yet</h4>
             <p className="text-slate-500 text-sm mt-1 max-w-xs">Looks like you haven't placed any orders. Start exploring delicious food around you!</p>
             <Button className="mt-6 bg-indigo-600 hover:bg-indigo-700 rounded-xl">Explore Food</Button>
          </div>
       ) : (
          <div className="grid gap-4">
             {orders.map(order => (
                <div key={order.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                          <ShoppingBag className="w-6 h-6 text-slate-400 group-hover:text-indigo-600" />
                      </div>
                      <div>
                         <h3 className="font-bold text-slate-900">Order #{order.id.slice(0,6)}</h3>
                         <p className="text-sm text-slate-500 mt-0.5">{new Date(order.created_at).toLocaleDateString()} • {order.items?.length || 1} Items</p>
                      </div>
                   </div>
                   <div className="flex items-center justify-between md:justify-end gap-6 w-full md:w-auto">
                      <div className="text-right">
                          <p className="font-bold text-slate-900">{(order.total_price || 0).toLocaleString()} IQD</p>
                          <Badge variant={order.status === 'delivered' ? 'default' : 'secondary'} className="mt-1 capitalize">
                              {order.status}
                          </Badge>
                      </div>
                      <Button variant="ghost" size="icon" className="rounded-full bg-slate-50 group-hover:bg-slate-100"><ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-slate-600"/></Button>
                   </div>
                </div>
             ))}
          </div>
       )}
    </div>
  );

  const renderFavorites = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h3 className="text-lg font-bold text-slate-800">Your Favorites</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           <Card className="border-2 border-dashed border-slate-200 bg-slate-50/50 shadow-none flex flex-col items-center justify-center p-8 text-center cursor-pointer hover:bg-slate-50 hover:border-indigo-300 transition-all group">
              <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Heart className="w-6 h-6 text-indigo-400 group-hover:text-indigo-600" />
              </div>
              <p className="font-semibold text-slate-700">Add Favorites</p>
              <p className="text-xs text-slate-500 mt-1">Save places you love</p>
           </Card>
           
           {[1, 2].map(i => (
              <Card key={i} className="overflow-hidden group cursor-pointer border-slate-100 shadow-sm hover:shadow-lg transition-all">
                 <div className="h-32 bg-slate-200 relative">
                    <img src={`https://source.unsplash.com/random/400x300?food&sig=${i}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <Button size="icon" variant="secondary" className="absolute top-3 right-3 rounded-full h-8 w-8 text-rose-500 bg-white shadow-sm hover:bg-white"><Heart className="w-4 h-4 fill-current"/></Button>
                 </div>
                 <CardContent className="p-4">
                    <h3 className="font-bold text-slate-900 text-lg">Tasty Burger Spot #{i}</h3>
                    <p className="text-xs text-slate-500 mt-1 mb-3">Fast Food • 4.5 Stars • 2.5km</p>
                    <Button variant="outline" className="w-full h-9 text-xs rounded-lg">Order Again</Button>
                 </CardContent>
              </Card>
           ))}
        </div>
    </div>
  );

  const renderWallet = () => (
     <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-slate-900 to-slate-800 p-8 text-white shadow-2xl">
           <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500 rounded-full mix-blend-overlay filter blur-3xl opacity-20 -mr-16 -mt-16"></div>
           <div className="relative z-10">
               <div className="flex justify-between items-start mb-8">
                   <div>
                       <p className="text-slate-400 font-medium mb-1">Total Balance</p>
                       <h2 className="text-4xl md:text-5xl font-bold tracking-tight">25,000 <span className="text-2xl text-slate-400 font-normal">IQD</span></h2>
                   </div>
                   <div className="p-3 bg-white/10 backdrop-blur-md rounded-2xl">
                       <Wallet className="w-8 h-8 text-indigo-300" />
                   </div>
               </div>
               
               <div className="flex gap-4">
                   <Button className="flex-1 bg-white text-slate-900 hover:bg-slate-100 h-12 rounded-xl font-bold border-0">
                       <Plus className="w-4 h-4 mr-2"/> Top Up
                   </Button>
                   <Button className="flex-1 bg-white/10 text-white hover:bg-white/20 h-12 rounded-xl font-bold backdrop-blur-md border border-white/10">
                       <ArrowUpRight className="w-4 h-4 mr-2"/> Transfer
                   </Button>
               </div>
           </div>
        </div>

        <div>
           <div className="flex items-center justify-between mb-4">
               <h3 className="font-bold text-lg text-slate-800">Recent Transactions</h3>
               <Button variant="ghost" size="sm" className="text-slate-500 hover:text-slate-900">View Report</Button>
           </div>
           
           <div className="space-y-3">
              {[1, 2, 3].map(i => (
                 <div key={i} className="flex justify-between items-center p-4 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all">
                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-slate-600 border border-slate-100">
                           <CreditCard className="w-5 h-5"/>
                       </div>
                       <div>
                          <p className="font-bold text-slate-900 text-sm">Food Order Payment</p>
                          <p className="text-xs text-slate-500 mt-0.5">Today, 12:30 PM • Credit Card</p>
                       </div>
                    </div>
                    <span className="font-bold text-slate-900">- 12,500 IQD</span>
                 </div>
              ))}
           </div>
        </div>
     </div>
  );

  return (
    <div className="max-w-5xl mx-auto pb-20">
       <Tabs value={currentTab} onValueChange={setCurrentTab} className="space-y-8">
          <TabsList className="bg-slate-100/50 p-1.5 rounded-2xl w-full md:w-auto inline-flex">
             <TabsTrigger value="orders" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-white data-[state=active]:shadow-md data-[state=active]:text-indigo-600 transition-all">Orders</TabsTrigger>
             <TabsTrigger value="favorites" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-white data-[state=active]:shadow-md data-[state=active]:text-indigo-600 transition-all">Favorites</TabsTrigger>
             <TabsTrigger value="wallet" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-white data-[state=active]:shadow-md data-[state=active]:text-indigo-600 transition-all">Wallet</TabsTrigger>
          </TabsList>

          <TabsContent value="orders">{renderOrders()}</TabsContent>
          <TabsContent value="favorites">{renderFavorites()}</TabsContent>
          <TabsContent value="wallet">{renderWallet()}</TabsContent>
       </Tabs>
    </div>
  );
};

export default CustomerDashboard;
