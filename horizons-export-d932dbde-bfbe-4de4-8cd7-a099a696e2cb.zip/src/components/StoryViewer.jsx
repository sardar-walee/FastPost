
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, Eye, ChevronLeft, ChevronRight, ShoppingBag, Calendar, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const StoryViewer = ({ isOpen, onClose, stories, initialStoryIndex = 0, onLikeToggle, currentUserId }) => {
  const [currentIndex, setCurrentIndex] = useState(initialStoryIndex);
  const [hasLiked, setHasLiked] = useState(false);
  const { toast } = useToast();

  const currentStory = stories[currentIndex];

  useEffect(() => {
    setCurrentIndex(initialStoryIndex);
  }, [initialStoryIndex]);

  useEffect(() => {
    if (isOpen && currentStory) {
      checkIfLiked();
      incrementView();
    }
  }, [isOpen, currentIndex]);

  const incrementView = async () => {
    if (!currentStory) return;
    await supabase.rpc('increment_story_view', { p_story_id: currentStory.id });
  };

  const checkIfLiked = async () => {
    if (!currentUserId || !currentStory) return;
    const { data } = await supabase
      .from('story_likes')
      .select('id')
      .eq('story_id', currentStory.id)
      .eq('user_id', currentUserId)
      .single();
    setHasLiked(!!data);
  };

  const handleLike = async () => {
    if (!currentUserId) {
        toast({ title: "Login Required", description: "Please login to like stories." });
        return;
    }
    
    // Optimistic update
    const newLikedState = !hasLiked;
    setHasLiked(newLikedState);
    if(onLikeToggle) onLikeToggle(currentStory.id, newLikedState);

    const { data: isLikedNow, error } = await supabase.rpc('toggle_story_like', {
      p_story_id: currentStory.id,
      p_user_id: currentUserId
    });

    if (error) {
       console.error(error);
       setHasLiked(!newLikedState); // Revert
    } else {
       setHasLiked(isLikedNow);
    }
  };

  const handleNext = (e) => {
    e?.stopPropagation();
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = (e) => {
    e?.stopPropagation();
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const handleCTA = () => {
      toast({
          title: "Action Triggered",
          description: `User clicked ${currentStory.cta_type} for item: ${currentStory.linked_item_title || 'Item'}`
      });
  };

  if (!isOpen || !currentStory) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[60] bg-black flex items-center justify-center"
      >
        <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-4 right-4 text-white z-50 hover:bg-white/20" 
            onClick={onClose}
        >
          <X className="w-8 h-8" />
        </Button>

        <div className="relative w-full h-full md:max-w-md md:h-[85vh] bg-slate-900 md:rounded-xl overflow-hidden shadow-2xl">
          {/* Progress Bar (Simple) */}
          <div className="absolute top-2 left-2 right-2 flex gap-1 z-20">
            {stories.map((_, idx) => (
              <div key={idx} className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
                <div 
                    className={`h-full bg-white transition-all duration-300 ${idx < currentIndex ? 'w-full' : idx === currentIndex ? 'w-full' : 'w-0'}`} 
                />
              </div>
            ))}
          </div>

          {/* Header Info */}
          <div className="absolute top-6 left-4 z-20 flex items-center gap-3">
             <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold border-2 ${currentStory.is_vip ? 'border-yellow-400 bg-yellow-600' : 'border-emerald-500 bg-emerald-600'}`}>
                {currentStory.business_name?.[0] || 'U'}
             </div>
             <div>
                 <p className="text-white font-bold text-sm shadow-sm">{currentStory.business_name || 'User Story'}</p>
                 <p className="text-white/70 text-xs">{new Date(currentStory.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
             </div>
             {currentStory.is_vip && <span className="bg-yellow-400 text-black text-[10px] font-bold px-2 py-0.5 rounded-full">VIP</span>}
          </div>

          {/* Media */}
          <div className="w-full h-full flex items-center justify-center bg-black" onClick={handleNext}>
             <img 
                src={currentStory.media_url} 
                alt="Story" 
                className="w-full h-full object-cover"
             />
             <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none" />
          </div>

          {/* Navigation Overlay Areas */}
          <div className="absolute inset-y-0 left-0 w-1/4 z-10" onClick={handlePrev} />
          
          {/* Footer Controls */}
          <div className="absolute bottom-0 left-0 right-0 p-6 z-30 flex flex-col gap-4">
             {currentStory.caption && (
                 <p className="text-white text-center font-medium drop-shadow-md line-clamp-2">
                     {currentStory.caption}
                 </p>
             )}

             {currentStory.cta_type && currentStory.cta_type !== 'none' && (
                 <motion.div 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                 >
                    <Button 
                        onClick={(e) => { e.stopPropagation(); handleCTA(); }}
                        className="w-full bg-white text-black hover:bg-slate-200 font-bold rounded-full animate-pulse"
                    >
                        {currentStory.cta_type === 'cart' && <><ShoppingBag className="w-4 h-4 mr-2"/> Add to Cart</>}
                        {currentStory.cta_type === 'book' && <><Calendar className="w-4 h-4 mr-2"/> Book Now</>}
                        {currentStory.cta_type === 'contact' && <><Phone className="w-4 h-4 mr-2"/> Contact Seller</>}
                        {currentStory.cta_type === 'buy' && "Buy Now"}
                    </Button>
                 </motion.div>
             )}

             <div className="flex items-center justify-between mt-2">
                 <div className="flex items-center gap-4">
                     <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={(e) => { e.stopPropagation(); handleLike(); }}
                        className={`hover:bg-transparent ${hasLiked ? 'text-red-500' : 'text-white'}`}
                     >
                         <Heart className={`w-8 h-8 ${hasLiked ? 'fill-current' : ''}`} />
                     </Button>
                     {/* Share button could go here */}
                 </div>
                 <div className="flex items-center text-white/80 gap-1 text-sm font-medium">
                     <Eye className="w-4 h-4" />
                     {currentStory.views_count || 0}
                 </div>
             </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default StoryViewer;
