
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, ShoppingCart, Plus, Minus, Trash2, CreditCard, 
  Banknote, Receipt, User, Coffee, Utensils, CheckCircle, 
  LayoutDashboard, FileText, Settings, LogOut
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/supabaseClient';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const CashierDashboard = ({ user }) => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('pos');
  const [menuItems, setMenuItems] = useState([]);
  const [cart, setCart] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [processingPayment, setProcessingPayment] = useState(false);
  const [lastOrder, setLastOrder] = useState(null);

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    const { data } = await supabase.from('menu_items').select('*');
    if (data) setMenuItems(data);
  };

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (itemId) => {
    setCart(prev => prev.filter(i => i.id !== itemId));
  };

  const updateQuantity = (itemId, delta) => {
    setCart(prev => prev.map(i => {
      if (i.id === itemId) {
        const newQty = Math.max(1, i.quantity + delta);
        return { ...i, quantity: newQty };
      }
      return i;
    }));
  };

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const handleCheckout = async (method) => {
    if (cart.length === 0) return;
    setProcessingPayment(true);

    const total = calculateTotal();
    
    // Create Order
    const { data: order, error } = await supabase.from('orders').insert([{
      user_id: user?.id, 
      restaurant_id: menuItems[0]?.restaurant_id, 
      total_price: total,
      status: 'preparing',
      payment_status: 'paid',
      items: cart,
      cashier_id: user?.id,
      delivery_address: 'Dine-in / Takeaway'
    }]).select().single();

    if (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } else {
      setLastOrder(order);
      setCart([]);
      toast({ title: "Order Processed", description: `Order #${order.id.slice(0,6)} created successfully.` });
    }
    setProcessingPayment(false);
  };

  const filteredItems = menuItems.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatCurrency = (val) => new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(val);

  const POSView = () => (
    <div className="h-full flex gap-6">
      {/* Left Side: Menu */}
      <div className="flex-1 flex flex-col gap-4">
        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input 
              placeholder="Search menu items..." 
              className="pl-9 bg-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="food">Food</TabsTrigger>
              <TabsTrigger value="drinks">Drinks</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <ScrollArea className="flex-1 bg-slate-100/50 rounded-2xl border p-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredItems.map(item => (
              <motion.button
                key={item.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => addToCart(item)}
                className="bg-white p-4 rounded-xl border shadow-sm hover:border-indigo-500 hover:shadow-md transition-all text-left flex flex-col h-full"
              >
                <div className="h-24 bg-slate-100 rounded-lg mb-3 overflow-hidden">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                  ) : (
                    <Utensils className="w-8 h-8 m-auto mt-8 text-slate-300" />
                  )}
                </div>
                <h3 className="font-bold text-slate-800 line-clamp-1">{item.name}</h3>
                <p className="text-emerald-600 font-bold mt-auto">{formatCurrency(item.price)}</p>
              </motion.button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Right Side: Cart & Checkout */}
      <div className="w-96 bg-white rounded-2xl border shadow-lg flex flex-col">
        <div className="p-6 border-b bg-slate-50/50 rounded-t-2xl">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-indigo-600" /> Current Order
          </h2>
          <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
            <User className="w-4 h-4" />
            <span>Walk-in Customer</span>
          </div>
        </div>

        <ScrollArea className="flex-1 p-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-2">
              <Coffee className="w-12 h-12 opacity-20" />
              <p>No items in cart</p>
            </div>
          ) : (
            <div className="space-y-3">
              {cart.map(item => (
                <div key={item.id} className="flex items-center gap-3 bg-slate-50 p-3 rounded-lg border">
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{item.name}</h4>
                    <p className="text-xs text-slate-500">{formatCurrency(item.price)}</p>
                  </div>
                  <div className="flex items-center gap-2 bg-white rounded-lg border px-1">
                    <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-slate-100 rounded"><Minus className="w-3 h-3" /></button>
                    <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-slate-100 rounded"><Plus className="w-3 h-3" /></button>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} className="text-red-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        <div className="p-6 border-t bg-slate-50/50 rounded-b-2xl space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Subtotal</span>
              <span>{formatCurrency(calculateTotal())}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Tax (0%)</span>
              <span>{formatCurrency(0)}</span>
            </div>
            <div className="flex justify-between text-xl font-bold pt-2 border-t">
              <span>Total</span>
              <span className="text-indigo-600">{formatCurrency(calculateTotal())}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="outline" 
              className="h-12 flex flex-col items-center justify-center gap-1"
              onClick={() => handleCheckout('cash')}
              disabled={processingPayment || cart.length === 0}
            >
              <Banknote className="w-4 h-4" />
              <span className="text-xs">Cash</span>
            </Button>
            <Button 
              className="h-12 flex flex-col items-center justify-center gap-1 bg-indigo-600 hover:bg-indigo-700"
              onClick={() => handleCheckout('card')}
              disabled={processingPayment || cart.length === 0}
            >
              <CreditCard className="w-4 h-4" />
              <span className="text-xs">Card</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-[calc(100vh-6rem)] flex flex-col space-y-4">
       <div className="flex justify-between items-center bg-white p-4 rounded-xl border">
          <div className="flex gap-4">
             <Button variant={activeTab === 'pos' ? 'default' : 'ghost'} onClick={() => setActiveTab('pos')}><LayoutDashboard className="w-4 h-4 mr-2"/> POS</Button>
             <Button variant={activeTab === 'orders' ? 'default' : 'ghost'} onClick={() => setActiveTab('orders')}><FileText className="w-4 h-4 mr-2"/> Orders</Button>
             <Button variant={activeTab === 'reports' ? 'default' : 'ghost'} onClick={() => setActiveTab('reports')}><Banknote className="w-4 h-4 mr-2"/> Reports</Button>
          </div>
          <div className="font-bold text-slate-700">Cashier: {user?.full_name}</div>
       </div>

       <div className="flex-1 overflow-hidden">
          {activeTab === 'pos' && <POSView />}
          {activeTab === 'reports' && (
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card><CardHeader><CardTitle>Daily Sales</CardTitle></CardHeader><CardContent className="text-3xl font-bold">1,250,000 IQD</CardContent></Card>
                <Card><CardHeader><CardTitle>Orders Count</CardTitle></CardHeader><CardContent className="text-3xl font-bold">45</CardContent></Card>
                <Card><CardHeader><CardTitle>Cash in Drawer</CardTitle></CardHeader><CardContent className="text-3xl font-bold">850,000 IQD</CardContent></Card>
             </div>
          )}
          {activeTab === 'orders' && (
             <div className="bg-white rounded-xl border p-8 text-center text-slate-500">
                <FileText className="w-12 h-12 mx-auto mb-4 opacity-30"/>
                <p>Order history view coming soon.</p>
             </div>
          )}
       </div>
    </div>
  );
};

export default CashierDashboard;
