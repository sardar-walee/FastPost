
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ShoppingBag, Car, Plane, Utensils, User, LayoutDashboard, Globe, LogOut, Newspaper, Menu, X, Settings, ChevronRight, Bell, Search, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import NotificationCenter from '@/components/NotificationCenter';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';

const Header = ({ 
  view, 
  setView, 
  cartCount, 
  currentSection, 
  setCurrentSection,
  onLoginClick,
  onLogoutClick,
  isAuthenticated,
  userRole,
  user
}) => {
  const { t, i18n } = useTranslation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    const dir = ['ar', 'ur', 'ckb', 'fa'].includes(lng) ? 'rtl' : 'ltr';
    document.dir = dir;
    document.documentElement.lang = lng;
  };

  const handleMobileLogout = () => {
    setIsMobileMenuOpen(false);
    onLogoutClick();
  };

  const getDashboardLabel = () => {
    switch(userRole) {
      case 'admin': return t('admin_panel');
      case 'restaurant_owner': return t('restaurant_mgmt');
      case 'umrah_company': return t('agency_portal');
      case 'car_dealer': return t('dealer_hub');
      default: return t('dashboard');
    }
  };

  const MobileMenu = () => (
    <AnimatePresence>
      {isMobileMenuOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm md:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          />

          <motion.div
            initial={{ x: document.dir === 'rtl' ? '100%' : '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: document.dir === 'rtl' ? '100%' : '-100%' }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={`fixed inset-y-0 ${document.dir === 'rtl' ? 'right-0' : 'left-0'} z-[60] w-[85vw] max-w-sm bg-white dark:bg-slate-900 shadow-2xl md:hidden flex flex-col`}
          >
            <div className="flex justify-between items-center p-6 bg-gradient-to-r from-indigo-600 to-indigo-800 text-white">
                <div className="flex items-center gap-3">
                   {user?.avatar_url ? (
                       <img src={user.avatar_url} alt="Profile" className="w-12 h-12 rounded-full border-2 border-white/50 shadow-md object-cover" />
                   ) : (
                       <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-full flex items-center justify-center border-2 border-white/30">
                           <User className="w-6 h-6 text-white" />
                       </div>
                   )}
                   <div>
                       <h3 className="font-bold text-lg leading-tight truncate max-w-[150px]">{isAuthenticated ? user?.full_name : t('welcome')}</h3>
                       <p className="text-indigo-100 text-xs truncate max-w-[150px]">{isAuthenticated ? user?.email : t('slogan')}</p>
                   </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(false)} className="text-white hover:bg-white/20 hover:text-white rounded-full">
                    <X className="w-6 h-6" />
                </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-4 py-2 mt-2">{t('menu')}</div>
                
                {[
                  { id: 'feed', icon: Home, label: t('feed'), color: 'text-indigo-500', bg: 'bg-indigo-50' },
                  { id: 'food', icon: Utensils, label: t('food'), color: 'text-emerald-500', bg: 'bg-emerald-50' },
                  { id: 'umrah', icon: Plane, label: t('umrah'), color: 'text-amber-500', bg: 'bg-amber-50' },
                  { id: 'cars', icon: Car, label: t('autos'), color: 'text-blue-500', bg: 'bg-blue-50' },
                ].map((item) => (
                   <Button 
                      key={item.id}
                      variant="ghost" 
                      className={`justify-between w-full h-auto py-3 px-4 rounded-xl group hover:bg-slate-50 transition-all ${currentSection === item.id ? 'bg-indigo-50 shadow-sm border border-indigo-100' : ''}`}
                      onClick={() => { setCurrentSection(item.id); setIsMobileMenuOpen(false); }}
                   >
                      <div className="flex items-center gap-4">
                         <div className={`p-2.5 rounded-lg ${currentSection === item.id ? 'bg-white shadow-sm' : item.bg} group-hover:scale-110 transition-transform`}>
                            <item.icon className={`w-5 h-5 ${item.color}`} />
                         </div>
                         <span className={`font-semibold text-base ${currentSection === item.id ? 'text-indigo-900' : 'text-slate-700'}`}>{item.label}</span>
                      </div>
                      <ChevronRight className={`w-4 h-4 ${currentSection === item.id ? 'text-indigo-400' : 'text-slate-300'}`} />
                   </Button>
                ))}

                <div className="border-t border-slate-100 my-4"></div>
                
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-4 py-2">{t('account')}</div>

                {isAuthenticated ? (
                    <>
                       <Button variant="ghost" className="justify-start w-full py-3 px-4 gap-3 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl" onClick={() => { setView('dashboard'); setIsMobileMenuOpen(false); }}>
                           <LayoutDashboard className="w-5 h-5" /> {t('dashboard')}
                       </Button>
                       <Button variant="ghost" className="justify-start w-full py-3 px-4 gap-3 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl" onClick={() => { window.location.hash = '#settings'; setIsMobileMenuOpen(false); }}>
                           <Settings className="w-5 h-5" /> {t('settings')}
                       </Button>
                       <Button variant="ghost" className="justify-start w-full py-3 px-4 gap-3 text-red-500 hover:bg-red-50 hover:text-red-600 rounded-xl" onClick={handleMobileLogout}>
                           <LogOut className="w-5 h-5" /> {t('logout')}
                       </Button>
                    </>
                ) : (
                    <Button className="w-full bg-indigo-600 text-white shadow-lg shadow-indigo-200 mt-4 h-12 rounded-xl text-lg font-bold" onClick={() => { onLoginClick(); setIsMobileMenuOpen(false); }}>
                        {t('login')}
                    </Button>
                )}
            </div>
            
            <div className="p-4 bg-slate-50 border-t border-slate-100">
               <div className="flex justify-between items-center mb-4 px-2">
                  <span className="text-sm font-medium text-slate-500">{t('language')}</span>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" className="h-8 gap-2 bg-white">
                        <Globe className="w-3.5 h-3.5" />
                        <span className="text-xs uppercase">{i18n.language}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40">
                      <DropdownMenuItem onClick={() => changeLanguage('ar')}>🇮🇶 العربية</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => changeLanguage('en')}>🇺🇸 English</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => changeLanguage('ckb')}>🇹🇯 کوردی</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
               </div>
               <p className="text-center text-xs text-slate-400 font-medium">FastPost Inc. © 2024</p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );

  return (
    <header className="sticky top-0 z-40 w-full transition-all duration-300 bg-white/95 dark:bg-slate-900/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 border-b border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="container flex h-16 md:h-20 items-center justify-between px-4">
        
        {/* Mobile Left: Menu + Logo */}
        <div className="flex items-center gap-3 md:hidden">
             <Button variant="ghost" size="icon" className="text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800" onClick={() => setIsMobileMenuOpen(true)}>
                 <Menu className="w-6 h-6" />
             </Button>
             <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-indigo-400">
               FastPost
             </span>
        </div>

        {/* Desktop Logo + Nav */}
        <div className="hidden md:flex items-center gap-8">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => { setView('customer'); setCurrentSection('feed'); }}>
            <div className="bg-indigo-600 p-2 rounded-xl shadow-lg shadow-indigo-200 group-hover:scale-105 transition-transform duration-300">
              <ShoppingBag className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-slate-800 dark:text-white tracking-tight group-hover:text-indigo-600 transition-colors">
              FastPost
            </span>
          </div>

          <nav className="hidden lg:flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-full border border-slate-200 dark:border-slate-700">
             {[
               { id: 'feed', icon: Home, label: t('feed') },
               { id: 'food', icon: Utensils, label: t('food') },
               { id: 'umrah', icon: Plane, label: t('umrah') },
               { id: 'cars', icon: Car, label: t('autos') },
             ].map((item) => (
                <Button 
                  key={item.id}
                  variant="ghost"
                  onClick={() => { setCurrentSection(item.id); setView('customer'); }}
                  className={`
                    rounded-full px-5 h-9 text-sm font-medium transition-all duration-300
                    ${currentSection === item.id && view === 'customer' 
                       ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                       : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-700/50'}
                  `}
                >
                  <item.icon className={`w-4 h-4 mr-2 ${currentSection === item.id ? 'stroke-[2.5px]' : ''}`} />
                  {item.label}
                </Button>
             ))}
          </nav>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 md:gap-4">
          
          {/* Search - Expandable on mobile/desktop */}
          <div className={`relative transition-all duration-300 ${isSearchOpen ? 'w-full absolute left-0 top-0 h-full bg-white z-50 px-4 flex items-center md:static md:w-auto md:bg-transparent md:p-0' : 'w-auto'}`}>
             {isSearchOpen ? (
                 <div className="w-full flex items-center gap-2 md:w-64">
                    <Search className="w-5 h-5 text-slate-400 shrink-0" />
                    <Input autoFocus placeholder={t('search_placeholder') || "Search..."} className="border-0 focus-visible:ring-0 bg-transparent h-10 text-base shadow-none" onBlur={() => setIsSearchOpen(false)} />
                    <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(false)} className="md:hidden shrink-0">
                        <X className="w-5 h-5" />
                    </Button>
                 </div>
             ) : (
                 <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(true)} className="text-slate-500 hover:bg-slate-100 rounded-full">
                     <Search className="w-5 h-5" />
                 </Button>
             )}
          </div>

          {!isSearchOpen && (
            <>
              {/* Language Switcher */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="hidden md:flex text-slate-500 hover:bg-slate-100 rounded-full">
                    <Globe className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => changeLanguage('ar')}>🇮🇶 العربية</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => changeLanguage('ckb')}>🇹🇯 کوردی</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => changeLanguage('en')}>🇺🇸 English</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Mobile Cart Icon */}
              {(currentSection === 'food' || currentSection === 'feed') && view === 'customer' && (
                <div className="relative md:hidden">
                  <Button variant="ghost" size="icon" className="text-slate-700 hover:bg-slate-100 rounded-full">
                    <ShoppingBag className="w-6 h-6" />
                  </Button>
                  {cartCount > 0 && (
                    <span className="absolute top-0 right-0 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white ring-2 ring-white">
                      {cartCount}
                    </span>
                  )}
                </div>
              )}

              {isAuthenticated ? (
                <div className="flex items-center gap-2 md:gap-3">
                   <div className="hidden md:block">
                     <NotificationCenter user={user} />
                   </div>

                   {/* Desktop User Menu */}
                   <div className="hidden md:flex items-center gap-3 pl-2 border-l border-slate-200">
                      {user?.avatar_url ? (
                          <img src={user.avatar_url} alt="User" className="w-9 h-9 rounded-full border border-slate-200 object-cover cursor-pointer hover:ring-2 hover:ring-indigo-100 transition-all" />
                      ) : (
                          <div className="w-9 h-9 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold cursor-pointer">
                              {user?.full_name?.[0] || <User className="w-4 h-4"/>}
                          </div>
                      )}
                      
                      <div className="flex flex-col">
                          <Button 
                            variant="ghost"
                            size="sm"
                            onClick={() => setView(view === 'customer' ? 'dashboard' : 'customer')}
                            className="h-8 px-2 text-slate-700 font-medium hover:text-indigo-600 justify-start"
                          >
                            {view === 'customer' ? t('dashboard') : t('customer_view')}
                          </Button>
                          <span className="text-[10px] text-slate-400 px-2 leading-none uppercase font-bold tracking-wider">{userRole}</span>
                      </div>

                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full"
                        onClick={onLogoutClick}
                        title={t('logout')}
                      >
                        <LogOut className="w-4 h-4" />
                      </Button>
                   </div>
                   
                   {/* Mobile Notification Bell (only if auth) */}
                   <div className="md:hidden">
                      <NotificationCenter user={user} />
                   </div>
                </div>
              ) : (
                <Button onClick={onLoginClick} className="btn-primary hidden md:flex h-10 px-6 shadow-md">
                  {t('login')}
                </Button>
              )}
            </>
          )}
        </div>
      </div>
      <MobileMenu />
    </header>
  );
};

export default Header;
