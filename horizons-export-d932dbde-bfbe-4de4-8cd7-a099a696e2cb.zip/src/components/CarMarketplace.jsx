
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Car, Fuel, Gauge, MapPin, Search, Filter, Plus, BarChart2, DollarSign, Calendar, 
  Users, FileText, Settings, CheckCircle, XCircle, ArrowRight, TrendingUp, Activity, 
  PieChart, Shield, Download, Printer, Share2, Bell, CreditCard, Briefcase, 
  LayoutDashboard, List, Grid, Image as ImageIcon, Video, ScrollText as Tooltip, 
  AlertTriangle, Check, Camera, Eye, Trash2, RotateCw, Upload, Home as HomeIcon,
  FileCheck, History, Heart, MessageCircle, ShoppingCart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';

import { supabase } from '@/supabaseClient';
import CarListingDetailModal from '@/components/modals/CarListingDetailModal';
import { CarCard } from '@/components/ServiceCards';
import WalletSection from '@/components/WalletSection';

// --- IMAGE UPLOAD COMPONENT ---
const ImageUpload = ({ images, onChange, label = "Upload Images", multiple = true, accept = "image/*" }) => {
    const fileInputRef = useRef(null);

    const handleFileChange = (e) => {
        const files = Array.from(e.target.files);
        processFiles(files);
    };

    const processFiles = (files) => {
        const newImages = files.map(file => ({
            id: Math.random().toString(36).substr(2, 9),
            file,
            url: URL.createObjectURL(file), // Create blob URL for preview
            name: file.name,
            type: file.type
        }));
        
        if (multiple) {
            onChange([...images, ...newImages]);
        } else {
            onChange(newImages.slice(0, 1)); // Replace if single
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        const files = Array.from(e.dataTransfer.files);
        processFiles(files);
    };

    const removeImage = (id) => {
        onChange(images.filter(img => img.id !== id));
    };

    return (
        <div className="space-y-3">
            <Label>{label}</Label>
            <div 
                className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:bg-slate-50 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
            >
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    multiple={multiple} 
                    accept={accept}
                    onChange={handleFileChange}
                />
                <div className="flex flex-col items-center gap-2 text-slate-500">
                    <div className="bg-indigo-50 p-3 rounded-full text-indigo-600">
                        <Upload className="w-6 h-6" />
                    </div>
                    <p className="font-medium text-sm">Click to upload or drag & drop</p>
                    <p className="text-xs text-slate-400">Supports Images & PDF (max 10MB)</p>
                </div>
            </div>

            {images.length > 0 && (
                <div className="grid grid-cols-3 md:grid-cols-4 gap-3 mt-4">
                    {images.map((img, index) => (
                        <div key={img.id} className="relative aspect-square group rounded-lg overflow-hidden border bg-slate-100 flex items-center justify-center">
                            {img.type?.includes('pdf') ? (
                                <div className="flex flex-col items-center text-slate-500 p-2 text-center">
                                    <FileText className="w-8 h-8 mb-1" />
                                    <span className="text-[10px] break-all line-clamp-2">{img.name}</span>
                                </div>
                            ) : (
                                <img src={img.url || img} alt="preview" className="w-full h-full object-cover" />
                            )}
                            
                            <button 
                                onClick={(e) => { e.stopPropagation(); removeImage(img.id); }}
                                type="button"
                                className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                            >
                                <XCircle className="w-4 h-4" />
                            </button>
                            {index === 0 && multiple && accept.includes('image') && <span className="absolute bottom-1 left-1 bg-black/60 text-white text-[10px] px-1.5 rounded">Main</span>}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};


// --- ADD VEHICLE FORM COMPONENT (WIZARD STYLE) ---
const AddVehicleForm = ({ user, onClose, onSuccess }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const totalSteps = 4;
  
  // State for file objects
  const [uploadedImages, setUploadedImages] = useState([]);
  const [damageImages, setDamageImages] = useState([]);
  const [serviceRecords, setServiceRecords] = useState([]);
  const [historyReport, setHistoryReport] = useState([]);

  const [formData, setFormData] = useState({
    make: '', model: '', year: new Date().getFullYear(), price: '', mileage: '',
    condition: 'Used - Good', color: '', transmission: 'Automatic', fuel_type: 'Petrol',
    body_type: 'Sedan', description: '', engine_specs: '', damage_assessment: 'Not Messed',
    features: [], defects: [], images: [], photo_categories: {}, service_history: {}
  });

  const [newDefect, setNewDefect] = useState({ description: '', severity: 'minor' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    // Validate
    if (!formData.make || !formData.model || !formData.price) {
        toast({ variant: "destructive", title: "Missing Information", description: "Please fill in Make, Model and Price." });
        return;
    }

    setLoading(true);
    try {
      // In a real scenario, we would upload `uploadedImages` to Supabase Storage here and get URLs.
      // For this implementation, we will use the blob URLs locally to simulate success.
      
      const finalImageUrls = uploadedImages.map(img => img.url); 
      const damageImageUrls = damageImages.map(img => img.url);
      const serviceRecordUrls = serviceRecords.map(img => ({ name: img.name, url: img.url }));
      const historyReportUrl = historyReport.length > 0 ? historyReport[0].url : null;

      // Create car record
      const { error } = await supabase.from('cars').insert({
        seller_id: user.id,
        ...formData,
        price: parseFloat(formData.price),
        mileage: parseInt(formData.mileage),
        year: parseInt(formData.year),
        location: user.location || 'Baghdad',
        availability_status: 'available',
        images: finalImageUrls,
        photo_categories: { ...formData.photo_categories, damage: damageImageUrls },
        service_history: { 
            records: serviceRecordUrls, 
            history_report: historyReportUrl,
            last_service_date: new Date().toISOString() 
        }
      });

      if (error) throw error;

      toast({ title: "Success", description: "Vehicle listed successfully!" });
      onSuccess();
      onClose();
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const renderStep1_Details = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label>Make (Brand) <span className="text-red-500">*</span></Label>
                <Input name="make" placeholder="e.g. Toyota" value={formData.make} onChange={handleChange} />
            </div>
            <div className="space-y-2">
                <Label>Model <span className="text-red-500">*</span></Label>
                <Input name="model" placeholder="e.g. Camry" value={formData.model} onChange={handleChange} />
            </div>
            <div className="space-y-2">
                <Label>Year</Label>
                <Input name="year" type="number" value={formData.year} onChange={handleChange} />
            </div>
            <div className="space-y-2">
                <Label>Color</Label>
                <Input name="color" placeholder="e.g. White Pearl" value={formData.color} onChange={handleChange} />
            </div>
            <div className="space-y-2">
                <Label>Body Type</Label>
                <Select value={formData.body_type} onValueChange={(val) => setFormData(prev => ({...prev, body_type: val}))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Sedan">Sedan</SelectItem>
                        <SelectItem value="SUV">SUV</SelectItem>
                        <SelectItem value="Truck">Truck</SelectItem>
                        <SelectItem value="Coupe">Coupe</SelectItem>
                        <SelectItem value="Hatchback">Hatchback</SelectItem>
                        <SelectItem value="Van">Van</SelectItem>
                    </SelectContent>
                </Select>
            </div>
             <div className="space-y-2">
                <Label>Transmission</Label>
                <Select value={formData.transmission} onValueChange={(val) => setFormData(prev => ({...prev, transmission: val}))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Automatic">Automatic</SelectItem>
                        <SelectItem value="Manual">Manual</SelectItem>
                        <SelectItem value="CVT">CVT</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
             <div className="space-y-2">
                <Label>Engine Specs</Label>
                <Input name="engine_specs" placeholder="e.g. V6 3.5L" value={formData.engine_specs} onChange={handleChange} />
            </div>
            <div className="space-y-2">
                <Label>Fuel Type</Label>
                <Select value={formData.fuel_type} onValueChange={(val) => setFormData(prev => ({...prev, fuel_type: val}))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Petrol">Petrol</SelectItem>
                        <SelectItem value="Diesel">Diesel</SelectItem>
                        <SelectItem value="Hybrid">Hybrid</SelectItem>
                        <SelectItem value="Electric">Electric</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        </div>
    </div>
  );

  const renderStep2_Condition = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
        <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label>Mileage (km) <span className="text-red-500">*</span></Label>
                <Input name="mileage" type="number" placeholder="0" value={formData.mileage} onChange={handleChange} />
            </div>
            <div className="space-y-2">
                <Label>Price (IQD) <span className="text-red-500">*</span></Label>
                <Input name="price" type="number" placeholder="0" value={formData.price} onChange={handleChange} />
            </div>
        </div>

        <div className="space-y-4 border p-4 rounded-xl bg-slate-50">
            <Label className="text-base font-bold flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                Damage Assessment
            </Label>
            <div className="flex gap-6">
                <label className="flex items-center gap-2 cursor-pointer p-3 bg-white border rounded-lg hover:border-indigo-500 w-full transition-all">
                    <input type="radio" name="damage_assessment" value="Not Messed" checked={formData.damage_assessment === 'Not Messed'} onChange={handleChange} className="accent-indigo-600 w-4 h-4"/>
                    <span className="font-medium">Not Messed (Clean)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer p-3 bg-white border rounded-lg hover:border-red-500 w-full transition-all">
                    <input type="radio" name="damage_assessment" value="Messed" checked={formData.damage_assessment === 'Messed'} onChange={handleChange} className="accent-red-600 w-4 h-4"/>
                    <span className="font-medium text-red-600">Messed (Damaged)</span>
                </label>
            </div>
            
            {/* Conditional Damage Section */}
            {formData.damage_assessment === 'Messed' && (
                <div className="mt-4 animate-in fade-in slide-in-from-top-2 p-4 bg-red-50 border border-red-100 rounded-xl">
                    <h4 className="font-bold text-red-800 mb-2 text-sm">Damage Details</h4>
                    <ImageUpload 
                        images={damageImages} 
                        onChange={setDamageImages} 
                        label="Upload Damage Photos" 
                    />
                    <div className="mt-2">
                        <Label>Brief Description of Damage</Label>
                        <Textarea placeholder="e.g. Dent on rear bumper, scratch on left door..." className="mt-1" />
                    </div>
                </div>
            )}
        </div>

        <div className="space-y-2">
           <Label>Known Defects (if any)</Label>
           <div className="flex gap-2">
               <Input value={newDefect.description} onChange={(e) => setNewDefect(p => ({...p, description: e.target.value}))} placeholder="Defect description..." />
               <Select value={newDefect.severity} onValueChange={(v) => setNewDefect(p => ({...p, severity: v}))}>
                  <SelectTrigger className="w-[120px]"><SelectValue/></SelectTrigger>
                  <SelectContent>
                      <SelectItem value="minor">Minor</SelectItem>
                      <SelectItem value="major">Major</SelectItem>
                  </SelectContent>
               </Select>
               <Button type="button" onClick={() => { if(newDefect.description) { setFormData(p => ({...p, defects: [...p.defects, newDefect]})); setNewDefect({description:'', severity: 'minor'}); } }} variant="secondary">Add</Button>
           </div>
           <div className="space-y-1 mt-2">
               {formData.defects.map((d, i) => (
                   <div key={i} className="flex justify-between items-center p-2 bg-red-50 text-red-700 rounded text-sm border border-red-100">
                       <span><span className="font-bold uppercase text-xs mr-2">{d.severity}</span> {d.description}</span>
                       <XCircle className="w-4 h-4 cursor-pointer hover:text-red-900" onClick={() => setFormData(p => ({...p, defects: p.defects.filter((_, idx) => idx !== i)}))} />
                   </div>
               ))}
           </div>
        </div>
    </div>
  );

  const renderStep3_Documents = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
        <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl mb-4">
            <h4 className="font-bold text-blue-900 flex items-center gap-2"><FileCheck className="w-5 h-5"/> Documents & History</h4>
            <p className="text-sm text-blue-700">Adding service records increases buyer trust.</p>
        </div>

        <div className="space-y-4">
            <ImageUpload 
                images={historyReport} 
                onChange={setHistoryReport} 
                label="Vehicle History Report (PDF/Image)" 
                multiple={false}
                accept="image/*,application/pdf"
            />
            
            <ImageUpload 
                images={serviceRecords} 
                onChange={setServiceRecords} 
                label="Service Records & Maintenance Logs" 
                accept="image/*,application/pdf"
            />
        </div>
    </div>
  );

  const renderStep4_Photos = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
        <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl mb-4">
            <h4 className="font-bold text-indigo-900 flex items-center gap-2"><Camera className="w-5 h-5"/> Vehicle Gallery</h4>
            <p className="text-sm text-indigo-700">High quality photos increase sales chances by 40%.</p>
        </div>

        <ImageUpload 
            images={uploadedImages} 
            onChange={setUploadedImages} 
            label="Upload Vehicle Photos (Front, Back, Interior)" 
        />
        
        <div className="space-y-2 mt-4">
            <Label>Seller Notes / Description</Label>
            <Textarea 
                name="description" 
                rows={4} 
                placeholder="Describe the car's condition, history, features, etc." 
                value={formData.description} 
                onChange={handleChange} 
            />
        </div>
    </div>
  );

  return (
    <div className="py-4 h-full flex flex-col">
       {/* Wizard Progress */}
       <div className="mb-6 space-y-2">
           <Progress value={(step / totalSteps) * 100} className="h-2" />
           <div className="flex justify-between px-1">
               <span className={`text-xs font-bold ${step >= 1 ? 'text-indigo-600' : 'text-slate-400'}`}>1. Details</span>
               <span className={`text-xs font-bold ${step >= 2 ? 'text-indigo-600' : 'text-slate-400'}`}>2. Condition</span>
               <span className={`text-xs font-bold ${step >= 3 ? 'text-indigo-600' : 'text-slate-400'}`}>3. Docs</span>
               <span className={`text-xs font-bold ${step >= 4 ? 'text-indigo-600' : 'text-slate-400'}`}>4. Photos</span>
           </div>
       </div>
       
       <ScrollArea className="flex-1 px-1 -mx-1">
           {step === 1 && renderStep1_Details()}
           {step === 2 && renderStep2_Condition()}
           {step === 3 && renderStep3_Documents()}
           {step === 4 && renderStep4_Photos()}
       </ScrollArea>

       <div className="flex justify-between gap-2 pt-6 mt-auto border-t">
           <Button variant="outline" onClick={() => { if(step > 1) setStep(s => s-1); else onClose(); }}>
               {step === 1 ? 'Cancel' : 'Back'}
           </Button>
           
           {step < 4 ? (
               <Button onClick={() => setStep(s => s+1)} className="bg-indigo-600">Next Step <ArrowRight className="w-4 h-4 ml-2"/></Button>
           ) : (
               <Button onClick={handleSubmit} disabled={loading} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                   {loading ? 'Publishing...' : 'Publish Listing'}
               </Button>
           )}
       </div>
    </div>
  );
};

// --- MAIN MARKETPLACE COMPONENT ---
const CarMarketplace = ({ view = 'customer', listings = [], userLocation, user }) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filters
  const [filterStatus, setFilterStatus] = useState('all');
  const [priceRange, setPriceRange] = useState([0, 100000000]); // Max 100M IQD
  const [selectedMake, setSelectedMake] = useState('all');

  // Modal State
  const [selectedCar, setSelectedCar] = useState(null);
  const [isCarModalOpen, setIsCarModalOpen] = useState(false);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
  const [isAddCarOpen, setIsAddCarOpen] = useState(false);
  
  // Data State
  const [dealerInventory, setDealerInventory] = useState([]);
  const [publicListings, setPublicListings] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [compareList, setCompareList] = useState([]);
  const [dashboardTab, setDashboardTab] = useState('overview');
  const [isLoading, setIsLoading] = useState(false);
  const [favorites, setFavorites] = useState(new Set());

  // Initial Fetch
  useEffect(() => {
    if (view === 'dashboard' && user) {
        fetchDealerData();
    } else {
        fetchPublicListings();
    }
  }, [view, user]);

  const fetchDealerData = async () => {
     setIsLoading(true);
     try {
        const { data: cars } = await supabase
            .from('cars')
            .select('*')
            .eq('seller_id', user.id)
            .order('created_at', { ascending: false });
        if (cars) setDealerInventory(cars);

        const { data: bks } = await supabase
            .from('car_bookings')
            .select('*, cars(make, model)')
            .or(`seller_id.eq.${user.id},user_id.eq.${user.id}`)
            .order('booking_date', { ascending: true });
        if (bks) setBookings(bks);

     } catch (e) {
         console.error(e);
     } finally {
         setIsLoading(false);
     }
  };

  const fetchPublicListings = async () => {
      if (listings.length > 0) {
          setPublicListings(listings);
          return;
      }
      const { data } = await supabase
          .from('cars')
          .select('*')
          .eq('availability_status', 'available')
          .order('created_at', { ascending: false });
      if (data) setPublicListings(data);
  };

  const toggleFavorite = (id) => {
    setFavorites(prev => {
        const next = new Set(prev);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        return next;
    });
    // In real implementation, save to DB
    toast({ title: favorites.has(id) ? "Removed from wishlist" : "Added to wishlist" });
  };

  const toggleCompare = (car) => {
      setCompareList(prev => {
          if (prev.find(c => c.id === car.id)) return prev.filter(c => c.id !== car.id);
          if (prev.length >= 3) {
              toast({ variant: "destructive", title: "Limit Reached", description: "Max 3 cars for comparison." });
              return prev;
          }
          return [...prev, car];
      });
  };

  // --- FILTER LOGIC ---
  const filteredData = useMemo(() => {
      const source = view === 'dashboard' ? dealerInventory : publicListings;
      return source.filter(car => {
          const matchSearch = (car.make + ' ' + car.model + ' ' + car.year).toLowerCase().includes(searchTerm.toLowerCase());
          const matchStatus = filterStatus === 'all' || car.availability_status === filterStatus;
          const matchMake = selectedMake === 'all' || car.make === selectedMake;
          const matchPrice = (car.price || 0) >= priceRange[0] && (car.price || 0) <= priceRange[1];
          return matchSearch && matchStatus && matchMake && matchPrice;
      });
  }, [dealerInventory, publicListings, searchTerm, filterStatus, selectedMake, priceRange, view]);

  // --- RENDERERS ---

  const renderOverview = () => {
     const totalValue = dealerInventory.reduce((acc, car) => acc + (car.price || 0), 0);
     const soldCount = dealerInventory.filter(c => c.availability_status === 'sold').length;
     
     return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-indigo-600 to-indigo-800 text-white border-0">
                    <CardHeader className="pb-2"><CardTitle className="text-white/80 text-sm font-medium">Total Inventory Value</CardTitle></CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">${totalValue.toLocaleString()}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="pb-2"><CardTitle className="text-slate-500 text-sm font-medium">Active Listings</CardTitle></CardHeader>
                    <CardContent><div className="text-3xl font-bold text-slate-800">{dealerInventory.length - soldCount}</div></CardContent>
                </Card>
                <Card>
                    <CardHeader className="pb-2"><CardTitle className="text-slate-500 text-sm font-medium">Vehicles Sold</CardTitle></CardHeader>
                    <CardContent><div className="text-3xl font-bold text-emerald-600">{soldCount}</div></CardContent>
                </Card>
                <Card>
                    <CardHeader className="pb-2"><CardTitle className="text-slate-500 text-sm font-medium">Test Drives</CardTitle></CardHeader>
                    <CardContent><div className="text-3xl font-bold text-blue-600">{bookings.length}</div></CardContent>
                </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                    <CardHeader><CardTitle>Recent Listings</CardTitle></CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow><TableHead>Vehicle</TableHead><TableHead>Price</TableHead><TableHead>Status</TableHead></TableRow>
                            </TableHeader>
                            <TableBody>
                                {dealerInventory.slice(0, 5).map(car => (
                                    <TableRow key={car.id}>
                                        <TableCell className="font-medium">{car.year} {car.make} {car.model}</TableCell>
                                        <TableCell>${car.price?.toLocaleString()}</TableCell>
                                        <TableCell><Badge variant="outline">{car.availability_status}</Badge></TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </div>
     );
  };

  const renderInventory = () => (
      <div className="space-y-4">
          <div className="flex flex-col md:flex-row justify-between gap-4">
              <div className="flex gap-2 flex-1">
                  <div className="relative flex-1">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <Input placeholder="Search make, model..." className="pl-9" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                  </div>
              </div>
              <Dialog open={isAddCarOpen} onOpenChange={setIsAddCarOpen}>
                  <DialogTrigger asChild>
                      <Button className="bg-indigo-600 gap-2"><Plus className="w-4 h-4"/> Add Vehicle</Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl h-[90vh] overflow-hidden flex flex-col">
                      <DialogHeader><DialogTitle>Add New Vehicle</DialogTitle></DialogHeader>
                      <AddVehicleForm user={user} onClose={() => setIsAddCarOpen(false)} onSuccess={fetchDealerData} />
                  </DialogContent>
              </Dialog>
          </div>

          <div className="rounded-md border bg-white overflow-hidden">
              <ScrollArea className="w-full">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Vehicle</TableHead>
                            <TableHead>Stats</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredData.map(car => (
                            <TableRow key={car.id}>
                                <TableCell>
                                    <div className="flex items-center gap-3">
                                        <img src={car.images?.[0] || car.image_url || 'https://via.placeholder.com/60'} className="w-12 h-12 rounded object-cover bg-slate-100" />
                                        <div>
                                            <p className="font-bold text-slate-900">{car.make} {car.model}</p>
                                            <p className="text-xs text-slate-500">{car.year} • {car.damage_assessment === 'Messed' ? <span className="text-red-500 font-bold">DAMAGED</span> : 'Clean'}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="text-xs space-y-1">
                                        <div className="flex items-center gap-1"><Gauge className="w-3 h-3"/> {car.mileage}km</div>
                                    </div>
                                </TableCell>
                                <TableCell className="font-bold text-emerald-600">${car.price?.toLocaleString()}</TableCell>
                                <TableCell>
                                    <Badge variant={car.availability_status === 'available' ? 'default' : 'secondary'}>{car.availability_status}</Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                    <div className="flex justify-end gap-2">
                                        <Button size="icon" variant="ghost" onClick={() => { setSelectedCar(car); setIsCarModalOpen(true); }}><Settings className="w-4 h-4"/></Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
              </ScrollArea>
          </div>
      </div>
  );

  // --- DASHBOARD VIEW ---
  if (view === 'dashboard') {
      return (
          <div className="space-y-6">
              {/* Dashboard Breadcrumb/Nav */}
              <div className="flex justify-between items-center bg-white p-6 rounded-xl border shadow-sm">
                  <div className="flex items-center gap-4">
                      <Button variant="ghost" size="icon" className="md:hidden" onClick={() => {}}>
                         <HomeIcon className="w-5 h-5"/>
                      </Button>
                      <div>
                          <div className="flex items-center gap-2 text-sm text-slate-500 mb-1">
                              <span>Showroom</span>
                              <span>/</span>
                              <span className="font-medium text-slate-900 capitalize">{dashboardTab}</span>
                          </div>
                          <h2 className="text-2xl font-bold text-slate-900">Dashboard</h2>
                      </div>
                  </div>
                  <div className="flex gap-2">
                      <Button variant="outline" className="hidden md:flex" onClick={() => window.location.reload()}><HomeIcon className="w-4 h-4 mr-2"/> Return to Home</Button>
                      <Button variant="outline"><Settings className="w-4 h-4 mr-2"/> Settings</Button>
                  </div>
              </div>

              <Tabs value={dashboardTab} onValueChange={setDashboardTab} className="space-y-6">
                  <TabsList className="bg-white border p-1 h-auto flex justify-start gap-1 overflow-x-auto w-full md:w-auto scrollbar-hide">
                      <TabsTrigger value="overview" className="gap-2 px-4 py-2"><PieChart className="w-4 h-4"/> Overview</TabsTrigger>
                      <TabsTrigger value="inventory" className="gap-2 px-4 py-2"><Car className="w-4 h-4"/> Inventory</TabsTrigger>
                      <TabsTrigger value="bookings" className="gap-2 px-4 py-2"><Calendar className="w-4 h-4"/> Bookings</TabsTrigger>
                      <TabsTrigger value="finance" className="gap-2 px-4 py-2"><DollarSign className="w-4 h-4"/> Finance</TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview">{renderOverview()}</TabsContent>
                  <TabsContent value="inventory">{renderInventory()}</TabsContent>
                  <TabsContent value="finance"><WalletSection entityId={user?.id} entityType="user" /></TabsContent>
                  <TabsContent value="bookings">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {bookings.map(bk => (
                              <Card key={bk.id}>
                                  <CardHeader>
                                      <CardTitle className="text-base">{bk.type === 'test_drive' ? 'Test Drive' : 'Inspection'}</CardTitle>
                                      <CardDescription>{new Date(bk.booking_date).toDateString()} at {bk.booking_time}</CardDescription>
                                  </CardHeader>
                                  <CardContent>
                                      <p className="font-semibold">{bk.cars?.make} {bk.cars?.model}</p>
                                      <Badge className="mt-2" variant={bk.status === 'confirmed' ? 'default' : 'secondary'}>{bk.status}</Badge>
                                  </CardContent>
                              </Card>
                          ))}
                          {bookings.length === 0 && <p className="col-span-full text-center py-10 text-slate-500">No bookings yet.</p>}
                      </div>
                  </TabsContent>
              </Tabs>
          </div>
      );
  }

  // --- PUBLIC CUSTOMER VIEW ---
  return (
    <div className="space-y-6 pb-24 md:pb-0">
        {/* HERO SECTION */}
        <div className="bg-slate-900 text-white rounded-3xl p-8 md:p-12 relative overflow-hidden shadow-2xl">
            <div className="relative z-10 max-w-2xl mx-auto text-center space-y-6">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                   <h1 className="text-3xl md:text-5xl font-bold mb-4">Find Your Perfect Drive</h1>
                   <p className="text-slate-400 text-lg">Browse thousands of certified cars from trusted dealers.</p>
                </motion.div>
                
                <div className="bg-white/10 backdrop-blur-md p-2 rounded-2xl flex gap-2 border border-white/20 shadow-lg">
                    <Search className="w-6 h-6 ml-3 self-center text-slate-300" />
                    <input 
                        className="flex-1 bg-transparent border-none outline-none text-white placeholder:text-slate-400"
                        placeholder="Search make, model, or year..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <Button className="bg-white text-slate-900 hover:bg-slate-100">Search</Button>
                </div>
            </div>
            {/* Decorative BG */}
            <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-50 z-0"></div>
            <Car className="absolute -right-10 -bottom-10 w-80 h-80 text-white/5 rotate-12" />
        </div>

        {/* MAIN CONTENT GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* SIDEBAR FILTERS */}
            <div className="lg:col-span-1 space-y-6">
                <div className="bg-white p-6 rounded-2xl border shadow-sm space-y-6 sticky top-24">
                    <div className="flex justify-between items-center">
                        <h3 className="font-bold flex items-center gap-2"><Filter className="w-4 h-4"/> Filters</h3>
                        <Button variant="ghost" size="sm" className="text-xs text-slate-500" onClick={() => {setPriceRange([0, 100000000]); setSelectedMake('all'); setSearchTerm('');}}>Reset</Button>
                    </div>
                    
                    <div className="space-y-3">
                        <Label>Price Range (IQD)</Label>
                        <Slider value={priceRange} min={0} max={100000000} step={1000000} onValueChange={setPriceRange} />
                        <div className="flex justify-between text-xs text-slate-500">
                            <span>${priceRange[0].toLocaleString()}</span>
                            <span>${priceRange[1].toLocaleString()}</span>
                        </div>
                    </div>

                    <div className="space-y-3">
                        <Label>Make</Label>
                        <Select value={selectedMake} onValueChange={setSelectedMake}>
                            <SelectTrigger><SelectValue placeholder="All Makes" /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Makes</SelectItem>
                                <SelectItem value="Toyota">Toyota</SelectItem>
                                <SelectItem value="BMW">BMW</SelectItem>
                                <SelectItem value="Mercedes">Mercedes</SelectItem>
                                <SelectItem value="Hyundai">Hyundai</SelectItem>
                                <SelectItem value="Kia">Kia</SelectItem>
                                <SelectItem value="Ford">Ford</SelectItem>
                                <SelectItem value="Chevrolet">Chevrolet</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-3">
                        <Label>Condition</Label>
                         <Select defaultValue="all">
                            <SelectTrigger><SelectValue placeholder="All Conditions" /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Conditions</SelectItem>
                                <SelectItem value="new">New</SelectItem>
                                <SelectItem value="used">Used</SelectItem>
                                <SelectItem value="damaged">Damaged / Messed</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>
            </div>

            {/* LISTINGS GRID */}
            <div className="lg:col-span-3 space-y-6">
                <div className="flex justify-between items-center">
                    <p className="text-slate-500 font-medium">{filteredData.length} vehicles found</p>
                    <div className="flex items-center gap-2">
                         <Select defaultValue="newest">
                            <SelectTrigger className="w-[180px]"><SelectValue placeholder="Sort By" /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="newest">Newest Listed</SelectItem>
                                <SelectItem value="price_asc">Price: Low to High</SelectItem>
                                <SelectItem value="price_desc">Price: High to Low</SelectItem>
                                <SelectItem value="mileage_asc">Mileage: Low to High</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredData.map(car => (
                        <div key={car.id} className="relative group">
                            <CarCard 
                                data={car} 
                                onAction={(c) => { setSelectedCar(c); setIsCarModalOpen(true); }}
                                onFavorite={() => toggleFavorite(car.id)}
                            />
                            {/* Comparison and Favorite Badges/Buttons */}
                            <div className="absolute top-2 right-2 flex flex-col gap-2">
                                <Button 
                                    size="icon" 
                                    variant="secondary" 
                                    className={`rounded-full w-8 h-8 shadow-sm ${compareList.find(c => c.id === car.id) ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-white/80 backdrop-blur'}`}
                                    onClick={(e) => { e.stopPropagation(); toggleCompare(car); }}
                                    title="Compare"
                                >
                                    <Activity className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    ))}
                    {filteredData.length === 0 && (
                        <div className="col-span-full py-20 text-center border-2 border-dashed rounded-3xl bg-slate-50">
                            <Car className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                            <h3 className="text-xl font-bold text-slate-700">No vehicles found</h3>
                            <p className="text-slate-500 mt-2">Try adjusting your filters or search query.</p>
                            <Button variant="outline" className="mt-4" onClick={() => { setSearchTerm(''); setPriceRange([0, 100000000]); setSelectedMake('all'); }}>Clear Filters</Button>
                        </div>
                    )}
                </div>
            </div>
        </div>

        {/* COMPARISON BAR */}
        <AnimatePresence>
            {compareList.length > 0 && (
                <motion.div 
                    initial={{ y: 100, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 100, opacity: 0 }}
                    className="fixed bottom-24 md:bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white p-4 rounded-2xl shadow-2xl flex items-center gap-6 w-[90%] max-w-2xl border border-slate-700 backdrop-blur-md bg-slate-900/90"
                >
                    <div className="flex-1 flex gap-3 overflow-x-auto">
                        {compareList.map(c => (
                            <div key={c.id} className="relative group shrink-0">
                                <img src={c.image_url || 'https://via.placeholder.com/60'} className="w-12 h-12 rounded-lg object-cover border border-slate-600" />
                                <button onClick={() => toggleCompare(c)} className="absolute -top-2 -right-2 bg-red-500 rounded-full p-1 shadow-sm"><XCircle className="w-3 h-3 text-white"/></button>
                            </div>
                        ))}
                    </div>
                    <Button onClick={() => setIsCompareModalOpen(true)} disabled={compareList.length < 2} className="bg-indigo-600 whitespace-nowrap">
                        Compare ({compareList.length})
                    </Button>
                </motion.div>
            )}
        </AnimatePresence>

        {/* MODALS */}
        <CarListingDetailModal 
            isOpen={isCarModalOpen} 
            onClose={() => setIsCarModalOpen(false)} 
            listing={selectedCar} 
            mode="customer"
            user={user}
        />

        <Dialog open={isCompareModalOpen} onOpenChange={setIsCompareModalOpen}>
            <DialogContent className="max-w-5xl h-[80vh] flex flex-col">
                <DialogHeader><DialogTitle>Vehicle Comparison</DialogTitle></DialogHeader>
                <ScrollArea className="flex-1">
                    <div className="grid grid-cols-4 gap-4 p-4 min-w-[800px]">
                         <div className="space-y-4 pt-32 font-medium text-slate-500">
                             <div className="h-8 border-b">Price</div>
                             <div className="h-8 border-b">Mileage</div>
                             <div className="h-8 border-b">Year</div>
                             <div className="h-8 border-b">Transmission</div>
                             <div className="h-8 border-b">Fuel Type</div>
                             <div className="h-8 border-b">Damage</div>
                         </div>
                         {compareList.map(car => (
                             <div key={car.id} className="space-y-4 text-center">
                                 <div className="h-32 flex flex-col items-center justify-end pb-2">
                                     <img src={car.image_url} className="w-32 h-20 object-cover rounded-lg mb-2" />
                                     <p className="font-bold text-sm truncate w-full">{car.make} {car.model}</p>
                                 </div>
                                 <div className="h-8 border-b flex items-center justify-center font-bold text-emerald-600">${car.price?.toLocaleString()}</div>
                                 <div className="h-8 border-b flex items-center justify-center">{car.mileage} km</div>
                                 <div className="h-8 border-b flex items-center justify-center">{car.year}</div>
                                 <div className="h-8 border-b flex items-center justify-center">{car.transmission}</div>
                                 <div className="h-8 border-b flex items-center justify-center">{car.fuel_type}</div>
                                 <div className="h-8 border-b flex items-center justify-center font-bold text-red-500">{car.damage_assessment === 'Messed' ? 'Yes' : 'No'}</div>
                             </div>
                         ))}
                    </div>
                </ScrollArea>
            </DialogContent>
        </Dialog>
    </div>
  );
};

export default CarMarketplace;
