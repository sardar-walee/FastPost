
import React from 'react';
import { 
  Users, Utensils, Plane, Car, 
  ShoppingBag, Activity, FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTranslation } from 'react-i18next';

// Sub-components
import AdminOverview from '@/components/admin/AdminOverview';
import AdminUsers from '@/components/admin/AdminUsers';
import AdminServices from '@/components/admin/AdminServices';
import AdminOrders from '@/components/admin/AdminOrders';
import SystemHealthDashboard from '@/components/admin/SystemHealthDashboard';

const AdminDashboard = ({ user, activeSection = 'overview' }) => {
  const { t } = useTranslation();

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <div>
                <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Admin Portal</h1>
                <p className="text-slate-500 mt-1">Master control panel for DaimPost</p>
            </div>
            <div className="flex gap-3">
               <span className="text-sm bg-indigo-50 text-indigo-700 px-4 py-2 rounded-xl font-bold self-center border border-indigo-100">
                  Super Admin
               </span>
               <span className="text-sm bg-slate-50 text-slate-600 px-4 py-2 rounded-xl font-medium self-center border border-slate-100">
                  v2.0.0
               </span>
            </div>
        </div>

        <Tabs defaultValue={activeSection} className="w-full space-y-6">
            <div className="sticky top-20 z-20 bg-slate-50/80 backdrop-blur-xl -mx-4 px-4 py-2 md:static md:p-0 md:bg-transparent">
                <TabsList className="bg-white border p-1.5 h-auto flex w-full md:w-auto min-w-max justify-start gap-1 rounded-2xl shadow-sm overflow-x-auto scrollbar-hide">
                    <TabsTrigger value="overview" className="gap-2 px-5 py-2.5 rounded-xl data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
                        <Activity className="w-4 h-4"/> Overview
                    </TabsTrigger>
                    <TabsTrigger value="users" className="gap-2 px-5 py-2.5 rounded-xl data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
                        <Users className="w-4 h-4"/> Users
                    </TabsTrigger>
                    <TabsTrigger value="services" className="gap-2 px-5 py-2.5 rounded-xl data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
                        <Utensils className="w-4 h-4"/> Services & Partners
                    </TabsTrigger>
                    <TabsTrigger value="finance" className="gap-2 px-5 py-2.5 rounded-xl data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
                        <ShoppingBag className="w-4 h-4"/> Orders & Finance
                    </TabsTrigger>
                    <TabsTrigger value="system_health" className="gap-2 px-5 py-2.5 rounded-xl data-[state=active]:bg-slate-900 data-[state=active]:text-white transition-all">
                        <Activity className="w-4 h-4"/> System Health
                    </TabsTrigger>
                </TabsList>
            </div>

            <div className="bg-transparent">
                <TabsContent value="overview" className="m-0 focus-visible:ring-0">
                    <AdminOverview />
                </TabsContent>
                
                <TabsContent value="users" className="m-0 focus-visible:ring-0">
                    <AdminUsers />
                </TabsContent>
                
                <TabsContent value="services" className="m-0 focus-visible:ring-0">
                    <AdminServices />
                </TabsContent>
                
                <TabsContent value="finance" className="m-0 focus-visible:ring-0">
                    <AdminOrders />
                </TabsContent>
                
                <TabsContent value="system_health" className="m-0 focus-visible:ring-0">
                    <SystemHealthDashboard />
                </TabsContent>
            </div>
        </Tabs>
    </div>
  );
};

export default AdminDashboard;
