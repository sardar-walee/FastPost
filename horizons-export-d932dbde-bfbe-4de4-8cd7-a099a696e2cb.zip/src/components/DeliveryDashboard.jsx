
import React, { useState, useEffect } from 'react';
import { 
  Truck, Navigation, CreditCard, History, MapPin, User, Phone, CheckCircle, Package, 
  Store, Search, Upload, FileText, AlertCircle, Clock, DollarSign
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/supabaseClient';
import IraqMap from '@/components/ui/IraqMap';

const DeliveryDashboard = ({ user }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [profile, setProfile] = useState(null);
  const [activeOrders, setActiveOrders] = useState([]);
  const [availableOrders, setAvailableOrders] = useState([]);
  const [myRestaurants, setMyRestaurants] = useState([]);
  const [nearbyRestaurants, setNearbyRestaurants] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const { toast } = useToast();

  useEffect(() => {
    if (user?.id) {
      fetchDriverProfile();
      fetchMyData();
    }
  }, [user]);

  const fetchDriverProfile = async () => {
    // Use maybeSingle() to avoid PGRST116 error when no profile exists
    const { data, error } = await supabase.from('driver_profiles').select('*').eq('user_id', user.id).maybeSingle();
    if (!data && !error) {
       // Create profile if doesn't exist
       const { data: newProfile } = await supabase.from('driver_profiles').insert([{ user_id: user.id }]).select().single();
       setProfile(newProfile);
    } else {
       setProfile(data);
    }
  };

  const fetchMyData = async () => {
    setLoading(true);
    try {
        // 1. Fetch My Restaurants (Approved associations)
        const { data: associations } = await supabase
            .from('restaurant_drivers')
            .select('restaurant:restaurants(*)')
            .eq('driver_id', user.id)
            .eq('status', 'active');
        
        const myRestaurantIds = associations?.map(a => a.restaurant.id) || [];
        setMyRestaurants(associations?.map(a => a.restaurant) || []);

        // 2. Fetch Available Orders (Ready for pickup from my restaurants)
        if (myRestaurantIds.length > 0) {
            const { data: orders } = await supabase
                .from('orders')
                .select('*, restaurants(name, location, lat, lng)')
                .in('restaurant_id', myRestaurantIds)
                .is('delivery_person_id', null)
                .in('status', ['ready', 'preparing']) // Can see orders preparing too, to be ready
                .order('created_at', { ascending: false });
            setAvailableOrders(orders || []);
        }

        // 3. Fetch Active Orders (Assigned to me)
        // Explicitly specify the relationship for users to avoid PGRST201 error
        const { data: myOrders } = await supabase
            .from('orders')
            .select('*, restaurants(name, phone, lat, lng), users:users!orders_user_id_fkey(full_name, phone)')
            .eq('delivery_person_id', user.id)
            .in('status', ['delivering', 'picked_up'])
            .order('created_at', { ascending: false });
        setActiveOrders(myOrders || []);

        // 4. Fetch Nearby Restaurants (To join)
        const { data: allRestaurants } = await supabase
            .from('restaurants')
            .select('*')
            .eq('is_online', true)
            .limit(20);
            
        // Filter out already joined
        setNearbyRestaurants(allRestaurants?.filter(r => !myRestaurantIds.includes(r.id)) || []);

        // 5. Fetch Pending Requests
        const { data: requests } = await supabase
            .from('driver_requests')
            .select('*, restaurants(name)')
            .eq('driver_id', user.id);
        setPendingRequests(requests || []);

    } catch (error) {
        console.error("Error fetching driver data:", error);
    } finally {
        setLoading(false);
    }
  };

  const toggleOnlineStatus = async () => {
    const newStatus = !profile?.is_online;
    const { error } = await supabase.from('driver_profiles').update({ is_online: newStatus }).eq('user_id', user.id);
    if (!error) {
        setProfile({ ...profile, is_online: newStatus });
        toast({ title: newStatus ? "You are Online" : "You are Offline", description: newStatus ? "You can now receive orders." : "You will not receive new orders." });
    }
  };

  const sendJoinRequest = async (restaurantId) => {
    const { error } = await supabase.from('driver_requests').insert({
        driver_id: user.id,
        restaurant_id: restaurantId,
        status: 'pending'
    });

    if (error) {
        toast({ variant: "destructive", title: "Error", description: error.message });
    } else {
        toast({ title: "Request Sent", description: "Wait for the restaurant to approve." });
        fetchMyData();
    }
  };

  const acceptOrder = async (orderId) => {
    const { error } = await supabase.from('orders').update({
        delivery_person_id: user.id,
        status: 'delivering' // Driver accepted
    }).eq('id', orderId);

    if (error) {
        toast({ variant: "destructive", title: "Error", description: "Could not accept order." });
    } else {
        toast({ title: "Order Accepted", description: "Please head to the restaurant." });
        fetchMyData();
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    const { error } = await supabase.from('orders').update({ status: newStatus }).eq('id', orderId);
    if (!error) {
        toast({ title: "Status Updated", description: `Order is now ${newStatus}` });
        fetchMyData();
    }
  };

  // --- Render Functions ---

  const renderOverview = () => (
    <div className="space-y-6 animate-in fade-in duration-500">
        <div className="flex justify-between items-center bg-white p-6 rounded-xl border shadow-sm">
           <div>
               <h1 className="text-2xl font-bold text-slate-800">Hello, {user?.full_name}</h1>
               <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
                   <Badge variant={profile?.is_online ? "default" : "secondary"} className={profile?.is_online ? "bg-emerald-500 hover:bg-emerald-600" : ""}>
                       {profile?.is_online ? "Online" : "Offline"}
                   </Badge>
                   <span>• {profile?.vehicle_model || "No Vehicle Set"}</span>
               </div>
           </div>
           <div className="flex flex-col items-end gap-2">
               <Button onClick={toggleOnlineStatus} variant={profile?.is_online ? "outline" : "default"} className={!profile?.is_online && "bg-emerald-600 hover:bg-emerald-700"}>
                   {profile?.is_online ? "Go Offline" : "Go Online"}
               </Button>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
                <CardContent className="p-6">
                    <p className="text-sm text-slate-500 font-medium">Total Earnings</p>
                    <h3 className="text-2xl font-bold text-slate-900 mt-2">{new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(user?.wallet_balance || 0)}</h3>
                </CardContent>
            </Card>
            <Card>
                <CardContent className="p-6">
                    <p className="text-sm text-slate-500 font-medium">Active Orders</p>
                    <h3 className="text-2xl font-bold text-indigo-600 mt-2">{activeOrders.length}</h3>
                </CardContent>
            </Card>
            <Card>
                <CardContent className="p-6">
                    <p className="text-sm text-slate-500 font-medium">My Restaurants</p>
                    <h3 className="text-2xl font-bold text-slate-900 mt-2">{myRestaurants.length}</h3>
                </CardContent>
            </Card>
            <Card>
                <CardContent className="p-6">
                    <p className="text-sm text-slate-500 font-medium">Rating</p>
                    <h3 className="text-2xl font-bold text-amber-500 mt-2 flex items-center gap-1">
                        {profile?.rating || 5.0} <span className="text-sm text-slate-400 font-normal">/ 5.0</span>
                    </h3>
                </CardContent>
            </Card>
        </div>

        {/* Active Order Actions */}
        {activeOrders.length > 0 && (
            <div className="space-y-4">
                <h3 className="font-bold text-lg">Current Deliveries</h3>
                {activeOrders.map(order => (
                    <Card key={order.id} className="border-l-4 border-l-blue-500 shadow-md">
                        <CardContent className="p-6">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h4 className="font-bold text-lg">{order.restaurants?.name}</h4>
                                    <p className="text-sm text-slate-500">Order #{order.id.slice(0,6)} • {order.items?.length || 1} Items</p>
                                </div>
                                <Badge>{order.status}</Badge>
                            </div>
                            
                            <div className="grid md:grid-cols-2 gap-4 mb-4">
                                <div className="p-3 bg-slate-50 rounded-lg space-y-2">
                                    <p className="text-xs font-bold text-slate-400 uppercase">Pickup</p>
                                    <div className="flex items-center gap-2">
                                        <Store className="w-4 h-4 text-indigo-500"/> 
                                        <span className="text-sm">{order.restaurants?.location || "Restaurant Location"}</span>
                                    </div>
                                    <Button size="sm" variant="outline" className="w-full text-xs h-7">Navigate to Restaurant</Button>
                                </div>
                                <div className="p-3 bg-slate-50 rounded-lg space-y-2">
                                    <p className="text-xs font-bold text-slate-400 uppercase">Dropoff</p>
                                    <div className="flex items-center gap-2">
                                        <User className="w-4 h-4 text-emerald-500"/> 
                                        <span className="text-sm font-medium">{order.users?.full_name}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <MapPin className="w-4 h-4 text-slate-400"/> 
                                        <span className="text-sm">{order.delivery_address}</span>
                                    </div>
                                    <Button size="sm" variant="outline" className="w-full text-xs h-7">Navigate to Customer</Button>
                                </div>
                            </div>

                            <div className="flex gap-3">
                                {order.status === 'delivering' && (
                                    <Button className="flex-1 bg-blue-600 hover:bg-blue-700" onClick={() => updateOrderStatus(order.id, 'picked_up')}>
                                        <Package className="w-4 h-4 mr-2"/> Confirm Pickup
                                    </Button>
                                )}
                                {order.status === 'picked_up' && (
                                    <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700" onClick={() => updateOrderStatus(order.id, 'delivered')}>
                                        <CheckCircle className="w-4 h-4 mr-2"/> Complete Delivery
                                    </Button>
                                )}
                                <Button variant="outline" size="icon"><Phone className="w-4 h-4"/></Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        )}

        {/* Map Section */}
        <div className="h-[300px] rounded-xl overflow-hidden border shadow-sm">
             <IraqMap 
                center={[profile?.current_lat || 33.3152, profile?.current_lng || 44.3661]}
                zoom={11}
                markers={[
                    { id: 'me', lat: profile?.current_lat || 33.3152, lng: profile?.current_lng || 44.3661, type: 'driver', title: 'You' },
                    ...availableOrders.map(o => ({
                        id: o.id,
                        lat: o.restaurants?.lat || 33.3,
                        lng: o.restaurants?.lng || 44.3,
                        type: 'restaurant',
                        title: `Order: ${o.restaurants?.name}`
                    }))
                ]}
                className="w-full h-full"
             />
        </div>
    </div>
  );

  const renderAvailableOrders = () => (
      <div className="space-y-4">
          <div className="flex justify-between items-center">
             <h2 className="text-xl font-bold">Available Jobs</h2>
             <Button size="sm" variant="outline" onClick={fetchMyData}>Refresh</Button>
          </div>
          
          {availableOrders.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 border border-dashed rounded-xl">
                  <Package className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                  <h3 className="font-medium text-slate-600">No Orders Available</h3>
                  <p className="text-sm text-slate-400">Wait for restaurants to post orders.</p>
              </div>
          ) : (
              <div className="grid gap-4">
                  {availableOrders.map(order => (
                      <Card key={order.id} className="hover:border-indigo-300 transition-colors">
                          <CardContent className="p-4 flex flex-col md:flex-row justify-between items-center gap-4">
                              <div className="flex items-center gap-4">
                                  <div className="bg-orange-100 p-3 rounded-full text-orange-600">
                                      <Store className="w-6 h-6"/>
                                  </div>
                                  <div>
                                      <h3 className="font-bold text-lg">{order.restaurants?.name}</h3>
                                      <p className="text-sm text-slate-500">{order.delivery_address}</p>
                                      <div className="flex gap-2 mt-1">
                                          <Badge variant="outline" className="bg-slate-50">{order.distance_km || 3.2} km</Badge>
                                          <Badge variant="outline" className="bg-green-50 text-green-700">Fee: {order.delivery_fee || 3000} IQD</Badge>
                                      </div>
                                  </div>
                              </div>
                              <Button onClick={() => acceptOrder(order.id)} className="w-full md:w-auto bg-emerald-600 hover:bg-emerald-700">
                                  Accept Order
                              </Button>
                          </CardContent>
                      </Card>
                  ))}
              </div>
          )}
      </div>
  );

  const renderPartners = () => (
      <div className="space-y-6">
          <div className="space-y-4">
             <h2 className="text-xl font-bold">My Restaurants</h2>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {myRestaurants.map(restaurant => (
                    <Card key={restaurant.id}>
                        <CardHeader className="pb-2">
                            <CardTitle className="text-base">{restaurant.name}</CardTitle>
                            <CardDescription className="flex items-center gap-1">
                                <MapPin className="w-3 h-3"/> {restaurant.location}
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-emerald-600 font-medium">Active Partner</span>
                                <Button size="sm" variant="ghost">View Details</Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
                {myRestaurants.length === 0 && (
                    <div className="col-span-full text-center p-6 bg-slate-50 rounded-lg text-slate-500 text-sm">
                        You haven't joined any restaurants yet.
                    </div>
                )}
             </div>
          </div>

          <div className="space-y-4">
             <h2 className="text-xl font-bold">Marketplace</h2>
             <p className="text-sm text-slate-500">Find restaurants near you and apply to join their fleet.</p>
             
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                 {nearbyRestaurants.map(restaurant => {
                     const existingRequest = pendingRequests.find(r => r.restaurant_id === restaurant.id);
                     return (
                        <Card key={restaurant.id} className="border-dashed hover:border-solid hover:border-indigo-200 transition-all">
                            <CardContent className="p-4 space-y-4">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center">
                                        <Store className="w-5 h-5 text-slate-500"/>
                                    </div>
                                    <div>
                                        <h3 className="font-bold">{restaurant.name}</h3>
                                        <p className="text-xs text-slate-500">{restaurant.location}</p>
                                    </div>
                                </div>
                                {existingRequest ? (
                                    <Button disabled variant="secondary" className="w-full">
                                        {existingRequest.status === 'pending' ? 'Request Sent' : existingRequest.status}
                                    </Button>
                                ) : (
                                    <Button onClick={() => sendJoinRequest(restaurant.id)} variant="outline" className="w-full hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200">
                                        Send Join Request
                                    </Button>
                                )}
                            </CardContent>
                        </Card>
                     );
                 })}
             </div>
          </div>
      </div>
  );

  return (
    <div className="max-w-6xl mx-auto pb-20 pt-4">
       <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
           <TabsList className="bg-white border rounded-xl p-1 mb-6 inline-flex overflow-x-auto max-w-full h-auto">
               <TabsTrigger value="overview" className="gap-2 px-6"><Truck className="w-4 h-4"/> Overview</TabsTrigger>
               <TabsTrigger value="jobs" className="gap-2 px-6"><Package className="w-4 h-4"/> Available Jobs</TabsTrigger>
               <TabsTrigger value="partners" className="gap-2 px-6"><Store className="w-4 h-4"/> Partners</TabsTrigger>
               <TabsTrigger value="earnings" className="gap-2 px-6"><DollarSign className="w-4 h-4"/> Earnings</TabsTrigger>
           </TabsList>
           
           <TabsContent value="overview">{renderOverview()}</TabsContent>
           <TabsContent value="jobs">{renderAvailableOrders()}</TabsContent>
           <TabsContent value="partners">{renderPartners()}</TabsContent>
           <TabsContent value="earnings">
                <div className="bg-white p-8 rounded-xl border shadow-sm text-center">
                    <DollarSign className="w-12 h-12 mx-auto text-emerald-500 mb-4 bg-emerald-100 p-2 rounded-full"/>
                    <h2 className="text-2xl font-bold mb-2">Earnings Dashboard</h2>
                    <p className="text-slate-500 mb-6">Detailed breakdown of your delivery fees and tips.</p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left max-w-2xl mx-auto">
                        <div className="bg-slate-50 p-4 rounded-lg">
                            <span className="text-xs text-slate-500 uppercase font-bold">Today</span>
                            <p className="text-xl font-bold text-slate-900">45,000 IQD</p>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-lg">
                            <span className="text-xs text-slate-500 uppercase font-bold">This Week</span>
                            <p className="text-xl font-bold text-slate-900">320,000 IQD</p>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-lg">
                            <span className="text-xs text-slate-500 uppercase font-bold">Total Balance</span>
                            <p className="text-xl font-bold text-emerald-600">{new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(user?.wallet_balance || 0)}</p>
                        </div>
                    </div>
                </div>
           </TabsContent>
       </Tabs>
    </div>
  );
};

export default DeliveryDashboard;
