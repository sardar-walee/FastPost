
import React, { useState, useEffect } from 'react';
import { Download, X, Share } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AnimatePresence, motion } from 'framer-motion';

const InstallPrompt = () => {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    // Check if iOS
    const isIosDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    setIsIOS(isIosDevice);

    // Listen for install prompt
    const handler = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      // Check if app is already installed
      if (!window.matchMedia('(display-mode: standalone)').matches) {
         // Delay showing prompt slightly
         setTimeout(() => setShowPrompt(true), 3000);
      }
    };

    window.addEventListener('beforeinstallprompt', handler);

    // Show iOS hint if not installed
    if (isIosDevice && !window.matchMedia('(display-mode: standalone)').matches) {
       setTimeout(() => setShowPrompt(true), 3000);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setShowPrompt(false);
    }
  };

  if (!showPrompt) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-20 md:bottom-6 left-4 right-4 z-[100] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-4 max-w-sm mx-auto"
      >
        <div className="flex items-start justify-between mb-2">
           <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg">
                 FP
              </div>
              <div>
                 <h3 className="font-bold text-slate-900 dark:text-white">Install FastPost</h3>
                 <p className="text-xs text-slate-500">Get the best experience with our app.</p>
              </div>
           </div>
           <button onClick={() => setShowPrompt(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
           </button>
        </div>

        {isIOS ? (
           <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg text-xs text-slate-600 dark:text-slate-300 mt-2 flex items-center gap-2">
              <span>Tap</span>
              <Share className="w-4 h-4" />
              <span>then select <strong>Add to Home Screen</strong></span>
           </div>
        ) : (
           <Button onClick={handleInstall} className="w-full mt-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-lg shadow-indigo-200">
              <Download className="w-4 h-4 mr-2" /> Install App
           </Button>
        )}
      </motion.div>
    </AnimatePresence>
  );
};

export default InstallPrompt;
