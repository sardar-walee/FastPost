
import React from 'react';
import { Crown } from 'lucide-react';

const LoyaltyCard = ({ points }) => {
  const getLevel = (p) => {
    if (p > 5000) return { name: 'Platinum', color: 'from-slate-700 to-slate-900', iconColor: 'text-slate-200' };
    if (p > 1000) return { name: 'Gold', color: 'from-yellow-400 to-amber-500', iconColor: 'text-yellow-100' };
    return { name: 'Silver', color: 'from-slate-300 to-slate-400', iconColor: 'text-white' };
  };

  const level = getLevel(points);

  return (
    <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${level.color} p-6 text-white shadow-xl`}>
      <div className="absolute -right-6 -top-6 h-32 w-32 rounded-full bg-white/10 blur-2xl"></div>
      <div className="relative z-10 flex justify-between items-start">
        <div>
          <p className="text-sm font-medium opacity-80">Loyalty Balance</p>
          <h3 className="text-3xl font-bold mt-1">{points.toLocaleString()} pts</h3>
        </div>
        <div className={`p-2 rounded-full bg-white/20 backdrop-blur-sm ${level.iconColor}`}>
           <Crown className="w-6 h-6" />
        </div>
      </div>
      <div className="mt-6">
        <div className="flex justify-between text-xs font-medium uppercase tracking-wider opacity-80 mb-1">
          <span>{level.name} Member</span>
          <span>FastPost Rewards</span>
        </div>
        <div className="h-1.5 w-full bg-black/20 rounded-full overflow-hidden">
          <div className="h-full bg-white/80 rounded-full" style={{ width: `${Math.min((points % 1000) / 10, 100)}%` }}></div>
        </div>
        <p className="text-[10px] mt-1 opacity-70">
           {1000 - (points % 1000)} points to next reward
        </p>
      </div>
    </div>
  );
};

export default LoyaltyCard;
