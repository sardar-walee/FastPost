
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const PrivacyPolicy = ({ onBack }) => {
  const { t } = useTranslation();
  
  return (
    <div className="max-w-4xl mx-auto p-6 bg-white dark:bg-slate-900 rounded-xl shadow-sm border mt-8 mb-24 text-slate-900 dark:text-slate-100">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" onClick={onBack} size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <h1 className="text-2xl font-bold">{t('privacy_policy')}</h1>
      </div>
      
      <div className="prose dark:prose-invert max-w-none space-y-4">
        <p><strong>Effective Date:</strong> {new Date().toLocaleDateString()}</p>
        
        <h3 className="text-lg font-bold">1. Introduction</h3>
        <p>{t('privacy_intro')}</p>
        
        <h3 className="text-lg font-bold">2. Data We Collect</h3>
        <p>{t('privacy_data_collection')}</p>
        <ul className="list-disc pl-5">
            <li><strong>Identity Data:</strong> Name, username, picture.</li>
            <li><strong>Contact Data:</strong> Email, phone, address.</li>
            <li><strong>Usage Data:</strong> Interactions, theme preferences, language settings.</li>
        </ul>

        <h3 className="text-lg font-bold">3. How We Use Your Data</h3>
        <p>{t('privacy_usage')}</p>
        <ul className="list-disc pl-5">
            <li>Processing orders and payments.</li>
            <li>Providing AI-driven recommendations.</li>
            <li>Improving app performance and security.</li>
        </ul>

        <h3 className="text-lg font-bold">4. Smart Notifications & AI</h3>
        <p>We use automated systems to analyze your order history to provide personalized food and product recommendations. You can opt-out of these in Settings.</p>

        <h3 className="text-lg font-bold">5. Contact Details</h3>
        <p>If you have any questions about this privacy policy, please contact us at info@fastpost.iq.</p>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
