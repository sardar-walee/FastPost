
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { 
  Home, ShoppingBag, Car, Plane, 
  Settings, LogOut, User, DollarSign, List,
  LayoutDashboard, CreditCard, Users, Store,
  FileText, Globe, Activity
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const Sidebar = ({ userRole, activeSection, onNavigate, isOpen, user }) => {
  const { t } = useTranslation();
  const { signOut } = useAuth();
  
  const handleLogout = async () => {
     await signOut();
     // Reset navigation to public feed
     onNavigate('feed');
  };

  const getMenuItems = () => {
    const common = [
      { id: 'feed', icon: Home, label: 'home' },
      { id: 'food', icon: ShoppingBag, label: 'food' },
      { id: 'cars', icon: Car, label: 'cars' },
      { id: 'umrah', icon: Plane, label: 'umrah' },
    ];

    if (userRole === 'restaurant_owner') {
      return [
        { id: 'dashboard', icon: LayoutDashboard, label: 'dashboard' },
        { id: 'orders', icon: List, label: 'orders' },
        { id: 'menu', icon: FileText, label: 'menu' },
        { id: 'settings', icon: Settings, label: 'settings' },
        ...common
      ];
    }
    
    if (userRole === 'admin') {
      return [
        { id: 'dashboard', icon: LayoutDashboard, label: 'dashboard' },
        { id: 'users', icon: Users, label: 'users' },
        { id: 'services', icon: Store, label: 'services' },
        { id: 'reports', icon: Activity, label: 'reports' },
        ...common
      ];
    }

    if (userRole === 'driver') {
        return [
            { id: 'dashboard', icon: LayoutDashboard, label: 'dashboard' },
            { id: 'earnings', icon: DollarSign, label: 'earnings' },
            { id: 'history', icon: List, label: 'history' },
            ...common
        ];
    }
    
    if (userRole === 'umrah_company') {
        return [
            { id: 'dashboard', icon: LayoutDashboard, label: 'dashboard' },
            { id: 'trips', icon: Plane, label: 'trips' },
            { id: 'finance', icon: DollarSign, label: 'finance' },
            ...common
        ];
    }

    if (userRole === 'car_dealer') {
        return [
            { id: 'dashboard', icon: LayoutDashboard, label: 'dashboard' },
            { id: 'inventory', icon: Car, label: 'inventory' },
            { id: 'sales', icon: DollarSign, label: 'sales' },
            ...common
        ];
    }

    return [
      ...common,
      { id: 'orders', icon: List, label: 'my_orders' },
      { id: 'favorites', icon: Store, label: 'favorites' },
      { id: 'wallet', icon: CreditCard, label: 'wallet' },
    ];
  };

  const menuItems = getMenuItems();

  return (
    <aside 
      className={`
        fixed top-0 z-40 h-screen bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-r border-slate-200/50 dark:border-slate-800 transition-all duration-500 ease-in-out
        ${isOpen ? 'w-72' : 'w-24'}
        ${document.dir === 'rtl' ? 'right-0 border-l border-r-0' : 'left-0'}
      `}
    >
      <div className="flex flex-col h-full py-6">
        <div className={`flex items-center ${isOpen ? 'justify-start px-8' : 'justify-center'} mb-10`}>
             <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/30">
                 <Globe className="text-white w-6 h-6" />
             </div>
             {isOpen && (
                 <motion.span 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300 ${document.dir === 'rtl' ? 'mr-4' : 'ml-4'}`}
                 >
                     DaimPost
                 </motion.span>
             )}
        </div>

        <nav className="flex-1 px-4 space-y-2 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => (
            <div key={item.id} className="relative">
                <Button
                  variant="ghost"
                  className={`
                    w-full h-12 relative group overflow-hidden transition-all duration-300
                    ${activeSection === item.id 
                        ? 'bg-gradient-to-r from-indigo-50 to-white text-indigo-700 dark:from-indigo-900/20 dark:to-transparent dark:text-indigo-300 shadow-sm' 
                        : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50/50 dark:hover:bg-slate-800/50'}
                    ${isOpen ? 'justify-start px-6 rounded-2xl' : 'justify-center px-0 rounded-2xl'}
                  `}
                  onClick={() => onNavigate(item.id)}
                >
                  <item.icon 
                    className={`
                        w-5 h-5 shrink-0 transition-transform duration-300 
                        ${activeSection === item.id ? 'scale-110' : 'group-hover:scale-110'}
                        ${isOpen ? (document.dir === 'rtl' ? 'ml-4' : 'mr-4') : ''}
                    `} 
                  />
                  
                  {isOpen && (
                      <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="font-medium text-sm">
                          {t(item.label)}
                      </motion.span>
                  )}
                  
                  {activeSection === item.id && (
                      <motion.div 
                        layoutId="sidebarActive"
                        className="absolute inset-y-0 left-0 w-1 bg-indigo-600 rounded-r-full"
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      />
                  )}
                </Button>
            </div>
          ))}
        </nav>

        <div className="px-4 mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
           {user ? (
               <>
                   <Button
                      variant={activeSection === 'profile' ? 'secondary' : 'ghost'}
                      className={`w-full justify-start h-12 ${isOpen ? 'px-4' : 'px-0 justify-center'}`}
                      onClick={() => onNavigate('profile')}
                    >
                      <User className={`w-5 h-5 ${isOpen ? (document.dir === 'rtl' ? 'ml-3' : 'mr-3') : ''}`} />
                      {isOpen && <span>{t('profile')}</span>}
                    </Button>

                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button
                                variant="ghost"
                                className={`w-full justify-start h-12 text-red-500 hover:text-red-600 hover:bg-red-50/50 dark:hover:bg-red-900/10 ${isOpen ? 'px-4' : 'px-0 justify-center'}`}
                            >
                                <LogOut className={`w-5 h-5 ${isOpen ? (document.dir === 'rtl' ? 'ml-3' : 'mr-3') : ''}`} />
                                {isOpen && <span>{t('logout')}</span>}
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>{t('logout_confirmation_title', 'Confirm Logout')}</AlertDialogTitle>
                                <AlertDialogDescription>
                                    {t('logout_confirmation_desc', 'Are you sure you want to log out?')}
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>{t('cancel')}</AlertDialogCancel>
                                <AlertDialogAction onClick={handleLogout} className="bg-red-600 hover:bg-red-700 text-white border-0">
                                    {t('logout')}
                                </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
               </>
           ) : (
                <div className={`${isOpen ? 'px-4' : 'text-center'} py-2`}>
                    {isOpen ? (
                        <p className="text-xs text-slate-400 text-center font-medium">Guest User</p>
                    ) : (
                         <User className="w-5 h-5 mx-auto text-slate-400" />
                    )}
                </div>
           )}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
