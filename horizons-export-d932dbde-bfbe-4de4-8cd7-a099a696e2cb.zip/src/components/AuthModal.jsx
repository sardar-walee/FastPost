
import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/supabaseClient';
import { IRAQI_GOVERNORATES } from '@/lib/constants';
import { 
  Facebook, Mail, Lock, User, Phone, MapPin, Building2, 
  ArrowRight, ArrowLeft, Loader2, CheckCircle, ShieldCheck, 
  Eye, EyeOff, Truck, AlertTriangle
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const AuthModal = ({ isOpen, onClose, onLoginSuccess }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { signIn, signUp } = useAuth();
  
  const [activeTab, setActiveTab] = useState('login');
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  // Signup Multi-Step State
  const [step, setStep] = useState(1);
  const [role, setRole] = useState('customer');

  // Form Data
  const [formData, setFormData] = useState({
    email: '', password: '', fullName: '', phone: '',
    businessName: '', businessType: '', location: '',
    confirmPassword: '', termsAccepted: false,
    vehicleType: ''
  });

  // Reset form when modal closes or opens
  useEffect(() => {
    if (!isOpen) {
        setTimeout(() => {
            resetForm();
        }, 300);
    }
  }, [isOpen]);

  const resetForm = () => {
    setStep(1);
    setRole('customer');
    setFormData({
        email: '', password: '', fullName: '', phone: '',
        businessName: '', businessType: '', location: '',
        confirmPassword: '', termsAccepted: false,
        vehicleType: ''
    });
    setIsLoading(false);
    setShowPassword(false);
    setEmailSent(false);
    setActiveTab('login');
  };

  // Handlers
  const handleInputChange = (e) => {
    const { id, value, type, checked } = e.target;
    setFormData(prev => ({
        ...prev,
        [id]: type === 'checkbox' ? checked : value
    }));
  };

  const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validatePhone = (phone) => {
    // Basic Iraqi phone validation (optional 07 or +9647 followed by 9 digits)
    return /^(\+964|0)?7[0-9]{9}$/.test(phone.replace(/\s/g, ''));
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
        toast({ variant: "destructive", title: "Error", description: "Please fill in all fields." });
        return;
    }

    setIsLoading(true);
    const { data, error } = await signIn(formData.email, formData.password);
    setIsLoading(false);

    if (!error && data?.session) {
        toast({ title: "Welcome back!", description: "Successfully logged in." });
        onLoginSuccess?.(data);
        onClose();
    } else if (error) {
        // Check for email confirmation error specifically
        const isEmailError = error.message?.toLowerCase().includes("email not confirmed") || 
                             error.code === "email_not_confirmed";
        
        if (isEmailError) {
            setEmailSent(true);
        }
    }
  };

  const handleSocialLogin = async (provider) => {
    try {
        const { error } = await supabase.auth.signInWithOAuth({
            provider,
            options: { redirectTo: window.location.origin }
        });
        if (error) throw error;
    } catch (error) {
        toast({ variant: "destructive", title: "Social Login Error", description: error.message });
    }
  };

  const validateStep = (currentStep) => {
     if (currentStep === 1) {
         if (!formData.fullName.trim()) return false;
         if (!validateEmail(formData.email)) return false;
         if (!validatePhone(formData.phone)) return false;
         return true;
     }
     if (currentStep === 2) {
         // Validation for Business Roles
         if (['restaurant_owner', 'umrah_company', 'car_dealer'].includes(role)) {
             return formData.businessName.trim() && formData.location;
         }
         // Validation for Driver
         if (role === 'driver') {
             return formData.vehicleType && formData.location;
         }
         // Customer skips step 2 usually, but if logic brings them here, auto-pass
         return true; 
     }
     if (currentStep === 3) {
         return formData.password && 
                formData.password.length >= 6 && 
                formData.password === formData.confirmPassword && 
                formData.termsAccepted;
     }
     return false;
  };

  const handleNextStep = () => {
     if (!validateStep(step)) {
         toast({ variant: "destructive", title: "Incomplete", description: "Please correct the errors before proceeding." });
         return;
     }
     
     // Skip business step for customer role
     if (step === 1 && role === 'customer') {
         setStep(3);
     } else {
         setStep(prev => prev + 1);
     }
  };

  const handleSignupSubmit = async () => {
     if (!validateStep(3)) {
         toast({ variant: "destructive", title: "Validation Error", description: "Please check password and terms." });
         return;
     }
     setIsLoading(true);

     const metaData = {
         full_name: formData.fullName,
         phone: formData.phone,
         role: role,
         business_name: formData.businessName,
         location: formData.location,
         vehicle_type: formData.vehicleType
     };

     const { data, error } = await signUp(formData.email, formData.password, {
         data: metaData
     });

     setIsLoading(false);

     if (!error) {
         if (data?.session) {
             // Auto logged in (Email confirmation might be off)
             toast({ title: "Account Created!", description: "Welcome to FastPost." });
             onClose();
         } else if (data?.user) {
             // User created but needs email verification
             setEmailSent(true);
         }
     }
  };

  // --- RENDER STEPS ---

  const renderStep1 = () => (
     <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
        <div className="space-y-2">
            <Label>I want to join as a...</Label>
            <Select value={role} onValueChange={setRole}>
                <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
                <SelectContent>
                    <SelectItem value="customer">👤 Customer (Order & Shop)</SelectItem>
                    <SelectItem value="restaurant_owner">🍽️ Restaurant Owner</SelectItem>
                    <SelectItem value="umrah_company">🕌 Umrah Office</SelectItem>
                    <SelectItem value="car_dealer">🚗 Car Dealer</SelectItem>
                    <SelectItem value="driver">🚚 Driver</SelectItem>
                </SelectContent>
            </Select>
        </div>
        <div className="space-y-2">
            <Label htmlFor="fullName">Full Name</Label>
            <div className="relative">
                <User className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                <Input id="fullName" className="pl-9" value={formData.fullName} onChange={handleInputChange} placeholder="John Doe" />
            </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                    <Mail className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                    <Input id="email" type="email" className="pl-9" value={formData.email} onChange={handleInputChange} placeholder="name@example.com" />
                </div>
            </div>
            <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <div className="relative">
                    <Phone className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                    <Input id="phone" className="pl-9" value={formData.phone} onChange={handleInputChange} placeholder="0770..." />
                </div>
            </div>
        </div>
     </motion.div>
  );

  const renderStep2 = () => (
     <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
        {role === 'driver' ? (
            <div className="bg-blue-50 p-3 rounded-lg flex items-center gap-3 text-blue-700 text-sm mb-2">
                <Truck className="w-5 h-5" />
                <span>Driver details for delivery validation.</span>
            </div>
        ) : (
            <div className="bg-indigo-50 p-3 rounded-lg flex items-center gap-3 text-indigo-700 text-sm mb-2">
                <Building2 className="w-5 h-5" />
                <span>Tell us about your business to get verified.</span>
            </div>
        )}

        {role !== 'driver' && (
            <div className="space-y-2">
                <Label htmlFor="businessName">Business Name</Label>
                <Input id="businessName" value={formData.businessName} onChange={handleInputChange} placeholder="e.g. Baghdad Grill" />
            </div>
        )}

        {role === 'driver' && (
            <div className="space-y-2">
                <Label htmlFor="vehicleType">Vehicle Type</Label>
                <Select value={formData.vehicleType} onValueChange={(val) => setFormData(prev => ({...prev, vehicleType: val}))}>
                    <SelectTrigger><SelectValue placeholder="Select Vehicle" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="motorcycle">Motorcycle</SelectItem>
                        <SelectItem value="car">Car / Sedan</SelectItem>
                        <SelectItem value="van">Van / Truck</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        )}

        <div className="space-y-2">
            <Label htmlFor="location">Main Location (City)</Label>
            <div className="relative">
                <MapPin className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                <Select value={formData.location} onValueChange={(val) => setFormData(prev => ({...prev, location: val}))}>
                    <SelectTrigger className="pl-9"><SelectValue placeholder="Select City" /></SelectTrigger>
                    <SelectContent>
                        {IRAQI_GOVERNORATES.map(gov => <SelectItem key={gov} value={gov}>{gov}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
        </div>
     </motion.div>
  );

  const renderStep3 = () => (
     <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
        <div className="space-y-2">
            <Label htmlFor="password">Create Password</Label>
            <div className="relative">
                <Lock className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                <Input 
                  id="password" 
                  type={showPassword ? "text" : "password"} 
                  className="pl-9 pr-10" 
                  value={formData.password} 
                  onChange={handleInputChange} 
                  placeholder="••••••••" 
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
            </div>
            {/* Password Strength Indicator */}
            {formData.password && (
                <div className="flex gap-1 h-1.5 mt-1">
                    <div className={`flex-1 rounded-full transition-colors ${formData.password.length > 0 ? 'bg-red-500' : 'bg-slate-200'}`}></div>
                    <div className={`flex-1 rounded-full transition-colors ${formData.password.length > 5 ? 'bg-yellow-500' : 'bg-slate-200'}`}></div>
                    <div className={`flex-1 rounded-full transition-colors ${formData.password.length > 8 ? 'bg-emerald-500' : 'bg-slate-200'}`}></div>
                </div>
            )}
            <p className="text-xs text-slate-400">Min 6 characters</p>
        </div>
        <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirm Password</Label>
            <div className="relative">
                <Lock className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                <Input 
                  id="confirmPassword" 
                  type={showPassword ? "text" : "password"} 
                  className="pl-9" 
                  value={formData.confirmPassword} 
                  onChange={handleInputChange} 
                  placeholder="••••••••" 
                />
            </div>
        </div>
        <div className="flex items-start space-x-2 pt-2">
            <Checkbox id="termsAccepted" checked={formData.termsAccepted} onCheckedChange={(checked) => setFormData(prev => ({...prev, termsAccepted: checked}))} />
            <label htmlFor="termsAccepted" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-slate-600">
                I agree to the <span className="text-indigo-600 underline cursor-pointer">Terms of Service</span> and <span className="text-indigo-600 underline cursor-pointer">Privacy Policy</span>.
            </label>
        </div>
     </motion.div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[480px] overflow-hidden p-0 gap-0 border-0 rounded-2xl">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-700 p-8 text-white text-center">
            <DialogTitle className="text-3xl font-bold mb-2 tracking-tight">
                {activeTab === 'login' ? t('welcome_back') : "Join FastPost"}
            </DialogTitle>
            <DialogDescription className="text-indigo-100 text-base">
                {activeTab === 'login' ? "Access your dashboard & orders" : "Create an account to get started"}
            </DialogDescription>
        </div>

        {emailSent ? (
            <div className="p-8 text-center space-y-6">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto animate-bounce-slow">
                    <Mail className="w-10 h-10 text-green-600" />
                </div>
                <div>
                    <h3 className="text-2xl font-bold text-slate-800">Check Your Email</h3>
                    <p className="text-slate-500 mt-2">
                        We've sent a verification link to <strong>{formData.email}</strong>. 
                        Please confirm your email to activate your account.
                    </p>
                </div>
                <div className="flex flex-col gap-3">
                    <Button onClick={() => { setEmailSent(false); setActiveTab('login'); }} className="w-full bg-slate-900 text-white">
                        Back to Login
                    </Button>
                    <Button variant="ghost" className="text-sm text-slate-500" onClick={onClose}>
                        Close
                    </Button>
                </div>
            </div>
        ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <div className="px-8 pt-6">
                    <TabsList className="grid w-full grid-cols-2 h-12 bg-slate-100/80 p-1 rounded-xl">
                        <TabsTrigger value="login" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300">Login</TabsTrigger>
                        <TabsTrigger value="signup" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300">Sign Up</TabsTrigger>
                    </TabsList>
                </div>

                <div className="p-8 pt-6">
                    <TabsContent value="login" className="space-y-5 m-0 focus-visible:ring-0">
                        <form onSubmit={handleLogin} className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="loginEmail">Email</Label>
                                <Input id="email" type="email" value={formData.email} onChange={handleInputChange} placeholder="you@example.com" className="h-11" />
                            </div>
                            <div className="space-y-2">
                                <div className="flex justify-between">
                                    <Label htmlFor="loginPassword">Password</Label>
                                    <a href="#" className="text-xs text-indigo-600 hover:underline">Forgot?</a>
                                </div>
                                <div className="relative">
                                    <Input 
                                      id="password" 
                                      type={showPassword ? "text" : "password"} 
                                      value={formData.password} 
                                      onChange={handleInputChange} 
                                      placeholder="••••••••" 
                                      className="h-11 pr-10"
                                    />
                                    <button 
                                      type="button"
                                      onClick={() => setShowPassword(!showPassword)}
                                      className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                                    >
                                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                    </button>
                                </div>
                            </div>
                            <Button type="submit" className="w-full h-12 text-base bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-200" disabled={isLoading}>
                                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Sign In"}
                            </Button>
                        </form>
                        
                        <div className="relative py-2">
                            <div className="absolute inset-0 flex items-center"><Separator /></div>
                            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-slate-500">Or continue with</span></div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-3">
                            <Button variant="outline" onClick={() => handleSocialLogin('google')} className="w-full h-11"><img src="https://www.google.com/favicon.ico" className="w-4 h-4 mr-2"/> Google</Button>
                            <Button variant="outline" onClick={() => handleSocialLogin('facebook')} className="w-full h-11"><Facebook className="w-4 h-4 mr-2 text-blue-600"/> Facebook</Button>
                        </div>
                    </TabsContent>

                    <TabsContent value="signup" className="m-0 focus-visible:ring-0">
                        <div className="mb-6">
                            {/* Progress Steps */}
                            <div className="flex justify-between mb-4 px-2 relative">
                               <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -z-10"></div>
                               {[1, 2, 3].map(i => {
                                   // Adjust logic to hide step 2 for customers visually if needed, but keeping simple for now
                                   const isActive = step >= i;
                                   const isCompleted = step > i;
                                   return (
                                       <div key={i} className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 border-2 ${isActive ? 'bg-indigo-600 border-indigo-600 text-white shadow-md' : 'bg-white border-slate-200 text-slate-400'}`}>
                                           {isCompleted ? <CheckCircle className="w-4 h-4" /> : i}
                                       </div>
                                   );
                               })}
                            </div>
                            
                            <h3 className="text-lg font-bold text-slate-800 mb-1 text-center">
                                {step === 1 ? "Personal Details" : step === 2 ? "Additional Info" : "Security Setup"}
                            </h3>
                        </div>

                        <div className="min-h-[250px]">
                            <AnimatePresence mode="wait">
                                {step === 1 && renderStep1()}
                                {step === 2 && renderStep2()}
                                {step === 3 && renderStep3()}
                            </AnimatePresence>
                        </div>

                        <div className="flex justify-between mt-8 pt-4 border-t">
                            <Button 
                                variant="ghost" 
                                onClick={() => {
                                    if (step === 1) return;
                                    if (step === 3 && role === 'customer') setStep(1); // Skip step 2 backwards
                                    else setStep(prev => prev - 1);
                                }}
                                disabled={step === 1}
                                className="hover:bg-slate-100"
                            >
                                Back
                            </Button>
                            <Button 
                                className="bg-indigo-600 hover:bg-indigo-700 min-w-[120px] shadow-lg shadow-indigo-200" 
                                onClick={step === 3 ? handleSignupSubmit : handleNextStep}
                                disabled={isLoading}
                            >
                                {isLoading ? <Loader2 className="w-4 h-4 animate-spin"/> : (step === 3 ? "Create Account" : "Next Step")}
                            </Button>
                        </div>
                    </TabsContent>
                </div>
            </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default AuthModal;
