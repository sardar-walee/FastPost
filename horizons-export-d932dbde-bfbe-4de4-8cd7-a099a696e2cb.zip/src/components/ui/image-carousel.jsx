
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Maximize2, X, ZoomIn, Download, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';

export const ImageCarousel = ({ images = [], alt = "Vehicle Image", aspectRatio = "aspect-video", className }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);

  // Auto-cycle if not interacted with for a while could be added here
  
  const slideVariants = {
    enter: (direction) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8,
      rotateY: direction > 0 ? 45 : -45
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1,
      rotateY: 0
    },
    exit: (direction) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8,
      rotateY: direction < 0 ? 45 : -45
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset, velocity) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = (newDirection) => {
    setDirection(newDirection);
    setCurrentIndex((prev) => (prev + newDirection + images.length) % images.length);
  };

  if (!images.length) return (
    <div className={`bg-slate-100 rounded-xl flex items-center justify-center text-slate-400 ${aspectRatio}`}>
      No images available
    </div>
  );

  return (
    <div className={cn("relative group overflow-hidden bg-black rounded-xl", className)}>
      <div className={`${aspectRatio} relative overflow-hidden`}>
        <AnimatePresence initial={false} custom={direction}>
          <motion.img
            key={currentIndex}
            src={images[currentIndex]}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 },
              rotateY: { duration: 0.4 } // Flip effect
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={1}
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = swipePower(offset.x, velocity.x);
              if (swipe < -swipeConfidenceThreshold) {
                paginate(1);
              } else if (swipe > swipeConfidenceThreshold) {
                paginate(-1);
              }
            }}
            className="absolute w-full h-full object-contain cursor-grab active:cursor-grabbing"
            alt={`${alt} - View ${currentIndex + 1}`}
          />
        </AnimatePresence>

        {/* Counter */}
        <div className="absolute top-4 right-4 bg-black/60 backdrop-blur text-white px-3 py-1 rounded-full text-xs font-mono z-10">
          {currentIndex + 1} / {images.length}
        </div>

        {/* Controls */}
        <div className="absolute inset-0 flex items-center justify-between p-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
           <Button 
             variant="ghost" 
             size="icon" 
             className="w-10 h-10 rounded-full bg-black/40 text-white hover:bg-black/60 pointer-events-auto backdrop-blur-sm"
             onClick={(e) => { e.stopPropagation(); paginate(-1); }}
           >
             <ChevronLeft className="w-6 h-6" />
           </Button>
           <Button 
             variant="ghost" 
             size="icon" 
             className="w-10 h-10 rounded-full bg-black/40 text-white hover:bg-black/60 pointer-events-auto backdrop-blur-sm"
             onClick={(e) => { e.stopPropagation(); paginate(1); }}
           >
             <ChevronRight className="w-6 h-6" />
           </Button>
        </div>
        
        {/* Bottom Actions */}
        <div className="absolute bottom-4 right-4 flex gap-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
            <Dialog>
              <DialogTrigger asChild>
                <Button size="icon" variant="secondary" className="w-8 h-8 rounded-full bg-white/90 backdrop-blur"><Maximize2 className="w-4 h-4" /></Button>
              </DialogTrigger>
              <DialogContent className="max-w-[95vw] h-[90vh] bg-black border-0 p-0 flex flex-col items-center justify-center">
                  <div className="relative w-full h-full">
                      <img src={images[currentIndex]} className="w-full h-full object-contain" />
                      <Button onClick={() => paginate(-1)} className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full w-12 h-12 bg-white/10 hover:bg-white/20 text-white"><ChevronLeft/></Button>
                      <Button onClick={() => paginate(1)} className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full w-12 h-12 bg-white/10 hover:bg-white/20 text-white"><ChevronRight/></Button>
                  </div>
              </DialogContent>
            </Dialog>
        </div>
      </div>

      {/* Thumbnails */}
      {images.length > 1 && (
        <div className="p-2 flex gap-2 overflow-x-auto scrollbar-hide bg-black/90 backdrop-blur-md border-t border-white/10">
           {images.map((img, idx) => (
             <button
               key={idx}
               onClick={() => { setDirection(idx > currentIndex ? 1 : -1); setCurrentIndex(idx); }}
               className={cn(
                 "relative w-16 h-12 rounded-md overflow-hidden flex-shrink-0 transition-all duration-300 border-2",
                 idx === currentIndex ? "border-indigo-500 opacity-100 scale-105" : "border-transparent opacity-50 hover:opacity-80"
               )}
             >
               <img src={img} className="w-full h-full object-cover" />
             </button>
           ))}
        </div>
      )}
    </div>
  );
};
