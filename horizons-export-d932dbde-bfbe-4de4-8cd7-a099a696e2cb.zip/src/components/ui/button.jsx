
import { cn } from '@/lib/utils';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import React from 'react';

const buttonVariants = cva(
	'inline-flex items-center justify-center rounded-xl text-sm font-semibold ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 active:scale-95 duration-200',
	{
		variants: {
			variant: {
				default: 'bg-slate-900 text-white shadow-lg shadow-slate-900/20 hover:shadow-xl hover:bg-slate-800 hover:-translate-y-0.5 border-0',
				destructive:
          'bg-red-500 text-white shadow-sm hover:bg-red-600 hover:shadow-red-500/25',
				outline:
          'border-2 border-slate-200 bg-transparent hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300 text-slate-700',
				secondary:
          'bg-slate-100 text-slate-900 hover:bg-slate-200/80 shadow-sm border border-transparent',
				ghost: 'hover:bg-slate-100 hover:text-slate-900 text-slate-600',
				link: 'text-indigo-600 underline-offset-4 hover:underline',
        emerald: 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 hover:-translate-y-0.5',
        amber: 'bg-amber-500 text-white shadow-lg shadow-amber-500/20 hover:bg-amber-600 hover:-translate-y-0.5',
        glass: 'bg-white/20 backdrop-blur-md border border-white/20 text-white hover:bg-white/30',
			},
			size: {
				default: 'h-11 px-6 py-2',
				sm: 'h-9 rounded-lg px-3 text-xs',
				lg: 'h-14 rounded-2xl px-8 text-base font-bold',
				icon: 'h-11 w-11 rounded-full',
			},
		},
		defaultVariants: {
			variant: 'default',
			size: 'default',
		},
	},
);

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	const Comp = asChild ? Slot : 'button';
	return (
		<Comp
			className={cn(buttonVariants({ variant, size, className }))}
			ref={ref}
			{...props}
		/>
	);
});
Button.displayName = 'Button';

export { Button, buttonVariants };
