
import React, { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

const SectionCarousel = ({ title, items, renderItem, onViewAll, className }) => {
  const scrollContainerRef = useRef(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);

  // Update arrow visibility and active index on scroll
  const handleScroll = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setShowLeftArrow(scrollLeft > 0);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10);
      
      // Calculate active index based on scroll position (approximate)
      const index = Math.round(scrollLeft / (clientWidth / getItemsPerView()));
      setActiveIndex(index);
    }
  };

  const getItemsPerView = () => {
    if (typeof window === 'undefined') return 1;
    if (window.innerWidth >= 1024) return 4;
    if (window.innerWidth >= 768) return 3;
    return 2;
  };

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const scrollAmount = container.clientWidth * 0.75; // Scroll 75% of view width
      const targetScroll = direction === 'left' 
        ? container.scrollLeft - scrollAmount 
        : container.scrollLeft + scrollAmount;
      
      container.scrollTo({
        left: targetScroll,
        behavior: 'smooth'
      });
    }
  };

  // Keyboard navigation
  const handleKeyDown = (e) => {
    if (e.key === 'ArrowLeft') scroll('left');
    if (e.key === 'ArrowRight') scroll('right');
  };

  // Listen for resize to update arrows
  useEffect(() => {
    const handleResize = () => handleScroll();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!items || items.length === 0) return null;

  return (
    <div className={cn("py-6 space-y-4 group", className)} onKeyDown={handleKeyDown} tabIndex={0}>
      <div className="flex items-center justify-between px-1">
        <h2 className="text-xl md:text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
          {title}
          <span className="text-xs font-normal text-slate-400 bg-slate-100 px-2 py-1 rounded-full hidden sm:inline-block">
            {items.length}
          </span>
        </h2>
        {onViewAll && (
          <Button variant="ghost" size="sm" onClick={onViewAll} className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 gap-1 text-sm font-medium">
            View All <ArrowRight className="w-4 h-4" />
          </Button>
        )}
      </div>

      <div className="relative">
        {/* Navigation Buttons (Desktop) */}
        <AnimatePresence>
          {showLeftArrow && (
            <motion.button
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              onClick={() => scroll('left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 -ml-4 z-20 w-10 h-10 bg-white/90 backdrop-blur-sm border border-slate-200 rounded-full shadow-lg flex items-center justify-center text-slate-700 hover:bg-white hover:text-indigo-600 transition-colors hidden md:flex"
              aria-label="Previous items"
            >
              <ChevronLeft className="w-6 h-6" />
            </motion.button>
          )}

          {showRightArrow && (
            <motion.button
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              onClick={() => scroll('right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 -mr-4 z-20 w-10 h-10 bg-white/90 backdrop-blur-sm border border-slate-200 rounded-full shadow-lg flex items-center justify-center text-slate-700 hover:bg-white hover:text-indigo-600 transition-colors hidden md:flex"
              aria-label="Next items"
            >
              <ChevronRight className="w-6 h-6" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Scroll Container */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex gap-3 md:gap-4 overflow-x-auto pb-4 pt-1 snap-x snap-mandatory scrollbar-hide px-1 -mx-1"
          style={{ scrollBehavior: 'smooth', WebkitOverflowScrolling: 'touch' }}
        >
          {items.map((item, index) => (
            <motion.div
              key={item.id || index}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="flex-shrink-0 snap-start w-[calc(50%-6px)] md:w-[calc(33.333%-11px)] lg:w-[calc(25%-12px)] min-w-[160px]"
            >
              {renderItem(item)}
            </motion.div>
          ))}
          
          {/* Spacing at the end */}
          <div className="w-1 flex-shrink-0" />
        </div>

        {/* Mobile Dot Indicators */}
        <div className="flex justify-center gap-1.5 mt-2 md:hidden">
            {Array.from({ length: Math.min(5, Math.ceil(items.length / 2)) }).map((_, i) => (
                <div 
                    key={i} 
                    className={cn(
                        "w-1.5 h-1.5 rounded-full transition-all duration-300", 
                        Math.floor(activeIndex / 2) === i ? "bg-indigo-600 w-3" : "bg-slate-300"
                    )}
                />
            ))}
        </div>
      </div>
    </div>
  );
};

export default SectionCarousel;
