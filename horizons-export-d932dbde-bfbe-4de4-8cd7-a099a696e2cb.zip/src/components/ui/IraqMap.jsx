
import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap, Polyline } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MapPin, Navigation, User, Home, Truck } from 'lucide-react';
import { renderToStaticMarkup } from 'react-dom/server';

// Iraq Center
const IRAQ_CENTER = [33.3152, 44.3661]; // Baghdad
const IRAQ_BOUNDS = [
  [29.0, 38.0], // Southwest
  [37.5, 48.5]  // Northeast
];

// Custom Marker Icons
const createIcon = (IconComponent, color) => {
  const iconMarkup = renderToStaticMarkup(
    <div className={`p-2 rounded-full border-2 border-white shadow-lg ${color} text-white`}>
      <IconComponent size={20} />
    </div>
  );
  
  return L.divIcon({
    html: iconMarkup,
    className: 'custom-leaflet-icon',
    iconSize: [40, 40],
    iconAnchor: [20, 40],
    popupAnchor: [0, -40]
  });
};

const icons = {
  restaurant: createIcon(Home, 'bg-indigo-600'),
  driver: createIcon(Truck, 'bg-emerald-600'),
  customer: createIcon(User, 'bg-rose-600'),
  office: createIcon(Navigation, 'bg-amber-600'),
  showroom: createIcon(MapPin, 'bg-blue-600')
};

// Component to handle map view updates
const MapUpdater = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, zoom || 13);
  }, [center, zoom, map]);
  return null;
};

const IraqMap = ({ 
  markers = [], // Array of { id, lat, lng, type, title, description }
  center = IRAQ_CENTER,
  zoom = 6,
  serviceRadius = null, // In meters
  activeRoute = null, // Array of [lat, lng]
  onMarkerClick,
  className = "h-[400px] w-full rounded-xl overflow-hidden shadow-inner border border-slate-200"
}) => {
  return (
    <div className={className}>
      <MapContainer 
        center={center} 
        zoom={zoom} 
        scrollWheelZoom={true} 
        className="h-full w-full z-0"
        maxBounds={IRAQ_BOUNDS}
        minZoom={5}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        <MapUpdater center={center} zoom={zoom} />

        {/* Service Radius Circle */}
        {serviceRadius && center && (
          <Circle 
            center={center}
            radius={serviceRadius}
            pathOptions={{ color: '#6366F1', fillColor: '#6366F1', fillOpacity: 0.1 }}
          />
        )}

        {/* Route Polyline */}
        {activeRoute && (
          <Polyline 
            positions={activeRoute}
            pathOptions={{ color: '#10B981', weight: 4, opacity: 0.7, dashArray: '10, 10' }} 
          />
        )}

        {/* Markers */}
        {markers.map((marker) => (
          marker.lat && marker.lng && (
            <Marker 
              key={marker.id} 
              position={[marker.lat, marker.lng]}
              icon={icons[marker.type] || icons.restaurant}
              eventHandlers={{
                click: () => onMarkerClick && onMarkerClick(marker),
              }}
            >
              <Popup className="custom-popup">
                <div className="p-1">
                  <h3 className="font-bold text-sm text-slate-800">{marker.title}</h3>
                  {marker.description && <p className="text-xs text-slate-500 mt-1">{marker.description}</p>}
                </div>
              </Popup>
            </Marker>
          )
        ))}
      </MapContainer>
      
      {/* Styles for custom icons */}
      <style>{`
        .custom-leaflet-icon {
          background: transparent;
          border: none;
        }
        .leaflet-popup-content-wrapper {
          border-radius: 12px;
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
        }
      `}</style>
    </div>
  );
};

export default IraqMap;
