
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PackageOpen, ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const EmptyState = ({ 
  icon: Icon = PackageOpen, 
  title, 
  description, 
  actionLabel, 
  onAction 
}) => {
  const { t } = useTranslation();
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 px-4 text-center bg-slate-50/50 rounded-3xl border border-dashed border-slate-200"
    >
      <div className="w-20 h-20 bg-white rounded-full shadow-lg shadow-indigo-100 flex items-center justify-center mb-6">
         <Icon className="w-10 h-10 text-indigo-400 opacity-80" />
      </div>
      
      <h3 className="text-xl font-bold text-slate-800 mb-2">
        {title || t('no_results_title')}
      </h3>
      
      <p className="text-slate-500 max-w-sm mb-8 leading-relaxed">
        {description || t('no_results_desc')}
      </p>
      
      {onAction ? (
        <Button onClick={onAction} className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl">
          {actionLabel || t('try_again')}
        </Button>
      ) : (
         <div className="text-sm text-slate-400 italic">
           {t('try_again')}
         </div>
      )}
    </motion.div>
  );
};

export default EmptyState;
