
import React, { useState, useEffect } from 'react';
import { Search, Mic, Sparkles, Clock, TrendingUp, Command, X, MapPin, Star } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/supabaseClient';
import { ScrollArea } from '@/components/ui/scroll-area';

const SmartSearch = ({ isOpen, onClose, onSearch }) => {
  const { t } = useTranslation();
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Load local history
    const saved = localStorage.getItem('fastpost_search_history');
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  useEffect(() => {
    if (query.length > 2) {
      const timer = setTimeout(fetchSuggestions, 300);
      return () => clearTimeout(timer);
    } else {
      setSuggestions([]);
    }
  }, [query]);

  const fetchSuggestions = async () => {
    setLoading(true);
    try {
      // Parallel fetch from different tables
      const [restaurants, cars, umrah] = await Promise.all([
        supabase.from('restaurants').select('id, name, location, rating, image_url').ilike('name', `%${query}%`).limit(3),
        supabase.from('cars').select('id, make, model, year, price, image_url').or(`make.ilike.%${query}%,model.ilike.%${query}%`).limit(3),
        supabase.from('umrah_trips').select('id, title, price, image_url').ilike('title', `%${query}%`).limit(3)
      ]);

      const merged = [
        ...(restaurants.data || []).map(i => ({ ...i, type: 'restaurant', title: i.name })),
        ...(cars.data || []).map(i => ({ ...i, type: 'car', title: `${i.year} ${i.make} ${i.model}` })),
        ...(umrah.data || []).map(i => ({ ...i, type: 'umrah', title: i.title }))
      ];
      
      setSuggestions(merged);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (item) => {
    const text = item.title || item;
    // Save to history
    const newHistory = [text, ...history.filter(h => h !== text)].slice(0, 5);
    setHistory(newHistory);
    localStorage.setItem('fastpost_search_history', JSON.stringify(newHistory));
    
    // Save to DB if logged in (optional implementation)
    
    onSearch?.(text);
    setQuery('');
    onClose();
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('fastpost_search_history');
  };

  const formatPrice = (p) => new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(p);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[650px] p-0 gap-0 overflow-hidden bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-slate-200 dark:border-slate-800 shadow-2xl rounded-2xl">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-indigo-500" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('search_placeholder')}
            className="border-0 focus-visible:ring-0 bg-transparent text-lg h-12 shadow-none px-0"
            autoFocus
          />
          {query && (
            <Button variant="ghost" size="icon" onClick={() => setQuery('')}>
              <X className="w-4 h-4 text-slate-400" />
            </Button>
          )}
        </div>

        <ScrollArea className="h-[400px]">
          <div className="p-2">
            {query.length === 0 ? (
              <div className="p-4 space-y-6">
                {/* History Section */}
                {history.length > 0 && (
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                        <Clock className="w-3 h-3" /> {t('recent_searches')}
                      </h4>
                      <Button variant="ghost" size="sm" className="h-6 text-[10px] text-slate-400" onClick={clearHistory}>Clear</Button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {history.map((item, i) => (
                        <Badge 
                          key={i} 
                          variant="outline" 
                          className="cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 py-2 px-3 text-sm font-normal gap-2"
                          onClick={() => handleSelect(item)}
                        >
                          {item}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Trending Section */}
                <div>
                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <TrendingUp className="w-3 h-3 text-emerald-500" /> {t('trending')}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                     <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSelect('Burger King')}>
                        <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=100&h=100&fit=crop" className="w-12 h-12 rounded-lg object-cover" alt="Trend"/>
                        <div>
                           <p className="font-medium text-sm">Best Burgers</p>
                           <p className="text-xs text-slate-500">Food • 2.5k searches</p>
                        </div>
                     </div>
                     <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSelect('Toyota Land Cruiser')}>
                        <img src="https://images.unsplash.com/photo-1594502184342-28efcb0a5748?w=100&h=100&fit=crop" className="w-12 h-12 rounded-lg object-cover" alt="Trend"/>
                        <div>
                           <p className="font-medium text-sm">Land Cruiser</p>
                           <p className="text-xs text-slate-500">Cars • 1.2k searches</p>
                        </div>
                     </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-1">
                {loading ? (
                  <div className="flex items-center justify-center py-12">
                     <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
                  </div>
                ) : suggestions.length > 0 ? (
                  suggestions.map((item, i) => (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      key={`${item.type}-${item.id}`}
                      className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer group transition-all"
                      onClick={() => handleSelect(item)}
                    >
                      <div className="w-14 h-14 shrink-0 rounded-lg overflow-hidden bg-slate-100 relative">
                         {item.image_url ? (
                           <img src={item.image_url} className="w-full h-full object-cover" alt={item.title}/>
                         ) : (
                           <div className="w-full h-full flex items-center justify-center bg-indigo-50 text-indigo-300">
                             <Sparkles className="w-6 h-6"/>
                           </div>
                         )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start">
                           <h4 className="font-bold text-slate-900 dark:text-white truncate">{item.title}</h4>
                           {item.price && <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded ml-2">{formatPrice(item.price)}</span>}
                        </div>
                        
                        <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                           <span className="capitalize bg-slate-100 px-1.5 py-0.5 rounded">{item.type}</span>
                           {item.rating && <span className="flex items-center gap-1"><Star className="w-3 h-3 fill-amber-400 text-amber-400"/> {item.rating}</span>}
                           {item.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3"/> {item.location}</span>}
                        </div>
                      </div>
                      
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <Command className="w-4 h-4 text-slate-400" />
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-12 text-slate-400">
                    <Search className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    <p>No results found for "{query}"</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default SmartSearch;
