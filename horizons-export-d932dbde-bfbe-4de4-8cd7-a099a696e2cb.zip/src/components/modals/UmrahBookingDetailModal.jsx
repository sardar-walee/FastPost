
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Calendar, MapPin, User, CreditCard, FileText, Printer, Mail, 
  MessageCircle, Clock, CheckCircle, XCircle, AlertTriangle, 
  Plane, Bus, Hotel, ShieldCheck
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const UmrahBookingDetailModal = ({ booking, isOpen, onClose, onUpdateStatus, isAdmin = false }) => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');
  const [adminNote, setAdminNote] = useState('');
  const [status, setStatus] = useState(booking?.status || 'pending');

  if (!booking) return null;

  const handlePrint = () => {
    window.print();
    toast({ title: "Printing", description: "Preparing document for print..." });
  };

  const handleSendEmail = () => {
    toast({ title: "Email Sent", description: `Confirmation sent to ${booking.users?.email || 'customer'}` });
  };

  const handleSaveNote = () => {
    toast({ title: "Note Saved", description: "Admin note has been attached to this booking." });
    setAdminNote('');
  };

  const formatCurrency = (amount) => 
    new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(amount);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-0 gap-0 bg-white/95 backdrop-blur-xl border-slate-200">
        
        {/* Header Section */}
        <div className="p-6 border-b bg-slate-50/50 flex justify-between items-start sticky top-0 z-10 backdrop-blur-md">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Badge variant="outline" className="bg-slate-100 text-slate-600 font-mono">
                #{booking.id.slice(0, 8).toUpperCase()}
              </Badge>
              <Badge className={
                status === 'confirmed' ? 'bg-emerald-500' : 
                status === 'cancelled' ? 'bg-red-500' : 'bg-amber-500'
              }>
                {status.toUpperCase()}
              </Badge>
            </div>
            <DialogTitle className="text-2xl font-bold text-slate-900">
              {booking.package_name || 'Umrah Package'}
            </DialogTitle>
            <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
              <Calendar className="w-4 h-4" /> 
              <span>Booked on {new Date(booking.created_at).toLocaleDateString()}</span>
              <span>•</span>
              <Clock className="w-4 h-4" />
              <span>14 Days Duration</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handlePrint}><Printer className="w-4 h-4 mr-2"/> Print</Button>
            <Button variant="outline" size="sm" onClick={handleSendEmail}><Mail className="w-4 h-4 mr-2"/> Email</Button>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="flex flex-col md:flex-row h-full">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col md:flex-row">
            
            {/* Sidebar Navigation */}
            <div className="md:w-64 bg-slate-50/50 border-r p-4 space-y-2">
              <TabsList className="flex flex-col h-auto bg-transparent w-full gap-1 p-0">
                <TabsTrigger value="overview" className="w-full justify-start gap-2 px-3 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <FileText className="w-4 h-4" /> Overview
                </TabsTrigger>
                <TabsTrigger value="customer" className="w-full justify-start gap-2 px-3 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <User className="w-4 h-4" /> Customer Details
                </TabsTrigger>
                <TabsTrigger value="itinerary" className="w-full justify-start gap-2 px-3 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <Plane className="w-4 h-4" /> Itinerary & Trip
                </TabsTrigger>
                <TabsTrigger value="payment" className="w-full justify-start gap-2 px-3 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <CreditCard className="w-4 h-4" /> Payment & Receipt
                </TabsTrigger>
                {isAdmin && (
                  <TabsTrigger value="admin" className="w-full justify-start gap-2 px-3 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm text-indigo-600">
                    <ShieldCheck className="w-4 h-4" /> Admin Actions
                  </TabsTrigger>
                )}
              </TabsList>

              <div className="mt-8 px-3">
                <p className="text-xs font-bold text-slate-400 uppercase mb-2">Need Help?</p>
                <Button variant="ghost" className="w-full justify-start gap-2 text-slate-600 text-sm h-8 px-0">
                  <MessageCircle className="w-4 h-4" /> Contact Support
                </Button>
              </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 p-6 bg-white min-h-[500px]">
              <ScrollArea className="h-full pr-4">
                
                {/* OVERVIEW TAB */}
                <TabsContent value="overview" className="space-y-6 mt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-50 p-4 rounded-xl border">
                      <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
                        <User className="w-4 h-4 text-indigo-500"/> Pilgrim Info
                      </h3>
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Name:</span>
                          <span className="font-medium">{booking.users?.full_name || 'Guest User'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Phone:</span>
                          <span className="font-medium">{booking.customer_phone || booking.users?.phone || 'N/A'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Passport:</span>
                          <span className="font-medium">A12345678 (Verified)</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Location:</span>
                          <span className="font-medium">{booking.customer_address || 'Baghdad'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border">
                      <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-emerald-500"/> Payment Summary
                      </h3>
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Base Price:</span>
                          <span className="font-medium">{formatCurrency(booking.total_price)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Visa Fees:</span>
                          <span className="font-medium">{formatCurrency(0)} (Included)</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between text-base font-bold text-slate-900">
                          <span>Total Paid:</span>
                          <span className="text-emerald-600">{formatCurrency(booking.total_price)}</span>
                        </div>
                        <div className="pt-2">
                          <Badge variant="outline" className="w-full justify-center py-1 border-emerald-200 bg-emerald-50 text-emerald-700">
                            Payment Completed
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Timeline */}
                  <div className="border rounded-xl p-6">
                    <h3 className="font-semibold mb-6">Booking Status Timeline</h3>
                    <div className="relative space-y-6 before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-200">
                      {[
                        { title: 'Booking Created', date: booking.created_at, active: true },
                        { title: 'Payment Confirmed', date: booking.created_at, active: booking.payment_status === 'paid' },
                        { title: 'Visa Processing', date: null, active: false },
                        { title: 'Ready for Travel', date: null, active: false }
                      ].map((step, i) => (
                        <div key={i} className="relative flex gap-4 items-start">
                          <div className={`w-10 h-10 rounded-full border-4 shrink-0 z-10 flex items-center justify-center ${step.active ? 'bg-indigo-600 border-indigo-100 text-white' : 'bg-white border-slate-100 text-slate-300'}`}>
                            {step.active ? <CheckCircle className="w-5 h-5"/> : <div className="w-3 h-3 rounded-full bg-slate-200"/>}
                          </div>
                          <div className="pt-2">
                            <h4 className={`font-semibold ${step.active ? 'text-slate-900' : 'text-slate-400'}`}>{step.title}</h4>
                            <p className="text-xs text-slate-500">{step.date ? new Date(step.date).toLocaleString() : 'Pending'}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                {/* ITINERARY TAB */}
                <TabsContent value="itinerary" className="space-y-6 mt-0">
                  <div className="space-y-4">
                    <h3 className="font-bold text-lg">Trip Schedule</h3>
                    <div className="bg-slate-50 border rounded-xl p-4 flex gap-4">
                      <div className="p-3 bg-white rounded-lg shadow-sm">
                        <Plane className="w-6 h-6 text-indigo-500" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Flight Details</h4>
                        <p className="text-sm text-slate-500">Baghdad (BGW) ➔ Jeddah (JED)</p>
                        <p className="text-xs text-slate-400 mt-1">Flight IA-123 • 08:30 AM Departure</p>
                      </div>
                    </div>
                    
                    <div className="bg-slate-50 border rounded-xl p-4 flex gap-4">
                      <div className="p-3 bg-white rounded-lg shadow-sm">
                        <Hotel className="w-6 h-6 text-indigo-500" />
                      </div>
                      <div>
                        <h4 className="font-semibold">Accommodation (Makkah)</h4>
                        <p className="text-sm text-slate-500">Swissotel Makkah (5 Stars)</p>
                        <p className="text-xs text-slate-400 mt-1">Clock Tower View • Breakfast Included</p>
                      </div>
                    </div>

                    <div className="space-y-4 mt-6">
                      <h4 className="font-semibold text-slate-900">Daily Program</h4>
                      {[1, 2, 3, 4, 5].map((day) => (
                         <div key={day} className="flex gap-4 p-4 border rounded-lg hover:bg-slate-50 transition-colors">
                            <div className="font-bold text-slate-300 text-xl">0{day}</div>
                            <div>
                               <p className="font-bold text-slate-800">Day {day}: Religious Activities</p>
                               <p className="text-sm text-slate-500">Group tawaf, prayer times, and visiting holy sites.</p>
                            </div>
                         </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                {/* PAYMENT TAB */}
                <TabsContent value="payment" className="space-y-6 mt-0">
                   <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center bg-slate-50">
                      <CheckCircle className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
                      <h3 className="text-xl font-bold text-emerald-700">Payment Verified</h3>
                      <p className="text-slate-500 mb-6">Transaction ID: {booking.id}</p>
                      
                      <div className="bg-white p-6 max-w-md mx-auto shadow-sm border rounded-lg text-left">
                         <div className="flex justify-between mb-2">
                            <span className="text-slate-500">Amount</span>
                            <span className="font-bold">{formatCurrency(booking.total_price)}</span>
                         </div>
                         <div className="flex justify-between mb-2">
                            <span className="text-slate-500">Method</span>
                            <span className="font-bold">Cash at Office</span>
                         </div>
                         <div className="flex justify-between mb-2">
                            <span className="text-slate-500">Date</span>
                            <span className="font-bold">{new Date(booking.created_at).toLocaleDateString()}</span>
                         </div>
                      </div>

                      <div className="flex justify-center gap-4 mt-6">
                         <Button variant="outline"><Printer className="w-4 h-4 mr-2"/> Print Receipt</Button>
                         <Button variant="outline"><Mail className="w-4 h-4 mr-2"/> Email Invoice</Button>
                      </div>
                   </div>
                </TabsContent>

                {/* ADMIN TAB */}
                <TabsContent value="admin" className="space-y-6 mt-0">
                  <div className="grid gap-6">
                    <div className="space-y-2">
                       <label className="text-sm font-medium">Update Status</label>
                       <Select value={status} onValueChange={(val) => { setStatus(val); onUpdateStatus?.(booking.id, val); }}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                             <SelectItem value="pending">Pending</SelectItem>
                             <SelectItem value="confirmed">Confirmed</SelectItem>
                             <SelectItem value="cancelled">Cancelled</SelectItem>
                             <SelectItem value="completed">Completed</SelectItem>
                          </SelectContent>
                       </Select>
                    </div>

                    <div className="space-y-2">
                       <label className="text-sm font-medium">Admin Notes</label>
                       <Textarea 
                          placeholder="Add internal notes about this booking..." 
                          value={adminNote}
                          onChange={(e) => setAdminNote(e.target.value)}
                          className="min-h-[100px]"
                       />
                       <Button onClick={handleSaveNote} size="sm" className="bg-indigo-600">Save Note</Button>
                    </div>

                    <div className="bg-red-50 p-4 rounded-xl border border-red-100 mt-4">
                       <h4 className="font-bold text-red-700 mb-2 flex items-center gap-2"><AlertTriangle className="w-4 h-4"/> Danger Zone</h4>
                       <p className="text-xs text-red-600 mb-4">Actions here cannot be undone easily.</p>
                       <div className="flex gap-4">
                          <Button variant="destructive" size="sm">Cancel Booking</Button>
                          <Button variant="outline" className="border-red-200 text-red-600 hover:bg-red-100" size="sm">Issue Refund</Button>
                       </div>
                    </div>
                  </div>
                </TabsContent>

              </ScrollArea>
            </div>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default UmrahBookingDetailModal;
