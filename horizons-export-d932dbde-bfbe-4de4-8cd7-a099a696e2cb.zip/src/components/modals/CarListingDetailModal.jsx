
import React, { useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Car, Calendar, Gauge, Fuel, Settings, MapPin, 
  Phone, Share2, Shield, User, AlertTriangle, 
  ClipboardCheck, Star, CheckCircle, Maximize2, FileText, History, DollarSign
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { ImageCarousel } from '@/components/ui/image-carousel';
import { supabase } from '@/supabaseClient';

const CarListingDetailModal = ({ listing, isOpen, onClose, user }) => {
  const { toast } = useToast();
  const [bookingDate, setBookingDate] = useState('');
  const [offerPrice, setOfferPrice] = useState(listing?.price || '');
  const [purchaseMessage, setPurchaseMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");

  if (!listing) return null;

  // Compile images properly
  const images = listing.images && listing.images.length > 0 
    ? listing.images 
    : [listing.image_url || 'https://via.placeholder.com/800x600?text=Car+Image'];

  const specs = [
    { label: 'Year', value: listing.year, icon: Calendar },
    { label: 'Mileage', value: `${listing.mileage || '0'} km`, icon: Gauge },
    { label: 'Fuel', value: listing.fuel_type || 'Petrol', icon: Fuel },
    { label: 'Transmission', value: listing.transmission || 'Auto', icon: Settings },
    { label: 'Color', value: listing.color || 'N/A', icon: Car },
    { label: 'Body', value: listing.body_type || 'Sedan', icon: Car },
  ];

  const handleBookTestDrive = async () => {
      if (!user) {
          toast({ title: "Login Required", description: "Please login to book a test drive.", variant: "destructive" });
          return;
      }
      if (!bookingDate) {
          toast({ title: "Date Required", description: "Please select a preferred date.", variant: "destructive" });
          return;
      }

      setIsSubmitting(true);
      try {
          const { error } = await supabase.from('car_bookings').insert({
              car_id: listing.id,
              user_id: user.id,
              seller_id: listing.seller_id,
              booking_date: bookingDate,
              booking_time: '10:00:00', // Default time, could be a field
              type: 'test_drive',
              status: 'pending'
          });

          if (error) throw error;
          toast({ title: "Request Sent", description: "Dealer will contact you to confirm test drive." });
          onClose();
      } catch (e) {
          toast({ title: "Error", description: e.message, variant: "destructive" });
      } finally {
          setIsSubmitting(false);
      }
  };

  const handlePurchaseRequest = async () => {
    if (!user) {
        toast({ title: "Login Required", description: "Please login to make an offer.", variant: "destructive" });
        return;
    }

    setIsSubmitting(true);
    try {
        const { error } = await supabase.from('car_purchase_requests').insert({
            car_id: listing.id,
            buyer_id: user.id,
            seller_id: listing.seller_id,
            offer_price: parseFloat(offerPrice),
            message: purchaseMessage,
            status: 'pending'
        });

        if (error) throw error;
        toast({ title: "Offer Sent!", description: "The seller has been notified of your interest." });
        onClose();
    } catch (e) {
        toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
        setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[95vh] p-0 gap-0 bg-white border-0 overflow-hidden flex flex-col md:flex-row rounded-2xl">
        
        {/* Left: Gallery using Carousel */}
        <div className="w-full md:w-3/5 bg-black relative flex flex-col justify-center">
            <ImageCarousel images={images} alt={`${listing.make} ${listing.model}`} className="h-full w-full" aspectRatio="h-full" />
            <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-white hover:bg-white/20 z-50 rounded-full" onClick={onClose}><span className="sr-only">Close</span>✕</Button>
        </div>

        {/* Right: Info */}
        <div className="w-full md:w-2/5 flex flex-col h-full bg-slate-50">
            <ScrollArea className="flex-1">
                <div className="p-6 space-y-6">
                    {/* Header */}
                    <div>
                        <div className="flex justify-between items-start">
                            <div>
                                <h2 className="text-2xl font-bold text-slate-900">{listing.year} {listing.make} {listing.model}</h2>
                                <p className="text-slate-500 text-sm flex items-center gap-1 mt-1"><MapPin className="w-3 h-3"/> {listing.location || 'Baghdad'}</p>
                            </div>
                            <Badge className={listing.damage_assessment === 'Messed' ? 'bg-red-600' : 'bg-emerald-600'}>
                                {listing.damage_assessment === 'Messed' ? 'Damaged' : 'Undamaged'}
                            </Badge>
                        </div>
                        <h3 className="text-3xl font-bold text-indigo-700 mt-2">${listing.price?.toLocaleString()}</h3>
                    </div>

                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList className="w-full justify-start overflow-x-auto bg-slate-100 p-1">
                            <TabsTrigger value="overview">Overview</TabsTrigger>
                            <TabsTrigger value="features">Features</TabsTrigger>
                            <TabsTrigger value="condition">Condition</TabsTrigger>
                            <TabsTrigger value="purchase">Purchase</TabsTrigger>
                        </TabsList>

                        <TabsContent value="overview" className="space-y-6 mt-4 animate-in fade-in slide-in-from-right-2">
                            <div className="grid grid-cols-2 gap-4">
                                {specs.map((s, i) => (
                                    <div key={i} className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-100 shadow-sm">
                                        <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600"><s.icon className="w-4 h-4"/></div>
                                        <div>
                                            <p className="text-[10px] text-slate-400 uppercase tracking-wider">{s.label}</p>
                                            <p className="font-semibold text-slate-900 text-sm">{s.value}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            
                            <div className="bg-white p-4 rounded-xl border border-slate-100">
                                <h4 className="font-bold text-slate-900 mb-2">Description</h4>
                                <p className="text-sm text-slate-600 leading-relaxed">{listing.description || "No description provided."}</p>
                            </div>

                            {/* Seller Info */}
                            <div className="flex items-center gap-4 p-4 bg-white rounded-xl border border-slate-100">
                                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center"><User className="w-6 h-6 text-slate-400"/></div>
                                <div>
                                    <p className="font-bold text-slate-900">Showroom Seller</p>
                                    <div className="flex gap-1">
                                        {[1,2,3,4,5].map(i => <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400"/>)}
                                    </div>
                                </div>
                                <Button size="sm" variant="outline" className="ml-auto">View Profile</Button>
                            </div>
                        </TabsContent>

                        <TabsContent value="features" className="mt-4 animate-in fade-in slide-in-from-right-2">
                            <div className="grid grid-cols-2 gap-3">
                                {listing.features && listing.features.length > 0 ? listing.features.map((f, i) => (
                                    <div key={i} className="flex items-center gap-2 p-2 bg-white rounded border border-slate-100 text-sm">
                                        <CheckCircle className="w-4 h-4 text-emerald-500" /> {f}
                                    </div>
                                )) : <p className="text-slate-500 text-sm col-span-2">No specific features listed.</p>}
                            </div>
                        </TabsContent>

                        <TabsContent value="condition" className="mt-4 space-y-4 animate-in fade-in slide-in-from-right-2">
                             <div className={`flex items-center gap-3 p-4 border rounded-xl ${listing.damage_assessment === 'Messed' ? 'bg-red-50 border-red-100' : 'bg-emerald-50 border-emerald-100'}`}>
                                 <ClipboardCheck className={`w-8 h-8 ${listing.damage_assessment === 'Messed' ? 'text-red-600' : 'text-emerald-600'}`} />
                                 <div>
                                     <h5 className={`font-bold ${listing.damage_assessment === 'Messed' ? 'text-red-900' : 'text-emerald-900'}`}>
                                         {listing.damage_assessment === 'Messed' ? 'Damage Reported' : 'Clean Condition'}
                                     </h5>
                                     <p className={`text-xs ${listing.damage_assessment === 'Messed' ? 'text-red-700' : 'text-emerald-700'}`}>
                                         {listing.damage_assessment === 'Messed' ? 'Vehicle has reported issues.' : 'Vehicle verified as clean.'}
                                     </p>
                                 </div>
                             </div>

                             {listing.defects && listing.defects.length > 0 ? (
                                 <div className="space-y-2">
                                     <h4 className="font-bold text-sm">Reported Issues</h4>
                                     {listing.defects.map((d, i) => (
                                         <div key={i} className="flex items-center gap-2 p-3 bg-red-50 border border-red-100 rounded-lg text-red-800 text-sm">
                                             <AlertTriangle className="w-4 h-4" /> 
                                             <span className="font-bold capitalize">{d.severity}:</span> {d.description}
                                         </div>
                                     ))}
                                 </div>
                             ) : (
                                 <div className="p-4 text-center bg-white border rounded-xl">
                                     <CheckCircle className="w-8 h-8 mx-auto text-emerald-500 mb-2"/>
                                     <p className="text-sm font-medium">No specific defects logged</p>
                                 </div>
                             )}
                        </TabsContent>

                        <TabsContent value="purchase" className="mt-4 space-y-4 animate-in fade-in slide-in-from-right-2">
                            <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-6">
                                <h4 className="font-bold text-indigo-900 mb-4 flex items-center gap-2">
                                    <DollarSign className="w-5 h-5"/> Make an Offer
                                </h4>
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <label className="text-sm font-medium text-slate-700">Your Offer Price (IQD)</label>
                                        <Input 
                                            type="number" 
                                            value={offerPrice} 
                                            onChange={(e) => setOfferPrice(e.target.value)} 
                                            className="bg-white"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-medium text-slate-700">Message to Seller</label>
                                        <Textarea 
                                            placeholder="I'm interested in this car..." 
                                            value={purchaseMessage}
                                            onChange={(e) => setPurchaseMessage(e.target.value)}
                                            className="bg-white resize-none"
                                            rows={3}
                                        />
                                    </div>
                                    <Button 
                                        className="w-full bg-indigo-600 hover:bg-indigo-700" 
                                        onClick={handlePurchaseRequest}
                                        disabled={isSubmitting}
                                    >
                                        {isSubmitting ? 'Sending...' : 'Send Offer'}
                                    </Button>
                                    <p className="text-xs text-center text-slate-500 mt-2">The seller will be notified instantly.</p>
                                </div>
                            </div>
                        </TabsContent>
                    </Tabs>
                </div>
            </ScrollArea>

            {/* Sticky Footer */}
            <div className="p-4 bg-white border-t shadow-[0_-4px_10px_rgba(0,0,0,0.05)] space-y-3">
                 <div className="flex gap-2">
                     <Input type="date" className="flex-1" onChange={(e) => setBookingDate(e.target.value)} min={new Date().toISOString().split('T')[0]}/>
                     <Button className="flex-[2] bg-slate-900 hover:bg-slate-800 text-white font-bold" onClick={handleBookTestDrive} disabled={isSubmitting}>
                         Book Test Drive
                     </Button>
                 </div>
                 <div className="flex justify-center gap-6">
                     <button className="flex items-center gap-2 text-xs font-medium text-slate-500 hover:text-indigo-600"><Phone className="w-4 h-4"/> Call</button>
                     <button className="flex items-center gap-2 text-xs font-medium text-slate-500 hover:text-indigo-600"><Share2 className="w-4 h-4"/> Share</button>
                     <button className="flex items-center gap-2 text-xs font-medium text-slate-500 hover:text-indigo-600"><Shield className="w-4 h-4"/> Warranty</button>
                 </div>
            </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CarListingDetailModal;
