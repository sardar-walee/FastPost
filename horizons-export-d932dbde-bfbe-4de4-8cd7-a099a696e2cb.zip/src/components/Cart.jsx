
import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShoppingBag, MapPin, Navigation, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/supabaseClient';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const Cart = ({ cart, removeFromCart, placeOrder, onAuthRequired, isAuthenticated }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [deliveryDetails, setDeliveryDetails] = useState({ address: '', phone: '' });
  
  const [deliveryFee, setDeliveryFee] = useState(3000);
  const [distance, setDistance] = useState(0);
  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [appliedCoupon, setAppliedCoupon] = useState(null);

  const subtotal = cart.reduce((sum, item) => sum + item.totalPrice, 0);
  const total = Math.max(0, subtotal + deliveryFee - discount);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(price);
  };

  const handleApplyCoupon = async () => {
     if(!couponCode) return;
     const { data, error } = await supabase
        .from('coupons')
        .select('*')
        .eq('code', couponCode.toUpperCase())
        .eq('is_active', true)
        .single();
     
     if(error || !data) {
         toast({ variant: "destructive", title: "Invalid Coupon", description: "This code does not exist or has expired." });
         setDiscount(0);
         setAppliedCoupon(null);
     } else {
         let discAmount = 0;
         if(data.discount_percentage) {
             discAmount = (subtotal * data.discount_percentage) / 100;
         }
         if(data.max_discount_amount) {
             discAmount = Math.min(discAmount, data.max_discount_amount);
         }
         setDiscount(discAmount);
         setAppliedCoupon(data.code);
         toast({ title: "Coupon Applied!", description: `You saved ${formatPrice(discAmount)}` });
     }
  };

  const confirmOrder = () => {
    placeOrder({ ...deliveryDetails, deliveryFee, distance, discount, couponCode: appliedCoupon });
    setIsCheckingOut(false);
  };

  if (cart.length === 0) {
    return (
      <div className="bg-white rounded-3xl p-8 text-center shadow-sm border border-slate-100">
        <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
          <ShoppingBag className="w-8 h-8 text-slate-300" />
        </div>
        <h3 className="font-bold text-slate-800">{t('cart_empty')}</h3>
        <p className="text-slate-500 text-sm mt-1">Start adding some delicious food!</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden sticky top-24">
      <div className="p-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white flex justify-between items-center">
        <h3 className="font-bold flex items-center gap-2"><ShoppingBag className="w-5 h-5"/> Your Order</h3>
        <Badge variant="secondary" className="bg-white/20 text-white border-0">{cart.length} items</Badge>
      </div>

      <ScrollArea className="h-[300px] p-4">
        <div className="space-y-4">
          <AnimatePresence>
            {cart.map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, height: 0 }}
                className="flex gap-3 group"
              >
                <div className="w-16 h-16 bg-slate-100 rounded-xl overflow-hidden shrink-0 shadow-sm">
                    {item.image_url && <img src={item.image_url} alt={item.name} className="w-full h-full object-cover"/>}
                </div>
                <div className="flex-1 overflow-hidden">
                  <div className="flex justify-between items-start">
                    <h4 className="font-bold text-sm text-slate-900 truncate">{item.name}</h4>
                    <button onClick={() => removeFromCart(idx)} className="text-slate-300 hover:text-red-500 transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 truncate">{item.restaurantName}</p>
                  
                  {item.selectedOptions && item.selectedOptions.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                          {item.selectedOptions.map((opt, i) => (
                              <span key={i} className="text-[10px] bg-slate-50 px-1.5 py-0.5 rounded text-slate-600 border">
                                  {opt.choice}
                              </span>
                          ))}
                      </div>
                  )}

                  <div className="flex justify-between items-end mt-1">
                    <span className="font-bold text-emerald-600 text-sm">{formatPrice(item.totalPrice)}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>

      <div className="p-4 bg-slate-50/50 border-t space-y-3">
        {!isCheckingOut ? (
           <>
             {/* Coupon Input */}
             <div className="flex gap-2 mb-2">
                 <div className="relative flex-1">
                     <Tag className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
                     <Input 
                        placeholder="Promo Code" 
                        className="pl-8 h-9 text-xs bg-white" 
                        value={couponCode}
                        onChange={e => setCouponCode(e.target.value)}
                     />
                 </div>
                 <Button size="sm" variant="outline" onClick={handleApplyCoupon} className="h-9">Apply</Button>
             </div>

             <div className="space-y-1 text-sm">
                 <div className="flex justify-between text-slate-500">
                    <span>{t('subtotal')}</span>
                    <span>{formatPrice(subtotal)}</span>
                 </div>
                 <div className="flex justify-between text-slate-500">
                    <span>{t('delivery_fee')}</span>
                    <span>{formatPrice(deliveryFee)}</span>
                 </div>
                 {discount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-medium">
                        <span>Discount ({appliedCoupon})</span>
                        <span>-{formatPrice(discount)}</span>
                    </div>
                 )}
             </div>
             
             <Separator className="my-2"/>
             
             <div className="flex justify-between font-bold text-lg items-center">
                <span>{t('total')}</span>
                <span className="text-emerald-700 bg-emerald-50 px-3 py-1 rounded-lg">{formatPrice(total)}</span>
             </div>
             
             <Button className="w-full btn-primary font-bold py-6 rounded-xl text-lg shadow-lg shadow-emerald-200 mt-2" onClick={() => isAuthenticated ? setIsCheckingOut(true) : onAuthRequired()}>
                {t('checkout')}
             </Button>
           </>
        ) : (
           <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-sm">{t('delivery_details')}</h4>
              </div>
              <Input 
                placeholder={t('address')}
                value={deliveryDetails.address}
                onChange={e => setDeliveryDetails({...deliveryDetails, address: e.target.value})}
                className="bg-white"
              />
              <Input 
                placeholder={t('phone_number')}
                value={deliveryDetails.phone}
                onChange={e => setDeliveryDetails({...deliveryDetails, phone: e.target.value})}
                className="bg-white"
              />
              
              <div className="flex gap-2 pt-2">
                 <Button variant="ghost" className="flex-1 text-slate-500" onClick={() => setIsCheckingOut(false)}>
                    Back
                 </Button>
                 <Button className="flex-1 btn-primary" onClick={confirmOrder}>
                    Confirm Order
                 </Button>
              </div>
           </motion.div>
        )}
      </div>
    </div>
  );
};

export default Cart;
