
import React, { useState } from 'react';
import { supabase } from '@/supabaseClient';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Upload, Crown, Video, Image as ImageIcon } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

const AddStoryModal = ({ isOpen, onClose, user, role, onSuccess }) => {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const [formData, setFormData] = useState({
    caption: '',
    cta_type: 'none',
    is_vip: false,
    media_file: null,
    media_preview: null,
    linked_item_title: ''
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({
        ...formData,
        media_file: file,
        media_preview: URL.createObjectURL(file)
      });
    }
  };

  const handlePublish = async () => {
    if (!formData.media_file) {
        toast({ variant: "destructive", title: "Media Required", description: "Please select an image or video." });
        return;
    }

    setIsUploading(true);

    try {
        // 1. Upload Media
        const fileExt = formData.media_file.name.split('.').pop();
        const fileName = `${Date.now()}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
            .from('menu-items') // Reusing bucket for simplicity, ideally 'stories' bucket
            .upload(filePath, formData.media_file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
            .from('menu-items')
            .getPublicUrl(filePath);

        // 2. Insert Story
        const { data: storyData, error: dbError } = await supabase.from('stories').insert([{
            user_id: user.id,
            business_name: user.user_metadata?.business_name || user.email,
            role: role,
            media_url: publicUrl,
            media_type: formData.media_file.type.startsWith('video') ? 'video' : 'image',
            caption: formData.caption,
            cta_type: formData.cta_type,
            linked_item_title: formData.linked_item_title,
            is_vip: formData.is_vip,
            expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
        }]).select().single();

        if (dbError) throw dbError;

        // 3. Handle VIP Payment (Mock)
        if (formData.is_vip) {
            await supabase.from('vip_story_payments').insert({
                user_id: user.id,
                story_id: storyData.id,
                amount: 5000, // 5000 IQD fixed price
                status: 'completed'
            });
            toast({ title: "Payment Successful", description: "5,000 IQD deducted for VIP Story." });
        }

        toast({ title: "Story Published!", description: "Your story is now live for 24 hours." });
        onSuccess?.();
        onClose();
        setFormData({ caption: '', cta_type: 'none', is_vip: false, media_file: null, media_preview: null, linked_item_title: '' });
        
    } catch (error) {
        console.error(error);
        toast({ variant: "destructive", title: "Publish Failed", description: error.message });
    } finally {
        setIsUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add to Your Story</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
            {/* Preview Area */}
            <div className="w-full h-48 bg-slate-100 rounded-lg flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300 relative group">
                {formData.media_preview ? (
                    <img src={formData.media_preview} alt="Preview" className="w-full h-full object-contain" />
                ) : (
                    <div className="flex flex-col items-center text-slate-400">
                        <Upload className="w-8 h-8 mb-2" />
                        <span className="text-xs">Click to upload Image</span>
                    </div>
                )}
                <input 
                    type="file" 
                    className="absolute inset-0 opacity-0 cursor-pointer" 
                    accept="image/*,video/*"
                    onChange={handleFileChange}
                />
            </div>

            <div className="space-y-2">
                <Label>Caption</Label>
                <Input 
                    placeholder="What's happening?" 
                    value={formData.caption}
                    onChange={e => setFormData({...formData, caption: e.target.value})}
                />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label>Call to Action Button</Label>
                    <select 
                        className="w-full px-3 py-2 border rounded-md text-sm"
                        value={formData.cta_type}
                        onChange={e => setFormData({...formData, cta_type: e.target.value})}
                    >
                        <option value="none">No Button</option>
                        {role === 'restaurant_owner' && <option value="cart">Add to Cart</option>}
                        {role === 'umrah_company' && <option value="book">Book Now</option>}
                        {role === 'car_dealer' && <option value="contact">Contact Seller</option>}
                        <option value="buy">Buy Now</option>
                    </select>
                </div>
                
                {formData.cta_type !== 'none' && (
                    <div className="space-y-2">
                        <Label>Linked Item Name</Label>
                        <Input 
                            placeholder="e.g. Burger or Toyota"
                            value={formData.linked_item_title}
                            onChange={e => setFormData({...formData, linked_item_title: e.target.value})}
                        />
                    </div>
                )}
            </div>

            <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200 flex items-center gap-3">
                <Checkbox 
                    id="vip-mode" 
                    checked={formData.is_vip}
                    onCheckedChange={(checked) => setFormData({...formData, is_vip: checked})}
                />
                <div className="flex-1">
                    <label htmlFor="vip-mode" className="font-bold text-yellow-800 flex items-center gap-1 text-sm cursor-pointer">
                        <Crown className="w-4 h-4 fill-yellow-600 text-yellow-700" /> 
                        Promote as VIP Story
                    </label>
                    <p className="text-xs text-yellow-700">Cost: 5,000 IQD. VIP stories appear first with a golden border.</p>
                </div>
            </div>
        </div>

        <DialogFooter>
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handlePublish} disabled={isUploading || !formData.media_file} className="bg-emerald-600 hover:bg-emerald-700">
                {isUploading ? 'Publishing...' : (formData.is_vip ? 'Pay & Publish' : 'Publish Story')}
            </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddStoryModal;
