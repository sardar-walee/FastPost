
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { motion } from 'framer-motion';
import { Search, Sparkles, Filter, ArrowRight, Zap, ShoppingBag, Car, Plane } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SectionCarousel from '@/components/ui/section-carousel';
import { RestaurantCard, UmrahCard, CarCard } from '@/components/ServiceCards';
import { useToast } from '@/components/ui/use-toast';
import { useTranslation } from 'react-i18next';
import UmrahBookingDetailModal from '@/components/modals/UmrahBookingDetailModal';
import CarListingDetailModal from '@/components/modals/CarListingDetailModal';
import EmptyState from '@/components/ui/empty-state';

// Fallback Mock Data
const MOCK_UMRAH = [
  { id: 'u1', title: 'Ramadan Special Package', price: 1500000, duration: '14 Days', remaining_seats: 12, departure_city: 'Baghdad', image_url: 'https://images.unsplash.com/photo-1564769625905-50e93615e769' },
  { id: 'u2', title: 'Economy Group Trip', price: 950000, duration: '10 Days', remaining_seats: 4, departure_city: 'Basra', image_url: 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa' },
  { id: 'u3', title: 'Luxury VIP Experience', price: 3200000, duration: '7 Days', remaining_seats: 20, departure_city: 'Erbil', image_url: 'https://images.unsplash.com/photo-1519817650390-64a93db51149' },
];

const AllPostsFeed = ({ addToCart, onAuthRequired, isAuthenticated }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  
  // State
  const [activeCategory, setActiveCategory] = useState('trending');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  // Data
  const [restaurants, setRestaurants] = useState([]);
  const [umrahTrips, setUmrahTrips] = useState([]);
  const [cars, setCars] = useState([]);

  // Modals
  const [selectedUmrah, setSelectedUmrah] = useState(null);
  const [selectedCar, setSelectedCar] = useState(null);
  const [isUmrahModalOpen, setIsUmrahModalOpen] = useState(false);
  const [isCarModalOpen, setIsCarModalOpen] = useState(false);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [resData, umrahData, carData] = await Promise.all([
          supabase.from('restaurants').select('*').limit(20),
          supabase.from('umrah_trips').select('*').limit(20),
          supabase.from('cars').select('*').limit(20)
      ]);

      setRestaurants(resData.data || []);
      setUmrahTrips((umrahData.data && umrahData.data.length) > 0 ? umrahData.data : MOCK_UMRAH);
      setCars(carData.data || []);
    } catch (error) {
      console.error("Error loading feed:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFavorite = (item) => {
    if (!isAuthenticated) return onAuthRequired?.();
    toast({ title: "Added to Favorites", description: "Saved to your list." });
  };

  const categories = [
    { id: 'trending', label: t('cat_trending'), icon: Sparkles },
    { id: 'food', label: t('cat_food'), icon: ShoppingBag },
    { id: 'umrah', label: t('cat_umrah'), icon: Plane },
    { id: 'cars', label: t('cat_cars'), icon: Car },
    { id: 'offers', label: t('cat_offers'), icon: Zap },
  ];

  // Logic to filter content based on active category
  const getFilteredContent = () => {
     switch(activeCategory) {
        case 'trending':
           return {
              restaurants: restaurants.filter(r => (r.rating >= 4.5) || (r.reviews_count > 50)).slice(0, 5),
              cars: cars.filter(c => c.year >= 2023).slice(0, 5),
              umrah: umrahTrips.filter(u => u.remaining_seats < 10).slice(0, 5)
           };
        case 'food':
           return restaurants;
        case 'umrah':
           return umrahTrips;
        case 'cars':
           return cars;
        case 'offers':
           return {
              restaurants: restaurants.filter(r => r.discount > 0 || r.promotions?.length > 0),
              cars: cars.filter(c => c.price < 15000 || c.is_offer), 
              umrah: umrahTrips.filter(u => u.price < 1000000)
           };
        default:
           return [];
     }
  };

  const renderContent = () => {
    const data = getFilteredContent();

    if (activeCategory === 'trending') {
        const { restaurants: trendRes, cars: trendCars, umrah: trendUmrah } = data;
        const isEmpty = !trendRes.length && !trendCars.length && !trendUmrah.length;

        if (isEmpty) return <EmptyState title={t('no_results_title')} description={t('no_results_desc')} />;

        return (
            <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
                {trendRes.length > 0 && (
                    <SectionCarousel 
                        title={t('popular_restaurants')} 
                        items={trendRes}
                        renderItem={(item) => (
                            <RestaurantCard 
                                data={item} 
                                onAction={(i) => toast({ description: `Opening ${i.name}` })}
                                onFavorite={() => handleFavorite(item)}
                            />
                        )}
                        onViewAll={() => setActiveCategory('food')}
                    />
                )}

                {trendUmrah.length > 0 && (
                    <div className="relative rounded-3xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 p-6 md:p-10">
                        <SectionCarousel 
                            title={t('upcoming_trips')} 
                            items={trendUmrah}
                            renderItem={(item) => (
                                <UmrahCard 
                                    data={item} 
                                    onAction={(i) => { setSelectedUmrah(i); setIsUmrahModalOpen(true); }}
                                    onFavorite={() => handleFavorite(item)}
                                />
                            )}
                            onViewAll={() => setActiveCategory('umrah')}
                        />
                    </div>
                )}

                {trendCars.length > 0 && (
                    <SectionCarousel 
                        title={t('latest_cars')} 
                        items={trendCars}
                        renderItem={(item) => (
                            <CarCard 
                                data={item} 
                                onAction={(i) => { setSelectedCar(i); setIsCarModalOpen(true); }}
                                onFavorite={() => handleFavorite(item)}
                            />
                        )}
                        onViewAll={() => setActiveCategory('cars')}
                    />
                )}
            </div>
        );
    }
    
    if (activeCategory === 'offers') {
        const { restaurants: offerRes, cars: offerCars, umrah: offerUmrah } = data;
        const hasOffers = offerRes.length || offerCars.length || offerUmrah.length;
        
        if (!hasOffers) return <EmptyState icon={Filter} title={t('exclusive_offers')} description="No active offers at the moment. Check back soon!" />;

        return (
             <div className="space-y-12 animate-in fade-in zoom-in-95 duration-500">
                 {offerRes.length > 0 && (
                    <div className="space-y-6">
                        <h3 className="text-2xl font-bold flex items-center gap-2 text-slate-800 dark:text-white">🍔 Food Deals</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {offerRes.map(item => <RestaurantCard key={item.id} data={item} onAction={() => {}} onFavorite={() => handleFavorite(item)} />)}
                        </div>
                    </div>
                 )}
                 {offerCars.length > 0 && (
                    <div className="space-y-6">
                        <h3 className="text-2xl font-bold flex items-center gap-2 text-slate-800 dark:text-white">🚗 Car Deals</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {offerCars.map(item => <CarCard key={item.id} data={item} onAction={(i) => { setSelectedCar(i); setIsCarModalOpen(true); }} onFavorite={() => handleFavorite(item)} />)}
                        </div>
                    </div>
                 )}
             </div>
        );
    }

    // Standard Grids (Food, Umrah, Cars)
    if (!data || data.length === 0) {
        return <EmptyState actionLabel={t('explore_trending')} onAction={() => setActiveCategory('trending')} />;
    }

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            {data.map((item) => {
                if (activeCategory === 'food') return <RestaurantCard key={item.id} data={item} onAction={() => toast({description: "Menu View Not Implemented in Demo"})} onFavorite={() => handleFavorite(item)} />;
                if (activeCategory === 'umrah') return <UmrahCard key={item.id} data={item} onAction={(i) => { setSelectedUmrah(i); setIsUmrahModalOpen(true); }} onFavorite={() => handleFavorite(item)} />;
                if (activeCategory === 'cars') return <CarCard key={item.id} data={item} onAction={(i) => { setSelectedCar(i); setIsCarModalOpen(true); }} onFavorite={() => handleFavorite(item)} />;
                return null;
            })}
        </div>
    );
  };

  if (loading) {
     return (
        <div className="space-y-8 p-4">
           {[1,2].map(i => (
              <div key={i} className="space-y-4">
                 <div className="h-8 w-48 bg-slate-200 rounded animate-pulse" />
                 <div className="flex gap-4 overflow-hidden">
                    {[1,2,3,4].map(j => (
                       <div key={j} className="w-64 h-64 bg-slate-100 rounded-xl shrink-0 animate-pulse" />
                    ))}
                 </div>
              </div>
           ))}
        </div>
     );
  }

  return (
    <div className="space-y-10 pb-10">
      {/* Modern Hero Section */}
      <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl min-h-[400px] flex items-center">
         {/* Background with mesh gradient */}
         <div className="absolute inset-0 bg-slate-900">
            <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-600 rounded-full mix-blend-multiply filter blur-[128px] opacity-40 animate-blob"></div>
            <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-purple-600 rounded-full mix-blend-multiply filter blur-[128px] opacity-40 animate-blob animation-delay-2000"></div>
            <div className="absolute -bottom-32 left-20 w-[600px] h-[600px] bg-emerald-600 rounded-full mix-blend-multiply filter blur-[128px] opacity-40 animate-blob animation-delay-4000"></div>
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03]"></div>
         </div>

         <div className="relative z-10 w-full max-w-7xl mx-auto px-6 md:px-12 py-12 flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="md:w-1/2 space-y-6">
                <motion.div 
                   initial={{ opacity: 0, y: 20 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ duration: 0.6 }}
                >
                   <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-indigo-100 text-sm font-medium mb-4">
                       <Sparkles className="w-4 h-4 text-yellow-300" /> New Experience
                   </span>
                   <h1 className="text-4xl md:text-6xl font-bold text-white leading-[1.1] tracking-tight">
                       Discover <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 to-white">Iraq's</span> Best Services
                   </h1>
                   <p className="text-lg text-slate-300 mt-4 max-w-lg leading-relaxed">
                       From delicious food to spiritual journeys and dream cars. Experience the all-in-one platform for your lifestyle.
                   </p>
                </motion.div>

                <motion.div 
                   initial={{ opacity: 0, y: 20 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ duration: 0.6, delay: 0.2 }}
                   className="flex items-center p-2 bg-white rounded-2xl shadow-xl max-w-md"
                >
                   <Search className="w-5 h-5 text-slate-400 ml-3" />
                   <input 
                       placeholder={t('search_placeholder')} 
                       className="flex-1 bg-transparent border-none focus:outline-none text-slate-800 placeholder:text-slate-400 px-3 h-10"
                       value={searchTerm}
                       onChange={(e) => setSearchTerm(e.target.value)}
                   />
                   <Button className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl h-10 px-6 shadow-md shadow-indigo-200">
                       {t('search')}
                   </Button>
                </motion.div>
            </div>

            {/* Hero Visual */}
            <div className="md:w-1/2 flex justify-center relative">
                <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8 }}
                    className="relative z-10"
                >
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-4 mt-8">
                            <div className="bg-white/10 backdrop-blur-lg border border-white/20 p-4 rounded-2xl shadow-2xl">
                                <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center mb-2 text-white"><ShoppingBag className="w-6 h-6"/></div>
                                <div className="h-2 w-20 bg-white/20 rounded mb-1"></div>
                                <div className="h-2 w-12 bg-white/10 rounded"></div>
                            </div>
                            <div className="bg-white/10 backdrop-blur-lg border border-white/20 p-4 rounded-2xl shadow-2xl">
                                <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center mb-2 text-white"><Car className="w-6 h-6"/></div>
                                <div className="h-2 w-20 bg-white/20 rounded mb-1"></div>
                                <div className="h-2 w-12 bg-white/10 rounded"></div>
                            </div>
                        </div>
                        <div className="space-y-4">
                            <div className="bg-white/10 backdrop-blur-lg border border-white/20 p-4 rounded-2xl shadow-2xl">
                                <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center mb-2 text-white"><Plane className="w-6 h-6"/></div>
                                <div className="h-2 w-20 bg-white/20 rounded mb-1"></div>
                                <div className="h-2 w-12 bg-white/10 rounded"></div>
                            </div>
                        </div>
                    </div>
                </motion.div>
            </div>
         </div>
      </div>

      {/* Modern Category Tabs */}
      <div className="sticky top-20 z-30 bg-slate-50/80 dark:bg-slate-950/80 backdrop-blur-xl py-4 -mx-4 px-4 md:mx-0 md:px-0 md:bg-transparent md:backdrop-blur-none transition-all">
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide snap-x">
              {categories.map((cat) => (
                 <Button 
                    key={cat.id} 
                    variant={activeCategory === cat.id ? 'default' : 'secondary'} 
                    onClick={() => setActiveCategory(cat.id)}
                    className={`
                        snap-start rounded-full px-6 h-11 whitespace-nowrap transition-all duration-300 font-medium text-sm flex items-center gap-2
                        ${activeCategory === cat.id 
                            ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/20 scale-105' 
                            : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200 hover:border-slate-300'}
                    `}
                 >
                    {cat.icon && <cat.icon className={`w-4 h-4 ${activeCategory === cat.id ? 'text-white' : 'text-slate-400'}`} />}
                    {cat.label}
                 </Button>
              ))}
          </div>
      </div>

      {/* Dynamic Content */}
      <div className="min-h-[400px]">
          {renderContent()}
      </div>

      {/* Footer */}
      <div className="border-t border-slate-200 mt-20 pt-10 pb-6 text-center text-slate-500">
          <div className="flex justify-center gap-6 mb-4">
              <a href="#" className="hover:text-indigo-600 transition-colors">About Us</a>
              <a href="#" className="hover:text-indigo-600 transition-colors">Careers</a>
              <a href="#" className="hover:text-indigo-600 transition-colors">Privacy</a>
              <a href="#" className="hover:text-indigo-600 transition-colors">Terms</a>
          </div>
          <p className="text-sm">© 2024 DaimPost Inc. All rights reserved.</p>
      </div>

      {/* Modals */}
      <UmrahBookingDetailModal 
        isOpen={isUmrahModalOpen} 
        onClose={() => setIsUmrahModalOpen(false)} 
        booking={selectedUmrah ? { ...selectedUmrah, created_at: new Date().toISOString() } : null}
      />

      <CarListingDetailModal 
        isOpen={isCarModalOpen} 
        onClose={() => setIsCarModalOpen(false)} 
        listing={selectedCar} 
        mode="customer"
      />
    </div>
  );
};

export default AllPostsFeed;
