
import React, { useState, useEffect } from 'react';
import { Eye, Heart, MousePointer, Crown, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/supabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const StoryAnalytics = ({ userId }) => {
  const [analytics, setAnalytics] = useState({ totalViews: 0, totalLikes: 0, activeStories: [] });
  const { toast } = useToast();

  useEffect(() => {
    fetchAnalytics();
  }, [userId]);

  const fetchAnalytics = async () => {
    const { data: stories } = await supabase
      .from('stories')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (stories) {
        const totalViews = stories.reduce((sum, s) => sum + (s.views_count || 0), 0);
        const totalLikes = stories.reduce((sum, s) => sum + (s.likes_count || 0), 0);
        setAnalytics({
            totalViews,
            totalLikes,
            activeStories: stories
        });
    }
  };

  const deleteStory = async (id) => {
      const { error } = await supabase.from('stories').delete().eq('id', id);
      if (!error) {
          toast({ title: "Story Deleted" });
          fetchAnalytics();
      }
  };

  return (
    <div className="space-y-6">
        <h3 className="font-bold text-lg text-slate-800">Story Performance</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <Card>
                 <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                     <Eye className="w-6 h-6 text-blue-500 mb-2" />
                     <span className="text-2xl font-bold">{analytics.totalViews}</span>
                     <span className="text-xs text-slate-500">Total Views</span>
                 </CardContent>
             </Card>
             <Card>
                 <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                     <Heart className="w-6 h-6 text-red-500 mb-2" />
                     <span className="text-2xl font-bold">{analytics.totalLikes}</span>
                     <span className="text-xs text-slate-500">Total Likes</span>
                 </CardContent>
             </Card>
             <Card>
                 <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                     <MousePointer className="w-6 h-6 text-emerald-500 mb-2" />
                     <span className="text-2xl font-bold">{Math.round(analytics.totalViews * 0.12)}</span>
                     <span className="text-xs text-slate-500">Est. Conversions</span>
                 </CardContent>
             </Card>
             <Card>
                 <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                     <Crown className="w-6 h-6 text-yellow-500 mb-2" />
                     <span className="text-2xl font-bold">{analytics.activeStories.filter(s => s.is_vip).length}</span>
                     <span className="text-xs text-slate-500">VIP Stories</span>
                 </CardContent>
             </Card>
        </div>

        <div className="bg-white rounded-lg border overflow-hidden">
             <div className="p-4 bg-slate-50 border-b font-semibold text-sm">Recent Stories</div>
             <div className="divide-y">
                 {analytics.activeStories.slice(0, 5).map(story => (
                     <div key={story.id} className="p-4 flex items-center gap-4">
                         <div className="w-12 h-12 rounded bg-slate-100 overflow-hidden shrink-0">
                             <img src={story.media_url} className="w-full h-full object-cover" />
                         </div>
                         <div className="flex-1 min-w-0">
                             <p className="text-sm font-medium truncate">{story.caption || 'No caption'}</p>
                             <p className="text-xs text-slate-500">
                                 {new Date(story.created_at).toLocaleDateString()} 
                                 {story.is_vip && <span className="ml-2 text-yellow-600 font-bold">VIP</span>}
                             </p>
                         </div>
                         <div className="flex items-center gap-3 text-sm text-slate-600">
                             <span className="flex items-center gap-1"><Eye className="w-3 h-3"/> {story.views_count}</span>
                             <span className="flex items-center gap-1"><Heart className="w-3 h-3"/> {story.likes_count}</span>
                             <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => deleteStory(story.id)}>
                                 <Trash2 className="w-4 h-4"/>
                             </Button>
                         </div>
                     </div>
                 ))}
                 {analytics.activeStories.length === 0 && <div className="p-8 text-center text-slate-500 text-sm">No stories posted.</div>}
             </div>
        </div>
    </div>
  );
};

export default StoryAnalytics;
