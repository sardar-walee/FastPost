
import React from 'react';
import { Star, MapPin, Clock, Truck, Users, Calendar, Fuel, Gauge, Settings, ShieldCheck, Heart, Trash2, Ban } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { isRestaurantOpen } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const formatPrice = (price) => new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(price);

const DeleteButton = ({ onDelete, itemName }) => (
  <AlertDialog>
    <AlertDialogTrigger asChild>
      <Button variant="ghost" size="icon" className="absolute top-3 left-3 w-8 h-8 bg-white/90 backdrop-blur-md rounded-full text-red-500 hover:bg-red-500 hover:text-white transition-all shadow-sm z-20" onClick={(e) => e.stopPropagation()}>
        <Trash2 className="w-4 h-4" />
      </Button>
    </AlertDialogTrigger>
    <AlertDialogContent>
      <AlertDialogHeader>
        <AlertDialogTitle>Delete {itemName}?</AlertDialogTitle>
        <AlertDialogDescription>
          This action will move the item to the trash. You can restore it later from the archives.
        </AlertDialogDescription>
      </AlertDialogHeader>
      <AlertDialogFooter>
        <AlertDialogCancel onClick={(e) => e.stopPropagation()}>Cancel</AlertDialogCancel>
        <AlertDialogAction onClick={(e) => { e.stopPropagation(); onDelete(); }} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
);

const CardImage = ({ src, alt, badge, onFavorite, onDelete, isBlocked }) => (
  <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
    <img 
      src={src || 'https://via.placeholder.com/400x300?text=No+Image'} 
      alt={alt} 
      className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out ${isBlocked ? 'grayscale' : ''}`}
      loading="lazy"
    />
    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60" />
    
    {isBlocked && (
       <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex items-center justify-center z-20">
          <Badge variant="destructive" className="text-sm font-bold tracking-wider px-4 py-2 uppercase"><Ban className="w-4 h-4 mr-2"/> Unavailable</Badge>
       </div>
    )}

    {badge && (
      <div className="absolute bottom-3 left-3 z-10 flex flex-wrap gap-2">
        {badge}
      </div>
    )}
    
    {onDelete && <DeleteButton onDelete={onDelete} itemName={alt} />}

    <button 
        onClick={(e) => { e.stopPropagation(); onFavorite?.(); }}
        className="absolute top-3 right-3 w-9 h-9 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center text-slate-400 hover:text-red-500 hover:bg-white transition-all shadow-sm z-20 group/heart"
    >
        <Heart className="w-5 h-5 group-hover/heart:fill-current transition-colors" />
    </button>
  </div>
);

export const RestaurantCard = ({ data, onAction, onFavorite, onDelete }) => {
  const { isOpen, text } = isRestaurantOpen(data.restaurant_hours || []);
  
  return (
    <div 
        className={`bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden group hover:shadow-xl hover:-translate-y-1 transition-all duration-300 h-full flex flex-col cursor-pointer ${data.is_blocked ? 'opacity-80' : ''}`}
        onClick={() => onAction(data)}
    >
      <CardImage 
        src={data.image_url} 
        alt={data.name} 
        isBlocked={data.is_blocked}
        onDelete={onDelete}
        badge={
          <>
            {data.discount > 0 && <Badge className="bg-rose-500 text-white border-0 shadow-sm">{data.discount}% OFF</Badge>}
            <Badge className={`border-0 shadow-sm ${isOpen ? "bg-emerald-500 text-white" : "bg-slate-600 text-white"}`}>
               {text}
            </Badge>
          </>
        }
        onFavorite={onFavorite}
      />
      
      <div className="p-5 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-2">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg line-clamp-1">{data.name}</h3>
            <div className="flex items-center gap-1 bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded-lg text-slate-700 dark:text-slate-300 text-xs font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{data.rating || 4.5}</span>
            </div>
        </div>
        
        <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-1 mb-4">{data.cuisine_type || 'International'} • {data.location}</p>
        
        <div className="flex items-center gap-4 mt-auto pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 font-medium">
            <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-indigo-500" />
                <span>{data.delivery_time || '30-45'} min</span>
            </div>
            <div className="flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-emerald-500" />
                <span>{data.delivery_fee === 0 ? 'Free' : formatPrice(data.delivery_fee || 2000)}</span>
            </div>
        </div>
      </div>
    </div>
  );
};

export const CarCard = ({ data, onAction, onFavorite, onDelete }) => {
  const statusColors = {
    available: 'bg-emerald-500',
    sold: 'bg-rose-500',
    reserved: 'bg-amber-500'
  };

  const mainImage = data.images && data.images.length > 0 ? data.images[0] : (data.image_url || 'https://via.placeholder.com/400x300');

  return (
    <div 
        className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden group hover:shadow-xl hover:-translate-y-1 transition-all duration-300 h-full flex flex-col cursor-pointer"
        onClick={() => onAction(data)}
    >
      <CardImage 
        src={mainImage} 
        alt={`${data.make} ${data.model}`} 
        isBlocked={data.availability_status === 'blocked'} 
        onDelete={onDelete}
        badge={
          <>
            <Badge variant="secondary" className="bg-white/90 backdrop-blur text-slate-900 font-bold border-0 shadow-sm">{data.year}</Badge>
            {data.damage_assessment === 'Messed' && <Badge className="bg-rose-600 text-white border-0 shadow-sm">DAMAGED</Badge>}
          </>
        }
        onFavorite={onFavorite}
      />
      
      <div className="p-5 flex-1 flex flex-col">
        <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg line-clamp-1 mb-1">{data.make} {data.model}</h3>
        <p className="text-lg font-bold text-indigo-600 dark:text-indigo-400 mb-4">{formatPrice(data.price)}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
            <span className="bg-slate-50 dark:bg-slate-800 px-2 py-1.5 rounded-lg flex items-center gap-1.5 text-[11px] font-medium text-slate-600 dark:text-slate-300">
                <Gauge className="w-3.5 h-3.5 text-slate-400" /> {data.mileage ? `${data.mileage}km` : '0km'}
            </span>
            <span className="bg-slate-50 dark:bg-slate-800 px-2 py-1.5 rounded-lg flex items-center gap-1.5 text-[11px] font-medium text-slate-600 dark:text-slate-300">
                <Fuel className="w-3.5 h-3.5 text-slate-400" /> {data.fuel_type || 'Petrol'}
            </span>
            <span className="bg-slate-50 dark:bg-slate-800 px-2 py-1.5 rounded-lg flex items-center gap-1.5 text-[11px] font-medium text-slate-600 dark:text-slate-300">
                <Settings className="w-3.5 h-3.5 text-slate-400" /> {data.transmission || 'Auto'}
            </span>
        </div>

        <div className="mt-auto pt-4 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs text-slate-500 flex items-center gap-1.5 truncate max-w-[120px]">
                <MapPin className="w-3.5 h-3.5" /> {data.location || 'Iraq'}
            </span>
            <span className={`text-xs font-bold px-2 py-1 rounded-full ${data.availability_status === 'available' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                {data.availability_status || 'Available'}
            </span>
        </div>
      </div>
    </div>
  );
};

export const UmrahCard = ({ data, onAction, onFavorite, onDelete }) => {
  return (
    <div 
        className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden group hover:shadow-xl hover:-translate-y-1 transition-all duration-300 h-full flex flex-col cursor-pointer"
        onClick={() => onAction(data)}
    >
      <CardImage 
        src={data.image_url} 
        alt={data.title} 
        onDelete={onDelete}
        badge={<Badge className="bg-emerald-600 text-white border-0 shadow-sm flex gap-1"><ShieldCheck className="w-3 h-3"/> Certified</Badge>}
        onFavorite={onFavorite}
      />
      
      <div className="p-5 flex-1 flex flex-col">
        <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg line-clamp-1 mb-1">{data.title}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mb-4">
            <MapPin className="w-3.5 h-3.5" /> {data.departure_city || 'Baghdad'}
        </p>
        
        <div className="grid grid-cols-2 gap-3 mb-4">
             <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl flex items-center gap-2.5">
                 <div className="bg-white dark:bg-slate-700 p-1.5 rounded-lg shadow-sm">
                    <Calendar className="w-4 h-4 text-indigo-500" />
                 </div>
                 <div className="flex flex-col">
                     <span className="text-[10px] text-slate-400 uppercase tracking-wide">Duration</span>
                     <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{data.duration || '10 Days'}</span>
                 </div>
             </div>
             <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-xl flex items-center gap-2.5">
                 <div className="bg-white dark:bg-slate-700 p-1.5 rounded-lg shadow-sm">
                    <Users className="w-4 h-4 text-emerald-500" />
                 </div>
                 <div className="flex flex-col">
                     <span className="text-[10px] text-slate-400 uppercase tracking-wide">Seats</span>
                     <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{data.remaining_seats || 5} Left</span>
                 </div>
             </div>
        </div>

        <div className="mt-auto pt-4 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
            <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 font-medium uppercase tracking-wide">Starting from</span>
                <span className="text-lg font-bold text-emerald-600">{formatPrice(data.price)}</span>
            </div>
            <Button size="sm" className="rounded-xl px-5 bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 dark:hover:bg-slate-600 text-white font-semibold">Book</Button>
        </div>
      </div>
    </div>
  );
};
