
import React from 'react';
import { Home, Newspaper, ShoppingBag, User, List, Utensils, Plane, Car, LayoutDashboard, Settings, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';

const BottomNav = ({ currentSection, setCurrentSection, userRole = 'customer', cartCount }) => {
  const { t } = useTranslation();

  const handleNav = (section) => {
    setCurrentSection(section);
  };

  const NavItem = ({ section, icon: Icon, label, onClick, isActive }) => (
    <div className="flex-1 flex justify-center">
       <button 
           className="relative flex flex-col items-center justify-center w-full h-full py-2 gap-1 group"
           onClick={onClick}
        >
           {isActive && (
             <motion.div 
               layoutId="activeNavTab"
               className="absolute -top-0.5 h-1 w-12 bg-indigo-600 rounded-b-full shadow-[0_4px_12px_rgba(99,102,241,0.5)]"
               transition={{ type: "spring", stiffness: 300, damping: 30 }}
             />
           )}
           
           <div className={`p-1.5 rounded-xl transition-all duration-300 ${isActive ? 'text-indigo-600 bg-indigo-50 -translate-y-1' : 'text-slate-400 group-active:scale-95'}`}>
              <Icon className={`w-6 h-6 ${isActive ? 'fill-indigo-600/20 stroke-[2.5px]' : 'stroke-2'}`} />
           </div>
           
           <span className={`text-[10px] font-medium transition-colors duration-300 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`}>
              {label}
           </span>
        </button>
    </div>
  );

  // Define menus for different roles
  const getMenu = () => {
    if (userRole === 'car_dealer') {
      return [
        { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
        { id: 'inventory', icon: Car, label: 'Inventory' },
        { id: 'home', icon: Home, label: 'Home' }, // Allow dealer to see customer view
        { id: 'profile', icon: User, label: 'Profile' }
      ];
    }
    
    if (userRole === 'restaurant_owner') {
        return [
            { id: 'dashboard', icon: LayoutDashboard, label: 'Dash' },
            { id: 'orders', icon: List, label: 'Orders' },
            { id: 'menu', icon: Utensils, label: 'Menu' },
            { id: 'settings', icon: Settings, label: 'Settings' }
        ];
    }

    // Default Customer
    return [
      { id: 'feed', icon: Home, label: 'Feed' },
      { id: 'food', icon: Utensils, label: 'Food' },
      { id: 'cart', icon: ShoppingBag, label: 'Cart', isFab: true },
      { id: 'orders', icon: List, label: 'Orders' },
      { id: 'profile', icon: User, label: 'Profile' }
    ];
  };

  const menuItems = getMenu();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 pb-safe-area shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
       <div className="flex items-end justify-between px-1 h-16 pb-1">
          {menuItems.map((item) => {
              if (item.isFab) {
                  return (
                      <div key={item.id} className="flex-1 flex justify-center -mt-6 relative z-10">
                        <motion.button
                           whileTap={{ scale: 0.9 }}
                           className="h-14 w-14 rounded-full bg-gradient-to-tr from-indigo-600 to-indigo-500 shadow-xl shadow-indigo-200 flex items-center justify-center text-white border-4 border-white dark:border-slate-900 relative"
                           onClick={() => handleNav(item.id === 'cart' ? 'food' : item.id)}
                        >
                           <item.icon className="w-6 h-6" />
                           {cartCount > 0 && (
                              <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white ring-2 ring-white">
                                {cartCount}
                              </span>
                           )}
                        </motion.button>
                      </div>
                  );
              }

              return (
                <NavItem 
                    key={item.id}
                    section={item.id}
                    icon={item.icon}
                    label={item.label}
                    isActive={currentSection === item.id}
                    onClick={() => handleNav(item.id)}
                />
              );
          })}
       </div>
    </div>
  );
};

export default BottomNav;
