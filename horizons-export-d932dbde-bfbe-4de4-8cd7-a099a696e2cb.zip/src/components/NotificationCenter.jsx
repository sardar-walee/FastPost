
import React, { useState, useEffect } from 'react';
import { Bell, Settings, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/supabaseClient';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

const NotificationCenter = ({ user }) => {
  const { t } = useTranslation();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      fetchNotifications();
      
      const subscription = supabase
        .channel('public:notifications')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` }, payload => {
          setNotifications(prev => [payload.new, ...prev]);
          setUnreadCount(prev => prev + 1);
          playNotificationSound();
          toast({
             title: payload.new.title,
             description: payload.new.message,
             className: "border-l-4 border-emerald-500"
          });
        })
        .subscribe();

      return () => { subscription.unsubscribe(); };
    }
  }, [user]);

  const fetchNotifications = async () => {
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(20);
    
    if (data) {
      setNotifications(data);
      setUnreadCount(data.filter(n => !n.read_status).length);
    }
  };

  const playNotificationSound = () => {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3'); 
    audio.volume = 0.5;
    audio.play().catch(e => console.log("Audio play blocked", e));
  };

  const markAllRead = async () => {
    await supabase.from('notifications').update({ read_status: true }).eq('user_id', user.id);
    setNotifications(prev => prev.map(n => ({ ...n, read_status: true })));
    setUnreadCount(0);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative hover:bg-white/10 text-white rounded-full">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute top-2 right-2 h-2.5 w-2.5 rounded-full bg-red-500 border-2 border-emerald-600 animate-pulse"></span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0 rounded-xl overflow-hidden shadow-2xl border-slate-100">
        <div className="bg-slate-50 p-3 flex justify-between items-center border-b">
           <span className="font-bold text-sm text-slate-700">{t('notifications')}</span>
           {unreadCount > 0 && (
              <Button variant="ghost" size="sm" onClick={markAllRead} className="h-6 text-xs text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 px-2">
                 Mark all read
              </Button>
           )}
        </div>
        
        <ScrollArea className="h-[350px]">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-slate-400">
               <Bell className="w-8 h-8 mb-2 opacity-20"/>
               <p className="text-xs">{t('no_notifications')}</p>
            </div>
          ) : (
            <div className="flex flex-col">
              {notifications.map((n) => (
                <div key={n.id} className={`p-4 border-b last:border-0 hover:bg-slate-50 transition-colors cursor-pointer ${!n.read_status ? 'bg-blue-50/40' : ''}`}>
                   <div className="flex justify-between items-start mb-1">
                      <h4 className={`text-sm ${!n.read_status ? 'font-bold text-slate-900' : 'font-medium text-slate-700'}`}>{n.title}</h4>
                      <span className="text-[10px] text-slate-400 whitespace-nowrap ml-2">{new Date(n.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                   </div>
                   <p className="text-xs text-slate-500 line-clamp-2">{n.message}</p>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
        <div className="p-2 border-t bg-slate-50">
            <Button variant="ghost" size="sm" className="w-full text-xs text-slate-500" onClick={() => window.location.hash = '#settings'}>
                <Settings className="w-3 h-3 mr-2" /> Notification Settings
            </Button>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default NotificationCenter;
