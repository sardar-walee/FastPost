
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Utensils, ShoppingBag, Users, FileBox, 
  Ticket, BarChart2, Settings, Store, Wallet, Truck
} from 'lucide-react';
import { supabase } from '@/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Import Manager Components
import MenuManager from '@/components/restaurant/MenuManager';
import OrderManager from '@/components/restaurant/OrderManager';
import StaffManager from '@/components/restaurant/StaffManager';
import DriverManager from '@/components/restaurant/DriverManager';
import InventoryManager from '@/components/restaurant/InventoryManager';
import MarketingManager from '@/components/restaurant/MarketingManager';
import AnalyticsManager from '@/components/restaurant/AnalyticsManager';
import SettingsManager from '@/components/restaurant/SettingsManager';
import FinanceManager from '@/components/restaurant/FinanceManager';
import { Card, CardContent } from '@/components/ui/card';

const RestaurantDashboard = ({ user, activeTab = 'overview' }) => {
  const [restaurant, setRestaurant] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const [currentTab, setCurrentTab] = useState(activeTab);

  useEffect(() => {
    fetchRestaurant();
  }, [user]);

  useEffect(() => {
    setCurrentTab(activeTab);
  }, [activeTab]);

  const fetchRestaurant = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('restaurants')
        .select('*')
        .eq('owner_id', user.id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      setRestaurant(data);
    } catch (error) {
      console.error('Error fetching restaurant:', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to load restaurant data.' });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
        <Store className="w-16 h-16 text-slate-300 mb-4" />
        <h2 className="text-2xl font-bold text-slate-800">No Restaurant Found</h2>
        <p className="text-slate-500 max-w-md mt-2">
          You haven't set up a restaurant profile yet. Please contact support or check your account status.
        </p>
      </div>
    );
  }

  const renderOverview = () => (
    <div className="space-y-4 md:space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
        <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white border-0 shadow-lg relative overflow-hidden">
           <CardContent className="p-4 md:p-6 relative z-10">
              <p className="text-emerald-100 font-medium text-xs md:text-sm">Orders</p>
              <h3 className="text-2xl md:text-4xl font-bold mt-1 md:mt-2">24</h3>
              <p className="text-emerald-100 text-[10px] md:text-sm mt-2 md:mt-4 bg-emerald-700/30 inline-block px-1.5 py-0.5 rounded">+12%</p>
           </CardContent>
           <ShoppingBag className="absolute right-[-10px] bottom-[-10px] w-20 h-20 text-white/10 rotate-12" />
        </Card>
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 shadow-lg relative overflow-hidden">
           <CardContent className="p-4 md:p-6 relative z-10">
              <p className="text-blue-100 font-medium text-xs md:text-sm">Revenue</p>
              <h3 className="text-2xl md:text-4xl font-bold mt-1 md:mt-2">{new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(restaurant.wallet_balance || 0)}</h3>
              <p className="text-blue-100 text-[10px] md:text-sm mt-2 md:mt-4 bg-blue-700/30 inline-block px-1.5 py-0.5 rounded">IQD</p>
           </CardContent>
           <BarChart2 className="absolute right-[-10px] bottom-[-10px] w-20 h-20 text-white/10 rotate-12" />
        </Card>
        <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white border-0 shadow-lg relative overflow-hidden">
           <CardContent className="p-4 md:p-6 relative z-10">
              <p className="text-indigo-100 font-medium text-xs md:text-sm">Menu Items</p>
              <h3 className="text-2xl md:text-4xl font-bold mt-1 md:mt-2">42</h3>
              <p className="text-indigo-100 text-[10px] md:text-sm mt-2 md:mt-4 bg-indigo-700/30 inline-block px-1.5 py-0.5 rounded">Active</p>
           </CardContent>
           <Utensils className="absolute right-[-10px] bottom-[-10px] w-20 h-20 text-white/10 rotate-12" />
        </Card>
        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0 shadow-lg relative overflow-hidden">
           <CardContent className="p-4 md:p-6 relative z-10">
              <p className="text-purple-100 font-medium text-xs md:text-sm">Staff</p>
              <h3 className="text-2xl md:text-4xl font-bold mt-1 md:mt-2">6</h3>
              <p className="text-purple-100 text-[10px] md:text-sm mt-2 md:mt-4 bg-purple-700/30 inline-block px-1.5 py-0.5 rounded">Online</p>
           </CardContent>
           <Users className="absolute right-[-10px] bottom-[-10px] w-20 h-20 text-white/10 rotate-12" />
        </Card>
      </div>
      <AnalyticsManager restaurantId={restaurant.id} />
    </div>
  );

  return (
    <div className="space-y-4 md:space-y-6 max-w-7xl mx-auto pb-24 md:pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
         <div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-900">{restaurant.name}</h1>
            <p className="text-sm md:text-base text-slate-500">Restaurant Management Dashboard</p>
         </div>
         <div className="flex items-center gap-2 self-start md:self-auto">
            <span className={`px-3 py-1 rounded-full text-xs md:text-sm font-medium ${restaurant.is_online ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
               {restaurant.is_online ? 'Open for Orders' : 'Closed'}
            </span>
         </div>
      </div>

      <Tabs value={currentTab} onValueChange={setCurrentTab} className="space-y-4 md:space-y-6">
         <div className="sticky top-16 md:top-20 z-20 bg-slate-50/95 dark:bg-slate-950/95 backdrop-blur py-2 -mx-4 px-4 md:mx-0 md:px-0 md:py-0 md:static">
             <TabsList className="bg-white border p-1 h-auto flex flex-nowrap md:flex-wrap overflow-x-auto w-full justify-start md:justify-start scrollbar-hide md:scrollbar-default gap-1 md:gap-0">
                <TabsTrigger value="overview" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><LayoutDashboard className="w-3 h-3 md:w-4 md:h-4"/> <span className="hidden md:inline">Overview</span></TabsTrigger>
                <TabsTrigger value="orders" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><ShoppingBag className="w-3 h-3 md:w-4 md:h-4"/> Orders</TabsTrigger>
                <TabsTrigger value="menu" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><Utensils className="w-3 h-3 md:w-4 md:h-4"/> Menu</TabsTrigger>
                <TabsTrigger value="finance" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><Wallet className="w-3 h-3 md:w-4 md:h-4"/> <span className="hidden md:inline">Finance</span></TabsTrigger>
                <TabsTrigger value="staff" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><Users className="w-3 h-3 md:w-4 md:h-4"/> Staff</TabsTrigger>
                <TabsTrigger value="drivers" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><Truck className="w-3 h-3 md:w-4 md:h-4"/> Drivers</TabsTrigger>
                <TabsTrigger value="inventory" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><FileBox className="w-3 h-3 md:w-4 md:h-4"/> <span className="hidden md:inline">Inventory</span></TabsTrigger>
                <TabsTrigger value="marketing" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><Ticket className="w-3 h-3 md:w-4 md:h-4"/> <span className="hidden md:inline">Marketing</span></TabsTrigger>
                <TabsTrigger value="analytics" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><BarChart2 className="w-3 h-3 md:w-4 md:h-4"/> <span className="hidden md:inline">Analytics</span></TabsTrigger>
                <TabsTrigger value="settings" className="gap-2 px-3 py-2 flex-shrink-0 text-xs md:text-sm"><Settings className="w-3 h-3 md:w-4 md:h-4"/> <span className="hidden md:inline">Settings</span></TabsTrigger>
             </TabsList>
         </div>

         <div className="bg-white/50 backdrop-blur-sm rounded-2xl">
            <TabsContent value="overview" className="m-0 focus-visible:ring-0">{renderOverview()}</TabsContent>
            <TabsContent value="orders" className="m-0 focus-visible:ring-0"><OrderManager restaurantId={restaurant.id} /></TabsContent>
            <TabsContent value="menu" className="m-0 focus-visible:ring-0"><MenuManager restaurantId={restaurant.id} /></TabsContent>
            <TabsContent value="finance" className="m-0 focus-visible:ring-0"><FinanceManager restaurantId={restaurant.id} /></TabsContent>
            <TabsContent value="staff" className="m-0 focus-visible:ring-0"><StaffManager restaurantId={restaurant.id} /></TabsContent>
            <TabsContent value="drivers" className="m-0 focus-visible:ring-0"><DriverManager restaurantId={restaurant.id} /></TabsContent>
            <TabsContent value="inventory" className="m-0 focus-visible:ring-0"><InventoryManager restaurantId={restaurant.id} /></TabsContent>
            <TabsContent value="marketing" className="m-0 focus-visible:ring-0"><MarketingManager restaurantId={restaurant.id} /></TabsContent>
            <TabsContent value="analytics" className="m-0 focus-visible:ring-0"><AnalyticsManager restaurantId={restaurant.id} fullView /></TabsContent>
            <TabsContent value="settings" className="m-0 focus-visible:ring-0"><SettingsManager restaurant={restaurant} onUpdate={fetchRestaurant} /></TabsContent>
         </div>
      </Tabs>
    </div>
  );
};

export default RestaurantDashboard;
