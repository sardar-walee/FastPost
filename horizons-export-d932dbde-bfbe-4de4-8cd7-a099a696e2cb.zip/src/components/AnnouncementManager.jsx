
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { 
  Plus, Edit, Trash2, Eye, Share2, Calendar, 
  BarChart2, ExternalLink, Copy, Check, Link as LinkIcon
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const AnnouncementManager = ({ user }) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [announcements, setAnnouncements] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [currentAnnouncement, setCurrentAnnouncement] = useState(null);
  const [formData, setFormData] = useState({
    title: '', description: '', link: '', image_url: '', 
    status: 'published', scheduled_at: ''
  });
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchAnnouncements();
  }, [user]);

  const fetchAnnouncements = async () => {
    let query = supabase.from('announcements').select('*').order('created_at', { ascending: false });
    const { data } = await query;
    if (data) setAnnouncements(data);
  };

  const handleSubmit = async () => {
    if (!formData.title) return;

    const payload = {
        ...formData,
        created_by: user.id,
        scheduled_at: formData.status === 'scheduled' ? formData.scheduled_at : null
    };

    let error;
    if (currentAnnouncement) {
        const { error: err } = await supabase.from('announcements').update(payload).eq('id', currentAnnouncement.id);
        error = err;
    } else {
        const { error: err } = await supabase.from('announcements').insert([payload]);
        error = err;
    }

    if (error) {
        toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else {
        toast({ title: 'Success', description: currentAnnouncement ? 'Updated' : 'Created' });
        setIsDialogOpen(false);
        setFormData({ title: '', description: '', link: '', image_url: '', status: 'published', scheduled_at: '' });
        setCurrentAnnouncement(null);
        fetchAnnouncements();
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm(t('Are you sure?'))) return;
    const { error } = await supabase.from('announcements').delete().eq('id', id);
    if (!error) {
        setAnnouncements(prev => prev.filter(a => a.id !== id));
        toast({ title: t('delete'), description: t('success') });
    }
  };

  const handleEdit = (announcement) => {
    setCurrentAnnouncement(announcement);
    setFormData({
        title: announcement.title,
        description: announcement.description,
        link: announcement.link,
        image_url: announcement.image_url,
        status: announcement.status,
        scheduled_at: announcement.scheduled_at || ''
    });
    setIsDialogOpen(true);
  };

  const openShareModal = (announcement) => {
    setCurrentAnnouncement(announcement);
    setIsShareOpen(true);
  };

  const handleShareClick = async (platform) => {
    // Increment share count in DB
    await supabase.rpc('increment_announcement_share', { row_id: currentAnnouncement.id });
    
    // Refresh local stats
    setAnnouncements(prev => prev.map(a => a.id === currentAnnouncement.id ? { ...a, shares_count: (a.shares_count || 0) + 1 } : a));

    const url = encodeURIComponent(currentAnnouncement.link || window.location.href);
    const text = encodeURIComponent(currentAnnouncement.title);
    
    let shareUrl = '';
    switch(platform) {
        case 'facebook': shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`; break;
        case 'whatsapp': shareUrl = `https://wa.me/?text=${text}%20${url}`; break;
        case 'twitter': shareUrl = `https://twitter.com/intent/tweet?text=${text}&url=${url}`; break;
        case 'linkedin': shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`; break;
        case 'tiktok': 
        case 'instagram':
             // No direct web share API for these, copy link instead
             copyToClipboard();
             toast({ title: "Link Copied", description: `Paste this link in ${platform} to share!` });
             return;
        default: break;
    }
    if (shareUrl) window.open(shareUrl, '_blank');
  };

  const copyToClipboard = () => {
     navigator.clipboard.writeText(currentAnnouncement.link || window.location.href);
     setCopied(true);
     setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
      if (navigator.share) {
          try {
              await navigator.share({
                  title: currentAnnouncement.title,
                  text: currentAnnouncement.description,
                  url: currentAnnouncement.link || window.location.href
              });
              await supabase.rpc('increment_announcement_share', { row_id: currentAnnouncement.id });
          } catch (err) {
              console.log('Error sharing', err);
          }
      } else {
          copyToClipboard();
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t('announcements')}</h2>
        <Button onClick={() => { setCurrentAnnouncement(null); setFormData({ title: '', description: '', link: '', image_url: '', status: 'published' }); setIsDialogOpen(true); }} className="bg-emerald-600 gap-2">
            <Plus className="w-4 h-4" /> {t('create_announcement')}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {announcements.map((item) => (
            <Card key={item.id} className="overflow-hidden flex flex-col group hover:shadow-lg transition-all">
                <div className="relative h-48 bg-slate-100">
                    {item.image_url ? (
                        <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
                    ) : (
                        <div className="flex items-center justify-center h-full text-slate-400">No Image</div>
                    )}
                    <div className="absolute top-2 right-2">
                        <Badge variant={item.status === 'published' ? 'default' : 'secondary'} className={item.status === 'published' ? 'bg-emerald-500' : ''}>
                            {t(item.status)}
                        </Badge>
                    </div>
                </div>
                <CardHeader className="pb-2">
                    <CardTitle className="line-clamp-1">{item.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col gap-4">
                    <p className="text-sm text-slate-500 line-clamp-2 flex-1">{item.description}</p>
                    
                    <div className="flex justify-between items-center text-xs text-slate-400 border-t pt-2">
                        <div className="flex gap-3">
                            <span className="flex items-center gap-1"><Eye className="w-3 h-3"/> {item.views_count}</span>
                            <span className="flex items-center gap-1"><Share2 className="w-3 h-3"/> {item.shares_count}</span>
                            <span className="flex items-center gap-1"><ExternalLink className="w-3 h-3"/> {item.clicks_count}</span>
                        </div>
                        {item.scheduled_at && <span>{new Date(item.scheduled_at).toLocaleDateString()}</span>}
                    </div>

                    <div className="grid grid-cols-4 gap-2 mt-auto">
                        <Button variant="outline" size="icon" onClick={() => handleEdit(item)}><Edit className="w-4 h-4"/></Button>
                        <Button variant="outline" size="icon" onClick={() => openShareModal(item)}><Share2 className="w-4 h-4"/></Button>
                        <Button variant="outline" size="icon" onClick={() => { setCurrentAnnouncement(item); setIsPreviewOpen(true); }}><Eye className="w-4 h-4"/></Button>
                        <Button variant="destructive" size="icon" onClick={() => handleDelete(item.id)}><Trash2 className="w-4 h-4"/></Button>
                    </div>
                </CardContent>
            </Card>
        ))}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
         <DialogContent className="max-w-2xl">
            <DialogHeader>
                <DialogTitle>{currentAnnouncement ? t('edit') : t('create_announcement')}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
                <div className="space-y-2">
                    <Label>{t('title')}</Label>
                    <Input value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="Announcement Title" />
                </div>
                <div className="space-y-2">
                    <Label>{t('description')}</Label>
                    <Textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Details..." />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>{t('link')}</Label>
                        <div className="relative">
                            <LinkIcon className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                            <Input className="pl-9" value={formData.link} onChange={e => setFormData({...formData, link: e.target.value})} placeholder="https://..." />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label>{t('image')}</Label>
                        <Input value={formData.image_url} onChange={e => setFormData({...formData, image_url: e.target.value})} placeholder="Image URL" />
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-4 items-center bg-slate-50 p-4 rounded-lg">
                    <div className="space-y-2">
                        <Label>{t('status')}</Label>
                        <Select value={formData.status} onValueChange={v => setFormData({...formData, status: v})}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="draft">{t('draft')}</SelectItem>
                                <SelectItem value="published">{t('publish')}</SelectItem>
                                <SelectItem value="scheduled">{t('scheduled')}</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    {formData.status === 'scheduled' && (
                        <div className="space-y-2">
                            <Label>{t('schedule_date')}</Label>
                            <Input type="datetime-local" value={formData.scheduled_at} onChange={e => setFormData({...formData, scheduled_at: e.target.value})} />
                        </div>
                    )}
                </div>
            </div>
            <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>{t('cancel')}</Button>
                <Button onClick={handleSubmit}>{t('save')}</Button>
            </DialogFooter>
         </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
         <DialogContent className="max-w-md p-0 overflow-hidden">
             {currentAnnouncement && (
                 <div className="flex flex-col">
                    <div className="relative h-64 bg-slate-100">
                        {currentAnnouncement.image_url && <img src={currentAnnouncement.image_url} className="w-full h-full object-cover" />}
                        <div className="absolute top-0 left-0 bg-emerald-600 text-white px-3 py-1 text-xs font-bold rounded-br-lg">PREVIEW</div>
                    </div>
                    <div className="p-6 space-y-4">
                        <h2 className="text-xl font-bold">{currentAnnouncement.title}</h2>
                        <p className="text-slate-600">{currentAnnouncement.description}</p>
                        {currentAnnouncement.link && (
                            <Button className="w-full bg-emerald-600" onClick={() => window.open(currentAnnouncement.link, '_blank')}>
                                {t('view')} <ExternalLink className="w-4 h-4 ml-2"/>
                            </Button>
                        )}
                    </div>
                 </div>
             )}
         </DialogContent>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={isShareOpen} onOpenChange={setIsShareOpen}>
          <DialogContent className="max-w-sm">
             <DialogHeader>
                 <DialogTitle>{t('share_on')}</DialogTitle>
             </DialogHeader>
             {currentAnnouncement && (
                 <div className="space-y-6 py-4">
                     <div className="flex justify-center">
                         <img 
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(currentAnnouncement.link || window.location.href)}`} 
                            alt="QR Code" 
                            className="border p-2 rounded-lg shadow-sm"
                         />
                     </div>
                     <div className="grid grid-cols-4 gap-2">
                         <Button variant="outline" className="flex flex-col h-auto py-3 gap-2 hover:bg-blue-50 hover:text-blue-600" onClick={() => handleShareClick('facebook')}>
                             <span className="font-bold text-lg">f</span>
                             <span className="text-[10px]">Facebook</span>
                         </Button>
                         <Button variant="outline" className="flex flex-col h-auto py-3 gap-2 hover:bg-green-50 hover:text-green-600" onClick={() => handleShareClick('whatsapp')}>
                             <span className="font-bold text-lg">WA</span>
                             <span className="text-[10px]">WhatsApp</span>
                         </Button>
                         <Button variant="outline" className="flex flex-col h-auto py-3 gap-2 hover:bg-pink-50 hover:text-pink-600" onClick={() => handleShareClick('instagram')}>
                             <span className="font-bold text-lg">IG</span>
                             <span className="text-[10px]">Insta</span>
                         </Button>
                         <Button variant="outline" className="flex flex-col h-auto py-3 gap-2 hover:bg-slate-900 hover:text-white" onClick={() => handleShareClick('tiktok')}>
                             <span className="font-bold text-lg">TT</span>
                             <span className="text-[10px]">TikTok</span>
                         </Button>
                     </div>
                     
                     <Button className="w-full bg-emerald-600" onClick={handleNativeShare}>
                         <Share2 className="w-4 h-4 mr-2" /> Share via...
                     </Button>

                     <div className="flex gap-2">
                         <Input value={currentAnnouncement.link || ''} readOnly className="bg-slate-50" />
                         <Button size="icon" onClick={copyToClipboard} variant={copied ? "default" : "outline"} className={copied ? "bg-green-600" : ""}>
                             {copied ? <Check className="w-4 h-4"/> : <Copy className="w-4 h-4"/>}
                         </Button>
                     </div>
                 </div>
             )}
          </DialogContent>
      </Dialog>
    </div>
  );
};

export default AnnouncementManager;
