
import React from 'react';
import { motion } from 'framer-motion';
import { Package, Truck, CheckCircle, Clock, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const STATUS_CONFIG = {
  pending: { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Pending', step: 1 },
  preparing: { icon: Package, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Preparing', step: 2 },
  delivering: { icon: Truck, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'On the Way', step: 3 },
  delivered: { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50', label: 'Delivered', step: 4 }
};

const OrderTracking = ({ orders }) => {
  const activeOrders = orders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled');

  if (activeOrders.length === 0) return null;

  return (
    <div className="bg-white rounded-3xl shadow-xl p-6 border border-slate-100">
      <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
        <Truck className="w-5 h-5 text-emerald-600" /> Active Orders
      </h3>
      <div className="space-y-6">
        {activeOrders.map((order) => {
          const status = STATUS_CONFIG[order.status] || STATUS_CONFIG.pending;
          return (
            <div key={order.id} className="space-y-3">
               <div className="flex justify-between items-center">
                   <span className="font-bold text-sm text-slate-700">Order #{order.id.slice(0, 6)}</span>
                   <Badge className={`${status.bg} ${status.color} border-0`}>{status.label}</Badge>
               </div>
               
               {/* Visual Map Placeholder / Live Tracking */}
               <div className="h-32 bg-slate-100 rounded-xl overflow-hidden relative border border-slate-200">
                   <div className="absolute inset-0 bg-[url('https://api.mapbox.com/styles/v1/mapbox/streets-v11/static/44.3615,33.3128,12,0/400x200?access_token=pk.xxx')] bg-cover bg-center opacity-50 grayscale"></div>
                   
                   {/* Animated Bike Marker */}
                   {order.status === 'delivering' && (
                       <motion.div 
                          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
                          animate={{ x: [0, 20, 0, -20, 0], y: [0, -10, 0, 10, 0] }}
                          transition={{ duration: 10, repeat: Infinity }}
                       >
                           <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center text-white shadow-lg border-2 border-white">
                              <Truck className="w-4 h-4" />
                           </div>
                       </motion.div>
                   )}

                   {/* Static Status if not delivering */}
                   {order.status !== 'delivering' && (
                       <div className="absolute inset-0 flex items-center justify-center">
                           <div className="bg-white/80 backdrop-blur px-4 py-2 rounded-full text-xs font-bold shadow-sm">
                               {order.status === 'preparing' ? 'Kitchen is preparing...' : 'Waiting for confirmation...'}
                           </div>
                       </div>
                   )}
               </div>

               {/* Progress Steps */}
               <div className="flex justify-between items-center px-1">
                   {[1, 2, 3, 4].map(step => (
                       <div key={step} className="flex flex-col items-center gap-1">
                           <div className={`w-2 h-2 rounded-full ${step <= status.step ? 'bg-emerald-500' : 'bg-slate-200'}`}></div>
                       </div>
                   ))}
               </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default OrderTracking;
