
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { MapPin } from 'lucide-react';

const LocationSelector = ({ isOpen, onSelect, cities }) => {
  const { t } = useTranslation();

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()} onEscapeKeyDown={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold text-slate-800">Select Location</DialogTitle>
          <DialogDescription className="text-center">
            {t('location_selector_desc')}
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[60vh] overflow-y-auto p-2">
          {cities.map((city) => (
            <Button
              key={city}
              variant="outline"
              className="flex flex-col items-center justify-center h-20 gap-2 hover:bg-emerald-50 hover:border-emerald-500 hover:text-emerald-700 transition-all"
              onClick={() => onSelect(city)}
            >
              <MapPin className="w-5 h-5 text-emerald-600" />
              <span className="text-xs font-medium text-center whitespace-normal">{city}</span>
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LocationSelector;
