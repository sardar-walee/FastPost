
import React, { useState, useEffect } from 'react';
import { supabase } from '@/supabaseClient';
import { Plus } from 'lucide-react';
import StoryViewer from '@/components/StoryViewer';
import AddStoryModal from '@/components/AddStoryModal';
import { useToast } from '@/components/ui/use-toast';

const StoriesBar = ({ user, userRole }) => {
  const [stories, setStories] = useState([]);
  const [groupedStories, setGroupedStories] = useState({});
  const [loading, setLoading] = useState(true);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [selectedStoryGroup, setSelectedStoryGroup] = useState([]);
  
  const { toast } = useToast();
  const canAddStory = ['restaurant_owner', 'umrah_company', 'car_dealer', 'admin'].includes(userRole);

  useEffect(() => {
    fetchStories();

    // Subscribe to new stories
    const subscription = supabase
      .channel('stories_update')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stories' }, () => {
        fetchStories();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchStories = async () => {
    try {
      const { data, error } = await supabase
        .from('stories')
        .select('*')
        .gt('expires_at', new Date().toISOString())
        .order('created_at', { ascending: false });

      if (error) throw error;

      setStories(data || []);
      
      // Group by User/Business
      const grouped = (data || []).reduce((acc, story) => {
        if (!acc[story.user_id]) {
          acc[story.user_id] = {
            user_id: story.user_id,
            business_name: story.business_name,
            role: story.role,
            items: [],
            latest_media: story.media_url,
            has_vip: false
          };
        }
        acc[story.user_id].items.push(story);
        if (story.is_vip) acc[story.user_id].has_vip = true;
        return acc;
      }, {});

      setGroupedStories(grouped);
    } catch (error) {
      console.error("Error fetching stories:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleStoryClick = (userId) => {
    const userStories = groupedStories[userId].items;
    setSelectedStoryGroup(userStories);
    setViewerOpen(true);
  };

  return (
    <div className="w-full bg-white border-b py-4 overflow-x-auto no-scrollbar">
       <div className="container mx-auto px-4 flex gap-4">
          
          {/* Add Story Button (If Authorized) */}
          {canAddStory && (
            <div className="flex flex-col items-center gap-1 shrink-0 cursor-pointer" onClick={() => setAddModalOpen(true)}>
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-slate-300 flex items-center justify-center bg-slate-50 hover:bg-slate-100 transition-colors relative">
                    <Plus className="w-6 h-6 text-emerald-600" />
                    <div className="absolute bottom-0 right-0 bg-emerald-600 text-white rounded-full p-0.5 border-2 border-white">
                        <Plus className="w-3 h-3" />
                    </div>
                </div>
                <span className="text-xs font-medium text-slate-600 truncate w-16 text-center">Your Story</span>
            </div>
          )}

          {/* Story Circles */}
          {Object.values(groupedStories).map((group) => (
             <div 
                key={group.user_id} 
                className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group"
                onClick={() => handleStoryClick(group.user_id)}
             >
                <div className={`w-16 h-16 rounded-full p-[2px] ${group.has_vip ? 'bg-gradient-to-tr from-yellow-400 via-orange-500 to-red-500 animate-pulse' : 'bg-gradient-to-tr from-emerald-500 to-teal-400'}`}>
                    <div className="w-full h-full rounded-full border-2 border-white overflow-hidden bg-white">
                        <img src={group.latest_media} alt={group.business_name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    </div>
                </div>
                <span className="text-xs font-medium text-slate-700 truncate w-20 text-center">
                    {group.business_name || 'User'}
                </span>
             </div>
          ))}

          {loading && Object.keys(groupedStories).length === 0 && (
              [1,2,3,4].map(i => (
                 <div key={i} className="flex flex-col items-center gap-1 shrink-0 animate-pulse">
                     <div className="w-16 h-16 rounded-full bg-slate-200"></div>
                     <div className="w-12 h-2 rounded bg-slate-200"></div>
                 </div>
              ))
          )}
       </div>

       <StoryViewer 
          isOpen={viewerOpen} 
          onClose={() => setViewerOpen(false)} 
          stories={selectedStoryGroup} 
          currentUserId={user?.id}
       />

       <AddStoryModal
          isOpen={addModalOpen}
          onClose={() => setAddModalOpen(false)}
          user={user}
          role={userRole}
          onSuccess={fetchStories}
       />
    </div>
  );
};

export default StoriesBar;
