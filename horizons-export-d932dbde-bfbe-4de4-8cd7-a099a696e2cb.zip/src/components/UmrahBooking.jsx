
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Plane, Calendar, MapPin, Plus, Users, Bus, 
  Trash2, Send, AlertTriangle, Check, Printer, 
  Navigation, Bell, FileText, Utensils, Info,
  DollarSign, Briefcase, FileBox
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/supabaseClient';
import WalletSection from '@/components/WalletSection';

// --- Helper: Haversine Distance ---
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 0;
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const d = R * c; // Distance in km
  return d;
};

const deg2rad = (deg) => {
  return deg * (Math.PI/180);
};

const UmrahBooking = ({ view, bookings, setBookings, userLocation, onAuthRequired, isAuthenticated, user }) => {
  const { toast } = useToast();
  
  // --- State ---
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTrip, setActiveTrip] = useState(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [tripToDelete, setTripToDelete] = useState(null);
  
  // Dashboard specific state
  const [announcementMsg, setAnnouncementMsg] = useState('');
  const [announcementType, setAnnouncementType] = useState('general');
  const [dashboardTab, setDashboardTab] = useState('trips');
  
  // Booking specific state
  const [bookingStep, setBookingStep] = useState('details'); // details -> locating -> distance_check -> confirm -> receipt
  const [distanceInfo, setDistanceInfo] = useState({ distance: 0, showWarning: false });
  const [customerCoords, setCustomerCoords] = useState(null);
  const [generatedReceipt, setGeneratedReceipt] = useState(null);
  const [nearbyOffices, setNearbyOffices] = useState([]);

  const [passengerDetails, setPassengerDetails] = useState({
    name: user?.user_metadata?.full_name || '',
    phone: user?.phone || '',
    address: user?.location || '',
    passport: ''
  });

  // Form State for New Trip
  const [newTrip, setNewTrip] = useState({
    title: '', description: '', price: '', total_seats: 50, meals: false, 
    transport_type: 'air', departure_date: '', return_date: '', 
    departure_city: userLocation || 'Baghdad',
    itinerary: [{ day: 1, activity: '' }],
    images: []
  });

  // Load Trips
  useEffect(() => {
    fetchTrips();
    
    // Realtime subscription
    const tripSubscription = supabase
      .channel('public:umrah_trips')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'umrah_trips' }, (payload) => {
        if (payload.eventType === 'INSERT') {
          setTrips(prev => [payload.new, ...prev]);
        } else if (payload.eventType === 'UPDATE') {
          setTrips(prev => prev.map(t => t.id === payload.new.id ? payload.new : t));
          if (activeTrip?.id === payload.new.id) {
             setActiveTrip(prev => ({ ...prev, ...payload.new }));
          }
        } else if (payload.eventType === 'DELETE') {
          setTrips(prev => prev.filter(t => t.id !== payload.old.id));
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(tripSubscription);
    };
  }, [userLocation, view, user]);

  const fetchTrips = async () => {
    setLoading(true);
    let query = supabase.from('umrah_trips').select('*, office:office_id(id, business_name, email, phone, location)');
    
    if (view === 'dashboard' && user) {
        query = query.eq('office_id', user.id);
    }

    const { data, error } = await query.order('created_at', { ascending: false });
    if (!error) setTrips(data || []);
    setLoading(false);
  };

  const fetchTripDetails = async (tripId) => {
     const { data: participants } = await supabase
        .from('umrah_bookings')
        .select('*')
        .eq('trip_id', tripId);
     
     const { data: announcements } = await supabase
        .from('trip_announcements')
        .select('*')
        .eq('trip_id', tripId)
        .order('created_at', { ascending: false });

     const totalRevenue = participants?.reduce((sum, p) => sum + (p.total_price || 0), 0) || 0;
     const totalBookings = participants?.length || 0;
     
     return { participants, announcements, stats: { totalRevenue, totalBookings } };
  };

  // --- Manager Dashboard Actions ---

  const handleCreateTrip = async () => {
     if (!user) return;
     if (!newTrip.title || !newTrip.price || !newTrip.departure_date) {
       toast({ variant: "destructive", title: "Missing Fields", description: "Please fill in all required fields." });
       return;
     }

     const payload = {
         ...newTrip,
         office_id: user.id,
         remaining_seats: newTrip.total_seats,
         status: 'upcoming',
         departure_lat: 33.3152, // Mock lat for office (Baghdad center)
         departure_lng: 44.3661  // Mock lng for office
     };

     const { data, error } = await supabase.from('umrah_trips').insert([payload]).select();
     
     if (error) {
         toast({ variant: "destructive", title: "Error", description: error.message });
     } else {
         setTrips([data[0], ...trips]);
         setIsCreateOpen(false);
         toast({ title: "Success", description: "Trip published successfully" });
         setNewTrip({
            title: '', description: '', price: '', total_seats: 50, meals: false, 
            transport_type: 'air', departure_date: '', return_date: '', 
            departure_city: userLocation || 'Baghdad',
            itinerary: [{ day: 1, activity: '' }],
            images: []
         });
     }
  };

  const handleUpdateStatus = async (tripId, newStatus) => {
    const { error } = await supabase.from('umrah_trips').update({ status: newStatus }).eq('id', tripId);
    if (!error) {
      toast({ title: "Status Updated", description: `Trip marked as ${newStatus}` });
      await broadcastNotification(tripId, "Trip Status Update", `The trip status has been changed to: ${newStatus}`);
    }
  };

  const handleDeleteTrip = async () => {
    if (!tripToDelete) return;
    await broadcastNotification(tripToDelete.id, "Trip Cancelled", "We regret to inform you that this trip has been cancelled. You will be contacted for refunds.");
    const { error } = await supabase.from('umrah_trips').delete().eq('id', tripToDelete.id);
    if (!error) {
      setTrips(trips.filter(t => t.id !== tripToDelete.id));
      setActiveTrip(null);
      setIsDeleteConfirmOpen(false);
      setTripToDelete(null);
      toast({ title: "Deleted", description: "Trip removed successfully" });
    }
  };

  const handleSendAnnouncement = async () => {
    if (!activeTrip || !announcementMsg.trim()) return;
    const { error } = await supabase.from('trip_announcements').insert({
      trip_id: activeTrip.id,
      message: announcementMsg,
      title: announcementType.toUpperCase(),
      type: announcementType
    });
    if (!error) {
      await broadcastNotification(activeTrip.id, `Announcement: ${announcementType}`, announcementMsg);
      toast({ title: "Sent", description: "Announcement broadcasted to all participants" });
      setAnnouncementMsg('');
      const details = await fetchTripDetails(activeTrip.id);
      setActiveTrip(prev => ({ ...prev, ...details }));
    }
  };

  const broadcastNotification = async (tripId, title, message) => {
    const { data: participants } = await supabase.from('umrah_bookings').select('user_id').eq('trip_id', tripId);
    if (participants?.length) {
      const notifications = participants.map(p => ({
        user_id: p.user_id,
        title: title,
        message: message,
        type: 'trip_update',
        read_status: false,
        created_at: new Date().toISOString()
      }));
      await supabase.from('notifications').insert(notifications);
    }
  };

  // --- Customer Booking Flow Actions ---

  const initiateBooking = (trip) => {
    if (!isAuthenticated) {
      onAuthRequired("Please login to book your Umrah trip.");
      return;
    }
    setSelectedTrip(trip);
    setIsBookingOpen(true);
    setBookingStep('details');
    setDistanceInfo({ distance: 0, showWarning: false });
    setGeneratedReceipt(null);
    setNearbyOffices([]);
  };

  const handleCheckLocation = () => {
    setBookingStep('locating');
    
    if (!navigator.geolocation) {
       toast({ variant: "destructive", title: "Error", description: "Geolocation is not supported by your browser." });
       setBookingStep('details');
       return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
         const { latitude, longitude } = position.coords;
         setCustomerCoords({ lat: latitude, lng: longitude });

         // Use trip's office location coordinates. 
         const officeLat = selectedTrip.departure_lat || 33.3152;
         const officeLng = selectedTrip.departure_lng || 44.3661;
         
         const dist = calculateDistance(latitude, longitude, officeLat, officeLng);
         setDistanceInfo({ distance: dist, showWarning: dist > 100 });

         if (dist > 100) {
            setBookingStep('distance_check');
            findNearbyOffices(latitude, longitude);
         } else {
            setBookingStep('confirm');
         }
      },
      (error) => {
         console.error(error);
         toast({ variant: "destructive", title: "Location Error", description: "Unable to retrieve your location. Please allow location access." });
         setBookingStep('details');
      }
    );
  };

  const findNearbyOffices = async (lat, lng) => {
     const others = trips.filter(t => t.id !== selectedTrip.id);
     const nearby = others.map(t => {
         const d = calculateDistance(lat, lng, t.departure_lat || 33.3152, t.departure_lng || 44.3661);
         return { ...t, distance: d };
     }).sort((a,b) => a.distance - b.distance).slice(0, 3);
     setNearbyOffices(nearby);
  };

  const handleConfirmBooking = async () => {
    if (!selectedTrip || !user) return;

    const receiptId = `INV-${Date.now().toString().slice(-6)}`;
    const receipt = {
        id: receiptId,
        date: new Date().toISOString(),
        customer: { ...passengerDetails, email: user.email },
        trip: { 
            title: selectedTrip.title, 
            date: selectedTrip.departure_date,
            office: selectedTrip.office?.business_name || 'Umrah Office',
            office_address: selectedTrip.office?.location || 'Main St, Baghdad',
            price: selectedTrip.price
        },
        distance: distanceInfo.distance.toFixed(2),
        amount: selectedTrip.price
    };

    const bookingData = {
      user_id: user.id,
      trip_id: selectedTrip.id,
      package_name: selectedTrip.title,
      total_price: selectedTrip.price,
      status: 'confirmed',
      payment_status: 'pending',
      customer_phone: passengerDetails.phone,
      customer_address: passengerDetails.address,
      office_name: selectedTrip.office?.business_name,
      office_address: selectedTrip.office?.location,
      office_location_lat: selectedTrip.departure_lat,
      office_location_lng: selectedTrip.departure_lng,
      customer_location_lat: customerCoords?.lat,
      customer_location_lng: customerCoords?.lng,
      distance_km: distanceInfo.distance,
      receipt_data: receipt
    };

    const { error } = await supabase.from('umrah_bookings').insert([bookingData]);

    if (error) {
      toast({ variant: "destructive", title: "Booking Failed", description: error.message });
    } else {
      await supabase.rpc('decrement_seats', { row_id: selectedTrip.id }).catch(() => {});

      await supabase.from('notifications').insert({
        user_id: selectedTrip.office_id,
        title: "New Booking Received",
        message: `New booking for ${selectedTrip.title} from ${distanceInfo.distance.toFixed(1)}km away.`,
        type: 'booking'
      });

      setGeneratedReceipt(receipt);
      setBookingStep('receipt');
      toast({ title: "Booking Confirmed!", description: "Receipt generated successfully." });
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(amount);
  };

  // --- RENDER ---

  if (view === 'dashboard') {
    return (
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-xl shadow-sm border">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Umrah Manager Dashboard</h2>
            <p className="text-slate-500">Manage trips, bookings, and pilgrims.</p>
          </div>
          <div className="flex gap-2">
             <Button onClick={() => setIsCreateOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                <Plus className="w-4 h-4" /> Create Package
             </Button>
          </div>
        </div>

        <Tabs defaultValue="trips" value={dashboardTab} onValueChange={setDashboardTab} className="w-full">
            <TabsList className="bg-white border p-1 h-auto flex justify-start gap-1 w-full overflow-x-auto scrollbar-hide">
                <TabsTrigger value="trips" className="gap-2 px-4 py-2"><Plane className="w-4 h-4"/> Packages</TabsTrigger>
                <TabsTrigger value="finance" className="gap-2 px-4 py-2"><DollarSign className="w-4 h-4"/> Finance</TabsTrigger>
                <TabsTrigger value="guides" className="gap-2 px-4 py-2"><Users className="w-4 h-4"/> Guides</TabsTrigger>
                <TabsTrigger value="documents" className="gap-2 px-4 py-2"><FileBox className="w-4 h-4"/> Documents</TabsTrigger>
            </TabsList>

            <div className="mt-6">
                <TabsContent value="trips" className="m-0 focus-visible:ring-0">
                     <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                       {/* Sidebar: Trip List */}
                       <div className="lg:col-span-4 space-y-4">
                         <h3 className="font-semibold text-slate-700 px-1">Active Packages</h3>
                         <ScrollArea className="h-[600px] pr-4">
                           {trips.length === 0 && <div className="text-center p-8 text-slate-400 border rounded-lg bg-white border-dashed">No trips created yet.</div>}
                           {trips.map(trip => (
                             <Card 
                               key={trip.id} 
                               className={`cursor-pointer transition-all hover:shadow-md ${activeTrip?.id === trip.id ? 'ring-2 ring-emerald-500 border-transparent' : ''}`}
                               onClick={async () => {
                                 const details = await fetchTripDetails(trip.id);
                                 setActiveTrip({ ...trip, ...details });
                               }}
                             >
                               <CardHeader className="p-4 pb-2">
                                 <div className="flex justify-between items-start">
                                   <Badge variant={trip.status === 'upcoming' ? 'default' : trip.status === 'completed' ? 'secondary' : 'destructive'}>
                                     {trip.status}
                                   </Badge>
                                   <span className="text-xs font-mono text-slate-400">{new Date(trip.departure_date).toLocaleDateString()}</span>
                                 </div>
                                 <CardTitle className="text-base mt-2 line-clamp-1">{trip.title}</CardTitle>
                               </CardHeader>
                               <CardContent className="p-4 pt-0">
                                 <div className="flex justify-between text-sm text-slate-500 mt-2">
                                   <span className="flex items-center gap-1"><Users className="w-3 h-3"/> {trip.total_seats - trip.remaining_seats}/{trip.total_seats}</span>
                                   <span className="font-semibold text-emerald-600">{formatCurrency(trip.price)}</span>
                                 </div>
                               </CardContent>
                             </Card>
                           ))}
                         </ScrollArea>
                       </div>

                       {/* Main Content: Active Trip Details */}
                       <div className="lg:col-span-8">
                         {activeTrip ? (
                           <Card className="h-full border-0 shadow-lg overflow-hidden flex flex-col">
                             <div className="bg-slate-50 border-b p-6">
                               <div className="flex justify-between items-start mb-6">
                                 <div>
                                   <h2 className="text-2xl font-bold text-slate-900">{activeTrip.title}</h2>
                                   <div className="flex items-center gap-4 text-sm text-slate-500 mt-2">
                                     <span className="flex items-center gap-1"><MapPin className="w-4 h-4"/> {activeTrip.departure_city}</span>
                                     <span className="flex items-center gap-1"><Calendar className="w-4 h-4"/> {new Date(activeTrip.departure_date).toLocaleDateString()}</span>
                                     <span className="flex items-center gap-1">{activeTrip.transport_type === 'air' ? <Plane className="w-4 h-4"/> : <Bus className="w-4 h-4"/>} {activeTrip.transport_type}</span>
                                   </div>
                                 </div>
                                 <div className="flex gap-2">
                                   <Select defaultValue={activeTrip.status} onValueChange={(v) => handleUpdateStatus(activeTrip.id, v)}>
                                     <SelectTrigger className="w-[140px] bg-white"><SelectValue /></SelectTrigger>
                                     <SelectContent>
                                       <SelectItem value="upcoming">Upcoming</SelectItem>
                                       <SelectItem value="in_progress">In Progress</SelectItem>
                                       <SelectItem value="completed">Completed</SelectItem>
                                       <SelectItem value="cancelled">Cancelled</SelectItem>
                                     </SelectContent>
                                   </Select>
                                   <Button 
                                     variant="destructive" 
                                     size="icon" 
                                     onClick={() => {
                                       setTripToDelete(activeTrip);
                                       setIsDeleteConfirmOpen(true);
                                     }}
                                   >
                                     <Trash2 className="w-4 h-4"/>
                                   </Button>
                                 </div>
                               </div>

                               <div className="grid grid-cols-3 gap-4">
                                 <div className="bg-white p-4 rounded-lg border shadow-sm">
                                   <p className="text-xs text-slate-500 uppercase font-bold">Total Revenue</p>
                                   <p className="text-xl font-bold text-emerald-600">{formatCurrency(activeTrip.stats?.totalRevenue || 0)}</p>
                                 </div>
                                 <div className="bg-white p-4 rounded-lg border shadow-sm">
                                   <p className="text-xs text-slate-500 uppercase font-bold">Occupancy</p>
                                   <p className="text-xl font-bold text-blue-600">
                                     {Math.round(((activeTrip.total_seats - activeTrip.remaining_seats) / activeTrip.total_seats) * 100)}%
                                   </p>
                                 </div>
                                 <div className="bg-white p-4 rounded-lg border shadow-sm">
                                   <p className="text-xs text-slate-500 uppercase font-bold">Bookings</p>
                                   <p className="text-xl font-bold text-slate-700">{activeTrip.stats?.totalBookings || 0}</p>
                                 </div>
                               </div>
                             </div>

                             <Tabs defaultValue="participants" className="w-full flex-1 flex flex-col">
                               <div className="px-6 pt-4 border-b">
                                 <TabsList className="w-full justify-start bg-transparent p-0 h-auto gap-6">
                                   <TabsTrigger value="participants" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-emerald-600 rounded-none px-0 pb-2">Participants</TabsTrigger>
                                   <TabsTrigger value="announcements" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-emerald-600 rounded-none px-0 pb-2">Announcements</TabsTrigger>
                                   <TabsTrigger value="itinerary" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-emerald-600 rounded-none px-0 pb-2">Itinerary</TabsTrigger>
                                 </TabsList>
                               </div>

                               <TabsContent value="participants" className="p-0 flex-1">
                                 <ScrollArea className="h-[400px]">
                                   <table className="w-full text-left text-sm">
                                     <thead className="bg-slate-50 sticky top-0 z-10">
                                       <tr>
                                         <th className="p-4 font-medium text-slate-500">Name</th>
                                         <th className="p-4 font-medium text-slate-500">Location Info</th>
                                         <th className="p-4 font-medium text-slate-500">Receipt</th>
                                         <th className="p-4 font-medium text-slate-500">Status</th>
                                       </tr>
                                     </thead>
                                     <tbody className="divide-y">
                                       {activeTrip.participants?.map((p) => (
                                         <tr key={p.id} className="hover:bg-slate-50">
                                           <td className="p-4 font-medium">
                                               <div className="font-bold">{p.receipt_data?.customer?.name || 'Unknown'}</div>
                                               <div className="text-xs text-slate-500">{p.customer_phone}</div>
                                           </td>
                                           <td className="p-4">
                                             <div className="flex items-center gap-1 text-xs font-bold text-blue-600 bg-blue-50 w-fit px-2 py-1 rounded mb-1">
                                                <Navigation className="w-3 h-3" /> {p.distance_km ? `${p.distance_km.toFixed(1)} km away` : 'N/A'}
                                             </div>
                                             <div className="text-xs text-slate-500 truncate max-w-[150px]">{p.customer_address}</div>
                                           </td>
                                           <td className="p-4">
                                              <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => {
                                                  setGeneratedReceipt(p.receipt_data);
                                                  setIsBookingOpen(true); 
                                                  setBookingStep('receipt_view_only');
                                              }}>
                                                  View Receipt
                                              </Button>
                                           </td>
                                           <td className="p-4">
                                             <Badge variant={p.payment_status === 'paid' ? 'default' : 'outline'}>
                                               {p.payment_status || 'Pending'}
                                             </Badge>
                                           </td>
                                         </tr>
                                       ))}
                                       {(!activeTrip.participants || activeTrip.participants.length === 0) && (
                                         <tr><td colSpan="4" className="p-8 text-center text-slate-400">No participants yet</td></tr>
                                       )}
                                     </tbody>
                                   </table>
                                 </ScrollArea>
                               </TabsContent>

                               <TabsContent value="announcements" className="p-6 space-y-6 flex-1 overflow-y-auto">
                                 <div className="bg-slate-50 p-4 rounded-lg border space-y-4">
                                   <h4 className="font-semibold text-sm uppercase text-slate-500">Broadcast Message</h4>
                                   <div className="flex gap-4">
                                     <Select value={announcementType} onValueChange={setAnnouncementType}>
                                       <SelectTrigger className="w-[180px] bg-white"><SelectValue /></SelectTrigger>
                                       <SelectContent>
                                         <SelectItem value="general">General Info</SelectItem>
                                         <SelectItem value="delay">Delay Alert</SelectItem>
                                         <SelectItem value="location">Location Update</SelectItem>
                                         <SelectItem value="schedule">Schedule Change</SelectItem>
                                       </SelectContent>
                                     </Select>
                                     <Input 
                                       placeholder="Subject / Title (Optional)" 
                                       className="bg-white flex-1" 
                                       disabled
                                       value={announcementType.toUpperCase()}
                                     />
                                   </div>
                                   <Textarea 
                                     placeholder="Type your message here... (e.g. Meeting point changed to Hotel Lobby at 8 PM)" 
                                     value={announcementMsg}
                                     onChange={(e) => setAnnouncementMsg(e.target.value)}
                                     className="bg-white min-h-[100px]"
                                   />
                                   <div className="flex justify-end">
                                     <Button onClick={handleSendAnnouncement} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                                       <Send className="w-4 h-4" /> Send Broadcast
                                     </Button>
                                   </div>
                                 </div>

                                 <div className="space-y-4">
                                   <h4 className="font-semibold text-sm uppercase text-slate-500">History</h4>
                                   {activeTrip.announcements?.map(a => (
                                     <div key={a.id} className="flex gap-4 items-start p-4 border rounded-lg bg-white">
                                       <div className={`p-2 rounded-full shrink-0 ${a.type === 'delay' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}`}>
                                         <Bell className="w-4 h-4" />
                                       </div>
                                       <div>
                                         <div className="flex items-center gap-2 mb-1">
                                           <span className="font-bold text-sm">{a.title || 'Announcement'}</span>
                                           <span className="text-xs text-slate-400">• {new Date(a.created_at).toLocaleString()}</span>
                                         </div>
                                         <p className="text-sm text-slate-600">{a.message}</p>
                                       </div>
                                     </div>
                                   ))}
                                 </div>
                               </TabsContent>

                               <TabsContent value="itinerary" className="p-6 flex-1 overflow-y-auto">
                                 <div className="space-y-6 relative before:absolute before:left-[27px] before:top-8 before:bottom-8 before:w-[2px] before:bg-slate-200">
                                   {activeTrip.itinerary?.map((day, idx) => (
                                     <div key={idx} className="relative flex gap-6">
                                       <div className="w-14 h-14 rounded-full bg-white border-2 border-emerald-500 text-emerald-700 flex items-center justify-center font-bold text-lg shrink-0 z-10 shadow-sm">
                                         {day.day}
                                       </div>
                                       <div className="pt-2 bg-slate-50 p-4 rounded-lg flex-1 border">
                                         <h5 className="font-bold text-slate-800">Day {day.day}</h5>
                                         <p className="text-slate-600 mt-1">{day.activity}</p>
                                       </div>
                                     </div>
                                   ))}
                                 </div>
                               </TabsContent>
                             </Tabs>
                           </Card>
                         ) : (
                           <div className="h-full flex flex-col items-center justify-center bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 text-slate-400 p-12">
                             <Plane className="w-16 h-16 mb-4 opacity-20" />
                             <p className="text-lg font-medium">Select a trip to view details</p>
                           </div>
                         )}
                       </div>
                     </div>
                </TabsContent>

                <TabsContent value="finance" className="m-0 focus-visible:ring-0">
                    <WalletSection entityId={user.id} entityType="user" />
                </TabsContent>

                <TabsContent value="guides" className="m-0 focus-visible:ring-0">
                    <div className="p-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed">
                        <Users className="w-12 h-12 mx-auto mb-4 opacity-30"/>
                        <h3 className="text-lg font-bold text-slate-700">Guide Management</h3>
                        <p className="text-sm">Manage your guides and their schedules here.</p>
                        <Button className="mt-4" variant="outline">Add Guide</Button>
                    </div>
                </TabsContent>

                <TabsContent value="documents" className="m-0 focus-visible:ring-0">
                    <div className="p-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed">
                        <FileBox className="w-12 h-12 mx-auto mb-4 opacity-30"/>
                        <h3 className="text-lg font-bold text-slate-700">Document Vault</h3>
                        <p className="text-sm">Store visas, permits, and passenger documents.</p>
                        <Button className="mt-4" variant="outline">Upload Document</Button>
                    </div>
                </TabsContent>
            </div>
        </Tabs>

        {/* Create Trip Dialog */}
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Umrah Package</DialogTitle>
              <DialogDescription>Fill in the details to publish a new trip.</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-6 py-4">
              <div className="col-span-2 space-y-2">
                <Label>Package Title</Label>
                <Input value={newTrip.title} onChange={e => setNewTrip({...newTrip, title: e.target.value})} placeholder="e.g. Premium Ramadan Umrah 2025" />
              </div>
              <div className="space-y-2">
                <Label>Departure City</Label>
                <Input value={newTrip.departure_city} onChange={e => setNewTrip({...newTrip, departure_city: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Price (IQD)</Label>
                <Input type="number" value={newTrip.price} onChange={e => setNewTrip({...newTrip, price: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Departure Date</Label>
                <Input type="date" value={newTrip.departure_date} onChange={e => setNewTrip({...newTrip, departure_date: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Return Date</Label>
                <Input type="date" value={newTrip.return_date} onChange={e => setNewTrip({...newTrip, return_date: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Total Seats</Label>
                <Input type="number" value={newTrip.total_seats} onChange={e => setNewTrip({...newTrip, total_seats: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Transport Type</Label>
                <Select value={newTrip.transport_type} onValueChange={v => setNewTrip({...newTrip, transport_type: v})}>
                  <SelectTrigger><SelectValue/></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="air">Air (Flight)</SelectItem>
                    <SelectItem value="bus">Ground (Bus)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2 flex items-center gap-4 p-4 bg-slate-50 rounded-lg border">
                <Switch checked={newTrip.meals} onCheckedChange={c => setNewTrip({...newTrip, meals: c})} />
                <div>
                  <Label className="text-base">Meals Included</Label>
                  <p className="text-xs text-slate-500">Enable if breakfast/dinner are provided</p>
                </div>
              </div>
              <div className="col-span-2 space-y-2">
                <Label>Itinerary (Day 1)</Label>
                <Textarea 
                  value={newTrip.itinerary[0]?.activity} 
                  onChange={e => setNewTrip({...newTrip, itinerary: [{ day: 1, activity: e.target.value }]})} 
                  placeholder="Describe the first day activities..." 
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateTrip} className="bg-emerald-600">Publish Trip</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Delete Trip</DialogTitle>
              <DialogDescription>Are you sure you want to delete this trip? This action cannot be undone.</DialogDescription>
            </DialogHeader>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setIsDeleteConfirmOpen(false)}>Cancel</Button>
              <Button variant="destructive" onClick={handleDeleteTrip}>Delete Trip</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // --- RENDER: CUSTOMER VIEW ---
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Hero */}
      <div className="relative h-[300px] md:h-[400px] rounded-3xl overflow-hidden shadow-xl group">
        <img 
          src="https://images.unsplash.com/photo-1565552629477-e254f38aa89d?q=80&w=2000&auto=format&fit=crop" 
          alt="Mecca" 
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-8 md:p-12">
          <Badge className="w-fit bg-emerald-500/90 backdrop-blur border-0 mb-4 text-white px-4 py-1">Spiritual Journey</Badge>
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">Umrah Packages {userLocation ? `from ${userLocation}` : ''}</h1>
          <p className="text-slate-200 text-lg max-w-2xl">Find trusted agencies, compare prices, and book your spiritual journey with ease.</p>
        </div>
      </div>

      {/* Trips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {loading && [1,2,3].map(i => <div key={i} className="h-[400px] bg-slate-100 rounded-2xl animate-pulse"/>)}
        {!loading && trips.map((trip) => (
          <motion.div 
            key={trip.id}
            whileHover={{ y: -5 }}
            className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden flex flex-col hover:shadow-xl transition-all duration-300"
          >
            <div className="relative h-56 bg-slate-200">
              {trip.image_url ? (
                <img src={trip.image_url} alt={trip.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-50 to-teal-100">
                  <Plane className="w-12 h-12 text-emerald-200" />
                </div>
              )}
              <div className="absolute top-4 right-4">
                <Badge className="bg-white/90 text-slate-900 backdrop-blur hover:bg-white shadow-sm">
                  {trip.status === 'upcoming' ? 'Open for Booking' : trip.status}
                </Badge>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                <p className="text-white font-bold text-lg">{formatCurrency(trip.price)}</p>
              </div>
            </div>

            <div className="p-6 flex-1 flex flex-col">
              <div className="mb-4">
                <h3 className="font-bold text-xl text-slate-900 mb-1 line-clamp-1">{trip.title}</h3>
                <p className="text-sm text-slate-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {trip.departure_city} • {trip.office?.business_name || 'Agency'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-slate-50 p-2 rounded flex items-center gap-2 text-sm text-slate-600">
                  <Calendar className="w-4 h-4 text-emerald-600"/> 
                  {new Date(trip.departure_date).toLocaleDateString()}
                </div>
                <div className="bg-slate-50 p-2 rounded flex items-center gap-2 text-sm text-slate-600">
                  <Utensils className="w-4 h-4 text-emerald-600"/> 
                  {trip.meals ? 'Meals Inc.' : 'No Meals'}
                </div>
              </div>

              <Button 
                className="w-full mt-auto bg-slate-900 hover:bg-emerald-600 text-white rounded-xl py-6"
                onClick={() => initiateBooking(trip)}
              >
                View Details & Book
              </Button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Booking Modal Flow */}
      <Dialog open={isBookingOpen} onOpenChange={setIsBookingOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {/* 1. VIEW ONLY RECEIPT (Manager Dashboard Mode) */}
          {bookingStep === 'receipt_view_only' && generatedReceipt && (
               <div className="space-y-4">
                  <DialogHeader>
                    <DialogTitle>Booking Receipt</DialogTitle>
                    <DialogDescription>Official receipt for the customer.</DialogDescription>
                  </DialogHeader>
                  <ReceiptView receipt={generatedReceipt} />
                  <DialogFooter>
                      <Button onClick={() => window.print()} variant="outline"><Printer className="w-4 h-4 mr-2"/> Print Receipt</Button>
                      <Button onClick={() => setIsBookingOpen(false)}>Close</Button>
                  </DialogFooter>
               </div>
          )}

          {/* 2. CUSTOMER DETAILS */}
          {bookingStep === 'details' && selectedTrip && (
            <div className="space-y-6">
               <DialogHeader>
                 <DialogTitle>Passenger Details</DialogTitle>
                 <DialogDescription>Enter details for {selectedTrip.title}</DialogDescription>
               </DialogHeader>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input 
                      value={passengerDetails.name} 
                      onChange={e => setPassengerDetails({...passengerDetails, name: e.target.value})}
                      placeholder="As in passport"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone Number</Label>
                    <Input 
                      value={passengerDetails.phone} 
                      onChange={e => setPassengerDetails({...passengerDetails, phone: e.target.value})}
                      placeholder="0770..."
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>Address</Label>
                    <Input 
                      value={passengerDetails.address} 
                      onChange={e => setPassengerDetails({...passengerDetails, address: e.target.value})}
                      placeholder="City, District, Street"
                    />
                  </div>
               </div>

               <Button className="w-full bg-emerald-600 hover:bg-emerald-700 mt-4" onClick={handleCheckLocation}>
                  Proceed to Location Check
               </Button>
            </div>
          )}

          {/* 3. LOCATING SPINNER */}
          {bookingStep === 'locating' && (
             <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
                 <div className="animate-spin w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full"></div>
                 <div>
                    <h3 className="font-bold text-lg">Calculating Distance...</h3>
                    <p className="text-slate-500">Checking your distance from the Umrah office</p>
                 </div>
             </div>
          )}

          {/* 4. DISTANCE WARNING */}
          {bookingStep === 'distance_check' && (
             <div className="space-y-6 text-center py-6">
                 <div className="mx-auto w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center text-amber-600 mb-4">
                    <AlertTriangle className="w-10 h-10" />
                 </div>
                 <h2 className="text-2xl font-bold text-slate-800">
                    المسافة بينك والمكتب بعيدة جداً ({distanceInfo.distance.toFixed(0)} كم)
                 </h2>
                 <p className="text-slate-600 max-w-md mx-auto">
                    The office is quite far from your location. We recommend booking with a closer office for better service coordination.
                 </p>

                 <div className="grid grid-cols-1 gap-3 max-w-md mx-auto pt-4 text-left">
                    <p className="text-sm font-bold text-slate-500 uppercase px-1">Nearby Alternatives:</p>
                    {nearbyOffices.map(office => (
                        <div key={office.id} className="p-3 border rounded-lg hover:bg-slate-50 cursor-pointer flex justify-between items-center" onClick={() => setSelectedTrip(office)}>
                            <div>
                                <p className="font-bold text-sm">{office.title}</p>
                                <p className="text-xs text-slate-500">{office.office?.business_name}</p>
                            </div>
                            <Badge variant="outline">{office.distance.toFixed(1)} km</Badge>
                        </div>
                    ))}
                    {nearbyOffices.length === 0 && <p className="text-sm text-slate-400 italic px-1">No other offices found nearby.</p>}
                 </div>

                 <div className="flex gap-4 justify-center pt-4">
                     <Button variant="outline" onClick={() => setIsBookingOpen(false)} className="px-8">Cancel Booking</Button>
                     <Button className="bg-amber-600 hover:bg-amber-700 px-8" onClick={() => setBookingStep('confirm')}>
                        I Accept & Continue
                     </Button>
                 </div>
             </div>
          )}

          {/* 5. CONFIRMATION PAGE */}
          {bookingStep === 'confirm' && selectedTrip && (
              <div className="space-y-6">
                  <DialogHeader>
                    <DialogTitle>Confirm Your Booking</DialogTitle>
                    <DialogDescription>Please review all details before final submission.</DialogDescription>
                  </DialogHeader>

                  <div className="bg-slate-50 p-6 rounded-lg border space-y-4 text-sm">
                      <div className="flex justify-between border-b pb-2">
                          <span className="text-slate-500">Package:</span>
                          <span className="font-bold">{selectedTrip.title}</span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                          <span className="text-slate-500">Travel Date:</span>
                          <span className="font-bold">{new Date(selectedTrip.departure_date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                          <span className="text-slate-500">Office Address:</span>
                          <span className="font-bold text-right max-w-[200px]">{selectedTrip.office?.location || 'Baghdad, Iraq'}</span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                          <span className="text-slate-500">Distance to Office:</span>
                          <span className={`font-bold ${distanceInfo.distance > 100 ? 'text-amber-600' : 'text-emerald-600'}`}>
                              {distanceInfo.distance.toFixed(1)} km
                          </span>
                      </div>
                      <div className="flex justify-between border-b pb-2">
                          <span className="text-slate-500">Passenger:</span>
                          <span className="font-bold">{passengerDetails.name}</span>
                      </div>
                      <div className="flex justify-between pt-2">
                          <span className="text-slate-500 text-lg">Total Amount:</span>
                          <span className="font-bold text-emerald-700 text-xl">{formatCurrency(selectedTrip.price)}</span>
                      </div>
                  </div>

                  <div className="flex items-start gap-3 p-4 bg-blue-50 text-blue-800 rounded-lg text-sm">
                      <Info className="w-5 h-5 shrink-0 mt-0.5" />
                      <p>By clicking Confirm, a receipt will be generated and sent to the office manager. You will be contacted for payment.</p>
                  </div>

                  <Button className="w-full bg-emerald-600 hover:bg-emerald-700 py-6 text-lg" onClick={handleConfirmBooking}>
                      Confirm Booking
                  </Button>
              </div>
          )}

          {/* 6. RECEIPT GENERATED */}
          {bookingStep === 'receipt' && generatedReceipt && (
              <div className="space-y-6 text-center">
                  <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="w-8 h-8" />
                  </div>
                  <h2 className="text-2xl font-bold text-emerald-800">Booking Successful!</h2>
                  <p className="text-slate-600">Your booking has been sent to the office manager.</p>
                  
                  <div className="border rounded-lg p-1 overflow-hidden">
                      <ReceiptView receipt={generatedReceipt} />
                  </div>

                  <DialogFooter className="flex-col sm:flex-row gap-2">
                      <Button onClick={() => window.print()} variant="outline" className="w-full sm:w-auto"><Printer className="w-4 h-4 mr-2"/> Print</Button>
                      <Button onClick={() => setIsBookingOpen(false)} className="w-full sm:w-auto">Close</Button>
                  </DialogFooter>
              </div>
          )}

        </DialogContent>
      </Dialog>
    </div>
  );
};

// --- Subcomponent: Receipt View (Reusable) ---
const ReceiptView = ({ receipt }) => {
    const formatCurrency = (val) => new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(val);

    return (
        <div className="bg-white p-6 md:p-8 text-left text-sm relative print-section" id="booking-receipt">
            {/* Header */}
            <div className="flex justify-between items-start border-b pb-6 mb-6">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 tracking-tight">INVOICE</h1>
                    <p className="text-slate-500 mt-1">Receipt #{receipt.id}</p>
                    <Badge className="mt-2 bg-emerald-100 text-emerald-700 hover:bg-emerald-100">CONFIRMED</Badge>
                </div>
                <div className="text-right">
                    <h3 className="font-bold text-lg">{receipt.trip.office || 'Umrah Office'}</h3>
                    <p className="text-slate-500 text-xs max-w-[200px] ml-auto">{receipt.trip.office_address}</p>
                    <p className="text-slate-400 text-xs mt-1">{new Date(receipt.date).toLocaleString()}</p>
                </div>
            </div>

            {/* Bill To & Details */}
            <div className="grid grid-cols-2 gap-8 mb-8">
                <div>
                    <p className="text-xs font-bold text-slate-400 uppercase mb-2">Billed To</p>
                    <p className="font-bold text-slate-800 text-lg">{receipt.customer.name}</p>
                    <p className="text-slate-500">{receipt.customer.phone}</p>
                    <p className="text-slate-500 text-xs">{receipt.customer.address}</p>
                </div>
                <div className="text-right">
                    <p className="text-xs font-bold text-slate-400 uppercase mb-2">Trip Details</p>
                    <p className="font-bold text-slate-800">{receipt.trip.title}</p>
                    <p className="text-slate-500">Date: {new Date(receipt.trip.date).toLocaleDateString()}</p>
                    <p className="text-emerald-600 font-medium text-xs mt-1 flex items-center justify-end gap-1">
                        <Navigation className="w-3 h-3" /> Distance: {receipt.distance} km
                    </p>
                </div>
            </div>

            {/* Total */}
            <div className="bg-slate-50 rounded-lg p-4 flex justify-between items-center mb-6">
                <span className="font-bold text-slate-700">Total Amount Due</span>
                <span className="font-bold text-2xl text-slate-900">{formatCurrency(receipt.amount)}</span>
            </div>

            {/* Footer */}
            <div className="text-center text-xs text-slate-400 pt-4 border-t">
                <p>This is a computer generated receipt. No signature required.</p>
                <p>Thank you for booking with us. May Allah accept your Umrah.</p>
            </div>
            
            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
                <FileText className="w-64 h-64" />
            </div>
        </div>
    );
};

export default UmrahBooking;
