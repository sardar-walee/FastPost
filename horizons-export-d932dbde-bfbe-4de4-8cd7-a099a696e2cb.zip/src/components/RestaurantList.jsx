
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, MapPin, Clock, Star, Plus, Info, X, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { supabase } from '@/supabaseClient';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const RestaurantList = ({ userLocation, addToCart, selectedRestaurant, setSelectedRestaurant }) => {
  const [restaurants, setRestaurants] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Customization Modal State
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [currentItem, setCurrentItem] = useState(null);
  const [selectedOptions, setSelectedOptions] = useState({});

  useEffect(() => {
    fetchRestaurants();
  }, [userLocation]);

  useEffect(() => {
    if (selectedRestaurant) {
      fetchMenu(selectedRestaurant.id);
    }
  }, [selectedRestaurant]);

  const fetchRestaurants = async () => {
    const { data } = await supabase.from('restaurants').select('*');
    if (data) setRestaurants(data);
  };

  const fetchMenu = async (restaurantId) => {
    const { data } = await supabase
      .from('menu_items')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .order('average_rating', { ascending: false });
    if (data) setMenuItems(data);
  };

  const handleItemClick = (item) => {
    if (item.options && item.options.length > 0) {
      setCurrentItem(item);
      setSelectedOptions({});
      setIsCustomizing(true);
    } else {
      addToCart(item, selectedRestaurant);
    }
  };

  const handleOptionSelect = (groupName, choice, price) => {
    setSelectedOptions(prev => ({
      ...prev,
      [groupName]: { name: groupName, choice: choice, price: price }
    }));
  };

  const confirmCustomization = () => {
    const optionsArray = Object.values(selectedOptions);
    addToCart(currentItem, selectedRestaurant, optionsArray);
    setIsCustomizing(false);
    setCurrentItem(null);
  };

  const calculateTotalWithOptions = () => {
    if (!currentItem) return 0;
    const optionsTotal = Object.values(selectedOptions).reduce((sum, opt) => sum + opt.price, 0);
    return currentItem.price + optionsTotal;
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(price);
  };

  const filteredRestaurants = restaurants.filter(r => 
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (r.location && r.location.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (selectedRestaurant) {
    return (
      <div className="space-y-8 animate-in slide-in-from-right duration-500">
        <Button variant="ghost" onClick={() => setSelectedRestaurant(null)} className="mb-4 pl-0 hover:bg-transparent hover:text-emerald-600 gap-2">
           <div className="p-1 bg-slate-100 rounded-full">
             <X className="w-4 h-4" />
           </div>
           Back to Restaurants
        </Button>
        
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-3xl p-8 shadow-xl text-white relative overflow-hidden">
          {selectedRestaurant.image_url && (
             <div className="absolute inset-0 z-0">
                <img src={selectedRestaurant.image_url} alt={selectedRestaurant.name} className="w-full h-full object-cover opacity-30" />
                <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent"></div>
             </div>
          )}
          <div className="absolute top-0 right-0 p-8 opacity-10 z-0">
             <ShoppingBag className="w-64 h-64 rotate-12" />
          </div>
          <div className="relative z-10">
            <h2 className="text-4xl font-bold mb-3">{selectedRestaurant.name}</h2>
            <div className="flex flex-wrap items-center gap-4 text-slate-300">
              <span className="flex items-center gap-1 bg-white/10 px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                 <Star className="w-4 h-4 text-yellow-400 fill-yellow-400"/> 
                 <span className="font-bold text-white">{selectedRestaurant.rating}</span>
              </span>
              <span className="flex items-center gap-1 text-sm">
                 <MapPin className="w-4 h-4"/> {selectedRestaurant.location}
              </span>
              <span className="flex items-center gap-1 text-sm">
                 <Clock className="w-4 h-4"/> 30-45 mins
              </span>
            </div>
          </div>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {menuItems.map((item) => (
            <motion.div 
              key={item.id}
              whileHover={{ y: -4 }}
              className="bg-white border border-slate-100 rounded-2xl overflow-hidden hover:shadow-lg transition-all flex flex-col group"
            >
              <div className="h-56 bg-slate-100 relative overflow-hidden">
                 {item.image_url ? (
                   <img src={item.image_url} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>
                 ) : (
                   <div className="w-full h-full flex items-center justify-center text-slate-300 bg-slate-50">No Image</div>
                 )}
                 <div className="absolute top-3 right-3 flex gap-2">
                   {item.average_rating && (
                     <span className="bg-white/95 backdrop-blur px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm">
                        <Star className="w-3 h-3 text-yellow-500 fill-yellow-500"/> 
                        {Number(item.average_rating).toFixed(1)}
                     </span>
                   )}
                 </div>
              </div>
              
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-xl text-slate-900 leading-tight">{item.name}</h3>
                  <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 font-bold text-sm border-emerald-100">
                     {formatPrice(item.price)}
                  </Badge>
                </div>
                <p className="text-slate-500 text-sm line-clamp-2 mb-6 flex-1 leading-relaxed">{item.description}</p>
                
                <Button onClick={() => handleItemClick(item)} className="w-full gap-2 rounded-xl h-12 font-bold shadow-sm">
                   <Plus className="w-4 h-4" />
                   {item.options && item.options.length > 0 ? 'Customize' : 'Add to Cart'}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Customization Dialog */}
        <Dialog open={isCustomizing} onOpenChange={setIsCustomizing}>
          <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden">
            <div className="bg-slate-900 p-6 text-white">
                <DialogTitle className="text-xl font-bold">Customize {currentItem?.name}</DialogTitle>
                <p className="text-slate-400 text-sm mt-1">Select your preferred options</p>
            </div>
            <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
               {currentItem?.options?.map((group, idx) => (
                 <div key={idx} className="space-y-3">
                    <h4 className="font-bold text-slate-900 flex items-center gap-2">
                        {group.name} 
                        {group.required && <Badge variant="outline" className="text-[10px] h-5">Required</Badge>}
                    </h4>
                    <div className="grid grid-cols-1 gap-2">
                       {group.choices.map((choice, cIdx) => {
                         const isSelected = selectedOptions[group.name]?.choice === choice.name;
                         return (
                           <div 
                             key={cIdx} 
                             onClick={() => handleOptionSelect(group.name, choice.name, choice.price)}
                             className={`p-4 rounded-xl border cursor-pointer flex justify-between items-center transition-all ${isSelected ? 'border-emerald-500 bg-emerald-50/50 ring-1 ring-emerald-500' : 'border-slate-100 hover:border-emerald-200 hover:bg-slate-50'}`}
                           >
                             <span className={`text-sm font-medium ${isSelected ? 'text-emerald-900' : 'text-slate-700'}`}>{choice.name}</span>
                             <span className="text-sm text-slate-500 font-medium">
                               {choice.price > 0 ? `+${formatPrice(choice.price)}` : 'Free'}
                             </span>
                           </div>
                         );
                       })}
                    </div>
                 </div>
               ))}
            </div>
            <DialogFooter className="p-6 bg-slate-50 border-t flex flex-row items-center justify-between">
              <div className="flex flex-col">
                <span className="text-xs text-slate-500 font-bold uppercase">Total</span>
                <span className="text-xl font-bold text-emerald-600">{formatPrice(calculateTotalWithOptions())}</span>
              </div>
              <Button onClick={confirmCustomization} size="lg" className="px-8 rounded-xl shadow-lg shadow-emerald-200">
                Add to Order
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5 group-focus-within:text-emerald-500 transition-colors" />
        <input 
          className="w-full pl-12 pr-4 h-14 rounded-2xl border-2 border-slate-100 bg-white focus:outline-none focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 shadow-sm transition-all text-lg"
          placeholder="Search restaurants, dishes, or cuisines..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredRestaurants.map((restaurant) => (
          <motion.div
            key={restaurant.id}
            whileHover={{ y: -5 }}
            onClick={() => setSelectedRestaurant(restaurant)}
            className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden cursor-pointer group hover:shadow-xl transition-all duration-300"
          >
            <div className="h-48 bg-slate-200 relative overflow-hidden">
               {restaurant.image_url ? (
                  <img 
                    src={restaurant.image_url} 
                    alt={restaurant.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
               ) : (
                  <div className="w-full h-full bg-slate-800 group-hover:scale-105 transition-transform duration-700"></div>
               )}
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10 flex items-end p-6">
                 <div>
                    <h3 className="text-white font-bold text-2xl mb-1">{restaurant.name}</h3>
                    <div className="flex items-center gap-3 text-white/90 text-sm font-medium">
                        <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {restaurant.location}</span>
                        <span className="w-1 h-1 bg-white/50 rounded-full"></span>
                        <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> 30-45 mins</span>
                    </div>
                 </div>
               </div>
            </div>
            <div className="p-4 flex items-center justify-between bg-white relative z-20">
               <div className="flex gap-2">
                   <Badge variant="secondary" className="bg-slate-100 text-slate-600 font-medium">Fast Food</Badge>
                   <Badge variant="secondary" className="bg-slate-100 text-slate-600 font-medium">Delivery</Badge>
               </div>
               <div className="bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-xl font-bold text-sm flex items-center gap-1 shadow-sm border border-emerald-100">
                 <Star className="w-4 h-4 fill-emerald-700" /> {restaurant.rating}
               </div>
            </div>
          </motion.div>
        ))}
        {filteredRestaurants.length === 0 && (
            <div className="col-span-full text-center py-12 text-slate-500">
                No restaurants found matching your search.
            </div>
        )}
      </div>
    </div>
  );
};

export default RestaurantList;
