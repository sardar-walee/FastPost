
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, Shield, Database, Server, Cpu, AlertTriangle, 
  CheckCircle, XCircle, Terminal, RefreshCw, Zap, Search, 
  Trash2, Play, Lock, Eye
} from 'lucide-react';
import { useSystemMonitor } from '@/contexts/SystemMonitorContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

const SystemHealthDashboard = () => {
  const { logs, metrics, healthScore, activeIssues, applyFix } = useSystemMonitor();
  const [selectedLog, setSelectedLog] = useState(null);
  const [filter, setFilter] = useState('all');

  const getHealthColor = (score) => {
    if (score >= 90) return 'text-emerald-500';
    if (score >= 70) return 'text-amber-500';
    return 'text-red-500';
  };

  const getSeverityBadge = (severity) => {
    switch (severity) {
      case 'critical': return <Badge variant="destructive">CRITICAL</Badge>;
      case 'high': return <Badge className="bg-orange-500">HIGH</Badge>;
      case 'warning': return <Badge className="bg-amber-500">WARNING</Badge>;
      default: return <Badge variant="secondary">INFO</Badge>;
    }
  };

  const filteredLogs = logs.filter(log => filter === 'all' ? true : log.category === filter);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto pb-20">
      
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-indigo-500">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">System Health Score</p>
                <h3 className={`text-3xl font-bold mt-2 ${getHealthColor(healthScore)}`}>{healthScore}%</h3>
              </div>
              <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
                <Activity className="w-6 h-6" />
              </div>
            </div>
            <Progress value={healthScore} className="h-2 mt-4" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">Active Issues</p>
                <h3 className="text-3xl font-bold mt-2 text-slate-800">{activeIssues}</h3>
              </div>
              <div className="p-3 bg-red-50 rounded-xl text-red-600">
                <AlertTriangle className="w-6 h-6" />
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-4">Requires attention</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">Performance (LCP)</p>
                <h3 className="text-3xl font-bold mt-2 text-slate-800">{(metrics.lcp / 1000).toFixed(2)}s</h3>
              </div>
              <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
                <Zap className="w-6 h-6" />
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-4">Target: &lt; 2.5s</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">Security Checks</p>
                <h3 className="text-3xl font-bold mt-2 text-slate-800">Passing</h3>
              </div>
              <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
                <Shield className="w-6 h-6" />
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-4">HTTPS & Headers</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Log Console */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="border-b bg-slate-50/50">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-slate-500" /> System Logs & AI Analysis
                </CardTitle>
                <div className="flex gap-2">
                  <Button size="sm" variant={filter === 'all' ? 'secondary' : 'ghost'} onClick={() => setFilter('all')}>All</Button>
                  <Button size="sm" variant={filter === 'api' ? 'secondary' : 'ghost'} onClick={() => setFilter('api')}>API</Button>
                  <Button size="sm" variant={filter === 'ui' ? 'secondary' : 'ghost'} onClick={() => setFilter('ui')}>UI</Button>
                </div>
              </div>
            </CardHeader>
            <ScrollArea className="flex-1">
              <div className="divide-y">
                {filteredLogs.length === 0 && (
                   <div className="p-12 text-center text-slate-400 flex flex-col items-center">
                      <CheckCircle className="w-12 h-12 mb-2 text-emerald-200" />
                      <p>System is healthy. No active logs found.</p>
                   </div>
                )}
                {filteredLogs.map(log => {
                   const analysis = log.ai_analysis ? JSON.parse(log.ai_analysis) : {};
                   return (
                    <div 
                      key={log.id} 
                      className={`p-4 hover:bg-slate-50 cursor-pointer transition-colors ${selectedLog?.id === log.id ? 'bg-indigo-50 hover:bg-indigo-50' : ''}`}
                      onClick={() => setSelectedLog({ ...log, analysis })}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          {getSeverityBadge(log.severity)}
                          <span className="text-xs font-mono text-slate-400">{new Date(log.created_at).toLocaleTimeString()}</span>
                        </div>
                        {log.resolved && <Badge variant="outline" className="text-emerald-600 border-emerald-200">RESOLVED</Badge>}
                      </div>
                      <p className="font-medium text-slate-800 text-sm line-clamp-1">{log.message}</p>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2">{analysis.analysis}</p>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </Card>
        </div>

        {/* AI Inspector Side Panel */}
        <div className="space-y-6">
          <Card className="h-full border-indigo-100 shadow-md">
            <CardHeader className="bg-gradient-to-r from-indigo-600 to-purple-700 text-white rounded-t-2xl">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Cpu className="w-5 h-5" /> AI Diagnostic Engine
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {selectedLog ? (
                <div className="space-y-6">
                   <div>
                      <h4 className="text-xs font-bold uppercase text-slate-400 mb-2">Error Details</h4>
                      <div className="bg-slate-900 rounded-lg p-3 overflow-x-auto">
                        <code className="text-red-400 text-xs font-mono">{selectedLog.message}</code>
                      </div>
                   </div>

                   <div>
                      <h4 className="text-xs font-bold uppercase text-indigo-500 mb-2 flex items-center gap-2">
                        <Zap className="w-3 h-3" /> AI Analysis
                      </h4>
                      <p className="text-sm text-slate-700 bg-indigo-50 p-3 rounded-lg border border-indigo-100">
                        {selectedLog.analysis?.analysis || "No analysis available."}
                      </p>
                   </div>

                   <div>
                      <h4 className="text-xs font-bold uppercase text-emerald-600 mb-2 flex items-center gap-2">
                         <CheckCircle className="w-3 h-3" /> Suggested Fix
                      </h4>
                      <div className="text-sm text-slate-600 whitespace-pre-line pl-2 border-l-2 border-emerald-200">
                        {selectedLog.analysis?.suggestion || "No suggestions available."}
                      </div>
                   </div>

                   {!selectedLog.resolved && (
                      <div className="pt-4 border-t">
                        <p className="text-xs text-slate-400 mb-3">Automated Actions</p>
                        <div className="grid grid-cols-2 gap-2">
                           <Button variant="outline" size="sm" onClick={() => applyFix(selectedLog.id, 'clear_cache')}>
                              <Trash2 className="w-3 h-3 mr-2" /> Clear Cache
                           </Button>
                           <Button variant="outline" size="sm" onClick={() => applyFix(selectedLog.id, 'reload')}>
                              <RefreshCw className="w-3 h-3 mr-2" /> Force Reload
                           </Button>
                           <Button className="col-span-2 bg-emerald-600 hover:bg-emerald-700" size="sm" onClick={() => applyFix(selectedLog.id, 'resolve')}>
                              <CheckCircle className="w-3 h-3 mr-2" /> Mark Resolved
                           </Button>
                        </div>
                      </div>
                   )}
                </div>
              ) : (
                <div className="text-center py-10 text-slate-400">
                  <Search className="w-12 h-12 mx-auto mb-3 opacity-20" />
                  <p>Select a log entry to view AI analysis and suggested fixes.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SystemHealthDashboard;
