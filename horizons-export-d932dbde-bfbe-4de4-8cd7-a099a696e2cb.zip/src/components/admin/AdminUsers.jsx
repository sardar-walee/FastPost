
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Edit, Trash2, Ban, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [blockDialogOpen, setBlockDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    // Filter out soft-deleted users
    const { data, error } = await supabase.from('users').select('*').is('deleted_at', null).order('created_at', { ascending: false });
    if (error) {
      toast({ variant: "destructive", title: "Error", description: "Failed to load users" });
    } else {
      setUsers(data || []);
    }
    setLoading(false);
  };

  const filteredUsers = users.filter(user => 
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.phone?.includes(searchTerm)
  );

  const handleUpdateRole = async (userId, newRole) => {
    const { error } = await supabase.from('users').update({ role: newRole }).eq('id', userId);
    if (!error) {
      setUsers(users.map(u => u.id === userId ? { ...u, role: newRole } : u));
      toast({ title: "Role Updated", description: `User is now a ${newRole}` });
    }
  };

  const initiateBlock = (user) => { setSelectedUser(user); setBlockDialogOpen(true); };
  const initiateDelete = (user) => { setSelectedUser(user); setDeleteDialogOpen(true); };

  const confirmBlock = async () => {
      if(!selectedUser) return;
      const newStatus = !selectedUser.is_blocked;
      const { error } = await supabase.from('users').update({ is_blocked: newStatus }).eq('id', selectedUser.id);
      if(!error) {
          setUsers(users.map(u => u.id === selectedUser.id ? { ...u, is_blocked: newStatus } : u));
          toast({ title: newStatus ? "User Blocked" : "User Unblocked", description: `Updated status for ${selectedUser.full_name}` });
      } else {
          toast({ variant: "destructive", title: "Error", description: error.message });
      }
      setBlockDialogOpen(false);
  };

  const confirmDelete = async () => {
      if (!selectedUser) return;
      // Soft Delete
      const { error } = await supabase.from('users').update({ deleted_at: new Date().toISOString() }).eq('id', selectedUser.id);
      
      if (!error) {
          setUsers(users.filter(u => u.id !== selectedUser.id));
          toast({ title: "User Deleted", description: "User has been moved to trash." });
      } else {
          toast({ variant: "destructive", title: "Delete Failed", description: error.message });
      }
      setDeleteDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
           <h2 className="text-2xl font-bold text-slate-900">User Management</h2>
           <p className="text-slate-500">Manage user accounts, roles, and deletion.</p>
        </div>
        <Button className="btn-primary" onClick={fetchUsers}>Refresh List</Button>
      </div>

      <div className="flex items-center space-x-2 bg-white p-2 rounded-xl border">
        <Search className="w-5 h-5 text-slate-400 ml-2" />
        <Input 
          className="border-0 focus-visible:ring-0" 
          placeholder="Search users..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="glass-card rounded-2xl overflow-hidden border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? <TableRow><TableCell colSpan={5} className="text-center py-10">Loading...</TableCell></TableRow>
            : filteredUsers.map((user) => (
                <TableRow key={user.id} className={user.is_blocked ? "bg-red-50" : ""}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium flex items-center gap-2">{user.full_name} {user.is_blocked && <Ban className="w-3 h-3 text-red-500"/>}</span>
                      <span className="text-xs text-slate-500">{user.email}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="capitalize">{user.role || 'customer'}</Badge>
                  </TableCell>
                  <TableCell>
                      <Badge variant={user.is_blocked ? "destructive" : "outline"}>{user.is_blocked ? "Blocked" : "Active"}</Badge>
                  </TableCell>
                  <TableCell className="text-right space-x-1">
                    <Dialog>
                      <DialogTrigger asChild><Button variant="ghost" size="icon"><Edit className="w-4 h-4 text-slate-500"/></Button></DialogTrigger>
                      <DialogContent>
                        <DialogHeader><DialogTitle>Edit Role</DialogTitle></DialogHeader>
                        <div className="grid grid-cols-2 gap-4 py-4">
                           {['admin', 'manager', 'restaurant_owner', 'umrah_company', 'driver', 'customer'].map(r => (
                               <Button key={r} variant={user.role === r ? 'default' : 'outline'} onClick={() => handleUpdateRole(user.id, r)} className="capitalize">{r.replace('_', ' ')}</Button>
                           ))}
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button variant="ghost" size="icon" onClick={() => initiateBlock(user)} className={user.is_blocked ? "text-green-600" : "text-amber-600"}>
                        {user.is_blocked ? <CheckCircle className="w-4 h-4"/> : <Ban className="w-4 h-4"/>}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => initiateDelete(user)} className="text-red-400 hover:text-red-600 hover:bg-red-50">
                        <Trash2 className="w-4 h-4"/>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            }
          </TableBody>
        </Table>
      </div>

      {/* Block Dialog */}
      <Dialog open={blockDialogOpen} onOpenChange={setBlockDialogOpen}>
         <DialogContent>
             <DialogHeader><DialogTitle>{selectedUser?.is_blocked ? "Unblock User" : "Block User"}</DialogTitle></DialogHeader>
             <p className="text-slate-600">Are you sure?</p>
             <DialogFooter>
                 <Button variant="outline" onClick={() => setBlockDialogOpen(false)}>Cancel</Button>
                 <Button variant={selectedUser?.is_blocked ? "default" : "destructive"} onClick={confirmBlock}>Confirm</Button>
             </DialogFooter>
         </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
         <DialogContent>
             <DialogHeader><DialogTitle className="flex items-center gap-2 text-red-600"><AlertTriangle className="w-5 h-5"/> Delete User</DialogTitle></DialogHeader>
             <p className="text-slate-600">Are you sure you want to delete <strong>{selectedUser?.full_name}</strong>? This action cannot be undone.</p>
             <DialogFooter>
                 <Button variant="ghost" onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
                 <Button variant="destructive" onClick={confirmDelete}>Permanently Delete</Button>
             </DialogFooter>
         </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminUsers;
