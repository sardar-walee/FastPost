
import React, { useState, useEffect } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/supabaseClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, CalendarCheck, Eye } from 'lucide-react';
import UmrahBookingDetailModal from '@/components/modals/UmrahBookingDetailModal';

const AdminOrders = ({ defaultTab = 'food' }) => {
  const [orders, setOrders] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Modal State
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      // Fix: Explicitly specify the foreign key relationship for users in orders query
      // Using 'users!orders_user_id_fkey' to target the customer relationship
      const { data: ord } = await supabase
        .from('orders')
        .select('*, users!orders_user_id_fkey(full_name, email, phone), restaurants(name)')
        .order('created_at', { ascending: false })
        .limit(50);
        
      const { data: bk } = await supabase.from('umrah_bookings').select('*, users(full_name, email, phone)').order('created_at', { ascending: false }).limit(50);
      
      setOrders(ord || []);
      setBookings(bk || []);
      setLoading(false);
    };
    fetchAll();
  }, []);

  const handleOpenBooking = (booking) => {
    setSelectedBooking(booking);
    setIsModalOpen(true);
  };

  const handleUpdateStatus = async (bookingId, newStatus) => {
     // Optimistic update
     setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status: newStatus } : b));
     await supabase.from('umrah_bookings').update({ status: newStatus }).eq('id', bookingId);
  };

  const formatPrice = (price) => new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(price);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
         <div>
            <h2 className="text-2xl font-bold">Orders & Bookings</h2>
            <p className="text-slate-500">Track and manage all platform transactions.</p>
         </div>
      </div>

      <Tabs defaultValue={defaultTab}>
         <TabsList className="bg-white border w-full justify-start h-auto p-1">
            <TabsTrigger value="food" className="gap-2 py-2 px-4"><FileText className="w-4 h-4"/> Food Orders</TabsTrigger>
            <TabsTrigger value="umrah" className="gap-2 py-2 px-4"><CalendarCheck className="w-4 h-4"/> Umrah Bookings</TabsTrigger>
         </TabsList>

         <TabsContent value="food">
            <div className="glass-card rounded-2xl overflow-hidden border">
               <Table>
                  <TableHeader>
                     <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Restaurant</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                     </TableRow>
                  </TableHeader>
                  <TableBody>
                     {orders.map(o => (
                        <TableRow key={o.id}>
                           <TableCell className="font-mono text-xs">#{o.id.slice(0,8)}</TableCell>
                           <TableCell>
                              <div className="flex flex-col">
                                 <span className="font-medium">{o.users?.full_name || 'Guest'}</span>
                                 <span className="text-xs text-slate-500">{o.contact_phone || o.users?.phone}</span>
                              </div>
                           </TableCell>
                           <TableCell>{o.restaurants?.name || 'Unknown'}</TableCell>
                           <TableCell className="font-bold">{formatPrice(o.total_amount || o.total_price || 0)}</TableCell>
                           <TableCell>
                              <Badge className={
                                 o.status === 'delivered' ? 'bg-emerald-500' :
                                 o.status === 'cancelled' ? 'bg-red-500' : 'bg-amber-500'
                              }>{o.status}</Badge>
                           </TableCell>
                           <TableCell className="text-xs text-slate-500">{new Date(o.created_at).toLocaleString()}</TableCell>
                        </TableRow>
                     ))}
                  </TableBody>
               </Table>
            </div>
         </TabsContent>

         <TabsContent value="umrah">
            <div className="glass-card rounded-2xl overflow-hidden border">
               <Table>
                  <TableHeader>
                     <TableRow>
                        <TableHead>Booking ID</TableHead>
                        <TableHead>Pilgrim</TableHead>
                        <TableHead>Package</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                     </TableRow>
                  </TableHeader>
                  <TableBody>
                     {bookings.map(b => (
                        <TableRow key={b.id}>
                           <TableCell className="font-mono text-xs">#{b.id.slice(0,8)}</TableCell>
                           <TableCell>
                              <div className="flex flex-col">
                                 <span className="font-medium">{b.users?.full_name || 'Guest'}</span>
                                 <span className="text-xs text-slate-500">{b.customer_phone}</span>
                              </div>
                           </TableCell>
                           <TableCell>{b.package_name}</TableCell>
                           <TableCell>
                              <Badge className={
                                 b.status === 'confirmed' ? 'bg-emerald-500' :
                                 b.status === 'cancelled' ? 'bg-red-500' : 'bg-blue-500'
                              }>{b.status}</Badge>
                           </TableCell>
                           <TableCell className="text-xs text-slate-500">{new Date(b.created_at).toLocaleDateString()}</TableCell>
                           <TableCell className="text-right">
                              <Button variant="ghost" size="sm" onClick={() => handleOpenBooking(b)}>
                                 <Eye className="w-4 h-4 text-slate-500" />
                              </Button>
                           </TableCell>
                        </TableRow>
                     ))}
                  </TableBody>
               </Table>
            </div>
         </TabsContent>
      </Tabs>

      <UmrahBookingDetailModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        booking={selectedBooking} 
        onUpdateStatus={handleUpdateStatus}
        isAdmin={true}
      />
    </div>
  );
};

export default AdminOrders;
