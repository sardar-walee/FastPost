
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Utensils, Plane, Car, Trash2, Eye, Ban, ShieldAlert, CheckCircle2 } from 'lucide-react';
import CarListingDetailModal from '@/components/modals/CarListingDetailModal';

const AdminServices = ({ defaultTab = 'restaurants' }) => {
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [blockDialogOpen, setBlockDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  
  const { toast } = useToast();
  const [selectedCar, setSelectedCar] = useState(null);
  const [isCarModalOpen, setIsCarModalOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    let table = 'restaurants';
    if (activeTab === 'umrah') table = 'umrah_offices';
    if (activeTab === 'cars') table = 'cars';

    let query = supabase.from(table).select('*').order('created_at', { ascending: false });
    if (activeTab === 'umrah') query = supabase.from('umrah_offices').select('*');

    const { data: result, error } = await query;
    if (!error) setData(result || []);
    setLoading(false);
  };

  const handleAction = (item, type) => {
    setSelectedItem(item);
    if (type === 'delete') setDeleteDialogOpen(true);
    if (type === 'block') setBlockDialogOpen(true);
  };

  const handleToggleVisibility = async (item) => {
      // Toggle 'is_online' as the visibility/publish status
      const newStatus = !item.is_online;
      const table = activeTab === 'restaurants' ? 'restaurants' : activeTab === 'cars' ? 'cars' : 'umrah_offices';
      
      // Note: cars table typically uses 'availability_status', but we'll assume a boolean or check schema.
      // Schema for cars says 'availability_status' text. We'll skip toggle for cars or map it.
      if (activeTab === 'cars') return; 

      const { error } = await supabase.from(table).update({ is_online: newStatus }).eq('id', item.id);
      
      if (!error) {
          setData(data.map(i => i.id === item.id ? { ...i, is_online: newStatus } : i));
          toast({ title: newStatus ? "Published" : "Unpublished", description: `${item.name} is now ${newStatus ? 'visible' : 'hidden'}.` });
      } else {
          toast({ variant: "destructive", title: "Error", description: error.message });
      }
  };

  const handleConfirmDelete = async () => {
    if (!selectedItem) return;

    let table = activeTab === 'restaurants' ? 'restaurants' : activeTab === 'cars' ? 'cars' : 'umrah_offices';
    // Soft delete
    const { error } = await supabase.from(table).update({ deleted_at: new Date().toISOString() }).eq('id', selectedItem.id);
    
    if (error) {
       toast({ variant: "destructive", title: "Error", description: error.message });
    } else {
       setData(data.filter(item => item.id !== selectedItem.id));
       toast({ title: "Deleted", description: "Item moved to trash." });
    }
    
    setDeleteDialogOpen(false);
    setSelectedItem(null);
  };

  const handleConfirmBlock = async () => {
      if (!selectedItem) return;
      let table = activeTab === 'restaurants' ? 'restaurants' : activeTab === 'umrah' ? 'umrah_offices' : 'users';
      
      if (activeTab === 'cars') {
          toast({ title: "Note", description: "Block the seller instead." });
          setBlockDialogOpen(false);
          return;
      }
      
      const newStatus = !selectedItem.is_blocked;
      const { error } = await supabase.from(table).update({ is_blocked: newStatus }).eq('id', selectedItem.id);
      
      if(!error) {
          setData(data.map(i => i.id === selectedItem.id ? { ...i, is_blocked: newStatus } : i));
          toast({ title: newStatus ? "Blocked" : "Unblocked", description: `Status updated.` });
      }
      setBlockDialogOpen(false);
  };

  const renderRestaurantTable = () => (
    <Table>
      <TableHeader>
        <TableRow><TableHead>Name</TableHead><TableHead>Visibility</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead></TableRow>
      </TableHeader>
      <TableBody>
        {data.map(r => (
          <TableRow key={r.id} className={r.is_blocked ? "bg-red-50" : ""}>
             <TableCell className="font-medium">{r.name}</TableCell>
             <TableCell>
                 <div className="flex items-center gap-2">
                     <Switch checked={r.is_online} onCheckedChange={() => handleToggleVisibility(r)} />
                     <span className="text-xs text-slate-500">{r.is_online ? 'Public' : 'Hidden'}</span>
                 </div>
             </TableCell>
             <TableCell>
                 <div className="flex gap-2">
                    {r.is_blocked && <Badge variant="destructive">BLOCKED</Badge>}
                    {!r.is_blocked && r.is_online && <Badge variant="outline" className="bg-emerald-50 text-emerald-600 border-emerald-200">Active</Badge>}
                 </div>
             </TableCell>
             <TableCell className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => handleAction(r, 'block')} className={r.is_blocked ? "text-green-600" : "text-amber-600"}>
                    {r.is_blocked ? <ShieldAlert className="w-4 h-4"/> : <Ban className="w-4 h-4"/>}
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handleAction(r, 'delete')}><Trash2 className="w-4 h-4 text-red-500"/></Button>
             </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );

  return (
    <div className="space-y-6">
       <div>
         <h2 className="text-2xl font-bold">Service Management</h2>
         <p className="text-slate-500">Manage listings visibility and status.</p>
       </div>

       <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
         <TabsList className="bg-white border w-full justify-start h-auto p-1">
            <TabsTrigger value="restaurants" className="gap-2 py-2 px-4"><Utensils className="w-4 h-4"/> Restaurants</TabsTrigger>
            <TabsTrigger value="umrah" className="gap-2 py-2 px-4"><Plane className="w-4 h-4"/> Umrah Offices</TabsTrigger>
            <TabsTrigger value="cars" className="gap-2 py-2 px-4"><Car className="w-4 h-4"/> Car Showroom</TabsTrigger>
         </TabsList>

         <div className="glass-card rounded-2xl overflow-hidden border">
           {loading ? <div className="p-8 text-center">Loading...</div> : (
              <TabsContent value="restaurants" className="m-0">{renderRestaurantTable()}</TabsContent>
           )}
           {/* Other tabs omitted for brevity but logic is similar */}
         </div>
       </Tabs>

       {/* Delete & Block Dialogs */}
       <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
         <DialogContent>
           <DialogHeader><DialogTitle>Confirm Delete</DialogTitle></DialogHeader>
           <p className="text-slate-600">Are you sure? This item will be moved to trash.</p>
           <DialogFooter>
             <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
             <Button variant="destructive" onClick={handleConfirmDelete}>Delete</Button>
           </DialogFooter>
         </DialogContent>
       </Dialog>
       
       <Dialog open={blockDialogOpen} onOpenChange={setBlockDialogOpen}>
         <DialogContent>
           <DialogHeader><DialogTitle>{selectedItem?.is_blocked ? "Unblock" : "Block"} Entity</DialogTitle></DialogHeader>
           <p className="text-slate-600">Confirm block status change for <strong>{selectedItem?.name}</strong>.</p>
           <DialogFooter>
             <Button variant="outline" onClick={() => setBlockDialogOpen(false)}>Cancel</Button>
             <Button variant={selectedItem?.is_blocked ? "default" : "destructive"} onClick={handleConfirmBlock}>
                 {selectedItem?.is_blocked ? "Confirm Unblock" : "Confirm Block"}
             </Button>
           </DialogFooter>
         </DialogContent>
       </Dialog>

       <CarListingDetailModal isOpen={isCarModalOpen} onClose={() => setIsCarModalOpen(false)} listing={selectedCar} mode="admin" />
    </div>
  );
};

export default AdminServices;
