
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, DollarSign, ShoppingCart, TrendingUp, Activity, AlertCircle } from 'lucide-react';
import { supabase } from '@/supabaseClient';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';

const StatCard = ({ title, value, description, icon: Icon, color }) => (
  <Card className="glass-card overflow-hidden">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <div className={`p-2 rounded-xl ${color}`}>
        <Icon className="h-4 w-4 text-white" />
      </div>
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      <p className="text-xs text-slate-500">{description}</p>
    </CardContent>
  </Card>
);

const AdminOverview = () => {
  const { t } = useTranslation();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalRevenue: 0,
    activeOrders: 0,
    pendingBookings: 0,
    restaurants: 0,
    umrahOffices: 0
  });

  useEffect(() => {
    fetchStats();
    
    // Real-time updates for orders
    const channel = supabase
      .channel('admin-overview')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => {
        fetchStats();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, []);

  const fetchStats = async () => {
    try {
      const { count: userCount } = await supabase.from('users').select('*', { count: 'exact', head: true });
      const { count: orderCount } = await supabase.from('orders').select('*', { count: 'exact', head: true }).eq('status', 'pending');
      const { count: bookingCount } = await supabase.from('umrah_bookings').select('*', { count: 'exact', head: true }).eq('status', 'pending');
      
      // Calculate revenue using total_price (which exists) or total_amount (newly added)
      // We select both to be safe
      const { data: orders } = await supabase.from('orders').select('total_price, total_amount').eq('status', 'delivered');
      
      const revenue = orders?.reduce((acc, curr) => {
        // Prefer total_amount if available, fallback to total_price
        const amount = curr.total_amount || curr.total_price || 0;
        return acc + amount;
      }, 0) || 0;

      setStats({
        totalUsers: userCount || 0,
        totalRevenue: revenue,
        activeOrders: orderCount || 0,
        pendingBookings: bookingCount || 0,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(amount);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title={t('total_revenue') || "Total Revenue"}
          value={formatCurrency(stats.totalRevenue)}
          description="+20.1% from last month"
          icon={DollarSign}
          color="bg-emerald-500"
        />
        <StatCard
          title={t('active_users') || "Total Users"}
          value={stats.totalUsers}
          description="+180 new users"
          icon={Users}
          color="bg-indigo-500"
        />
        <StatCard
          title={t('active_orders') || "Active Orders"}
          value={stats.activeOrders}
          description="Currently in progress"
          icon={ShoppingCart}
          color="bg-amber-500"
        />
        <StatCard
          title={t('pending_bookings') || "Pending Bookings"}
          value={stats.pendingBookings}
          description="Requires attention"
          icon={Activity}
          color="bg-rose-500"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4 glass-card">
          <CardHeader>
            <CardTitle>Revenue Overview</CardTitle>
            <p className="text-sm text-slate-500">Monthly revenue analysis</p>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[240px] flex items-end justify-between gap-2 p-4">
              {[35, 45, 30, 60, 75, 50, 65, 80, 70, 90, 85, 95].map((h, i) => (
                <div key={i} className="w-full bg-indigo-100 rounded-t-lg relative group transition-all duration-300 hover:bg-indigo-500">
                   <motion.div 
                     initial={{ height: 0 }}
                     animate={{ height: `${h}%` }}
                     transition={{ duration: 1, delay: i * 0.1 }}
                     className="absolute bottom-0 w-full bg-indigo-500 rounded-t-lg group-hover:bg-indigo-600"
                   />
                </div>
              ))}
            </div>
            <div className="flex justify-between text-xs text-slate-400 px-4 mt-2">
              <span>Jan</span><span>Jun</span><span>Dec</span>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3 glass-card">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <p className="text-sm text-slate-500">Latest system events</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { text: "New restaurant registered: 'Baghdad Grill'", time: "2m ago", type: "success" },
                { text: "System backup completed successfully", time: "1h ago", type: "info" },
                { text: "High server load detected", time: "3h ago", type: "warning" },
                { text: "New admin user added", time: "5h ago", type: "info" }
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4 border-b pb-3 last:border-0 last:pb-0">
                  <span className={`w-2 h-2 rounded-full ${
                    item.type === 'success' ? 'bg-emerald-500' : 
                    item.type === 'warning' ? 'bg-amber-500' : 'bg-blue-500'
                  }`} />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">{item.text}</p>
                    <p className="text-xs text-slate-500">{item.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="glass-card bg-gradient-to-br from-indigo-600 to-indigo-700 text-white border-0">
          <CardHeader>
            <CardTitle className="text-white">System Health</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-full backdrop-blur-md">
              <Activity className="w-8 h-8" />
            </div>
            <div>
              <div className="text-2xl font-bold">98.9%</div>
              <p className="text-indigo-100 text-sm">Operational</p>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
             <CardTitle>Top Restaurant</CardTitle>
          </CardHeader>
          <CardContent>
             <div className="flex items-center justify-between">
                <span className="font-bold">Al-Fawires Grill</span>
                <span className="text-emerald-600 font-bold">4.9 ★</span>
             </div>
             <p className="text-sm text-slate-500 mt-1">1,240 Orders this month</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
             <CardTitle>Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent>
             <div className="flex items-center justify-between">
                <span className="font-bold">New Vendors</span>
                <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded text-xs font-bold">5 Pending</span>
             </div>
             <p className="text-sm text-slate-500 mt-1">Requires review</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminOverview;
