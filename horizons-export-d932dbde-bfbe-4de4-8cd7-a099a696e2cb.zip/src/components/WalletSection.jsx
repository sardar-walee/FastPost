
import React, { useState, useEffect } from 'react';
import { Wallet, ArrowUpRight, ArrowDownLeft, RefreshCw, History } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/supabaseClient';

const WalletSection = ({ entityId, entityType }) => {
  const { toast } = useToast();
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [isTransferring, setIsTransferring] = useState(false);
  const [transferData, setTransferData] = useState({ receiverId: '', amount: '', description: '' });

  useEffect(() => {
    if (entityId) {
      fetchWalletData();
    }
  }, [entityId]);

  const fetchWalletData = async () => {
    // Fetch Balance
    const table = entityType === 'restaurant' ? 'restaurants' : 'users';
    const { data: entityData } = await supabase
      .from(table)
      .select('wallet_balance')
      .eq('id', entityId)
      .single();
    
    if (entityData) setBalance(entityData.wallet_balance || 0);

    // Fetch Transactions
    const { data: txData } = await supabase
      .from('wallet_transactions')
      .select('*')
      .or(`sender_id.eq.${entityId},receiver_id.eq.${entityId}`)
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (txData) setTransactions(txData);
  };

  const handleTransfer = async () => {
    if (!transferData.amount || !transferData.receiverId) {
       toast({ variant: "destructive", title: "Missing Fields", description: "Please fill all fields." });
       return;
    }

    try {
      // In a real app, we'd need to validate receiver exists and get their type.
      // For simplicity, we assume receiver is always a USER for now unless specified.
      // Or we can try to find them in users first.
      
      let receiverType = 'user';
      // Simple check (in production this logic needs to be more robust)
      const { data: userCheck } = await supabase.from('users').select('id').eq('id', transferData.receiverId).single();
      if (!userCheck) {
         // Try restaurant
         const { data: restCheck } = await supabase.from('restaurants').select('id').eq('id', transferData.receiverId).single();
         if (restCheck) receiverType = 'restaurant';
         else throw new Error("Receiver ID not found");
      }

      const { error } = await supabase.rpc('transfer_funds', {
        p_sender_id: entityId,
        p_sender_type: entityType,
        p_receiver_id: transferData.receiverId,
        p_receiver_type: receiverType,
        p_amount: parseFloat(transferData.amount),
        p_description: transferData.description || 'Transfer',
        p_type: 'payment'
      });

      if (error) throw error;

      toast({ title: "Transfer Successful", description: `Sent ${transferData.amount} IQD` });
      setIsTransferring(false);
      setTransferData({ receiverId: '', amount: '', description: '' });
      fetchWalletData();
    } catch (error) {
      toast({ variant: "destructive", title: "Transfer Failed", description: error.message });
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-IQ', { style: 'currency', currency: 'IQD', maximumFractionDigits: 0 }).format(price);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-slate-900 to-slate-800 text-white border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
             <div className="flex items-center gap-2 text-slate-300">
                <Wallet className="w-5 h-5" />
                <span className="font-medium">Total Balance</span>
             </div>
             <Button variant="ghost" size="icon" className="text-slate-300 hover:text-white hover:bg-slate-700" onClick={fetchWalletData}>
                <RefreshCw className="w-4 h-4" />
             </Button>
          </div>
          <h2 className="text-4xl font-bold mb-2">{formatPrice(balance)}</h2>
          <div className="flex gap-3 mt-6">
             <Dialog open={isTransferring} onOpenChange={setIsTransferring}>
                <DialogTrigger asChild>
                   <Button className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white border-0 gap-2">
                      <ArrowUpRight className="w-4 h-4" /> Send
                   </Button>
                </DialogTrigger>
                <DialogContent>
                   <DialogHeader><DialogTitle>Transfer Funds</DialogTitle></DialogHeader>
                   <div className="space-y-4 py-4">
                      <div className="space-y-2">
                         <Label>Receiver ID (User/Restaurant UUID)</Label>
                         <Input value={transferData.receiverId} onChange={e => setTransferData({...transferData, receiverId: e.target.value})} placeholder="e.g. 550e8400-e29b..." />
                      </div>
                      <div className="space-y-2">
                         <Label>Amount (IQD)</Label>
                         <Input type="number" value={transferData.amount} onChange={e => setTransferData({...transferData, amount: e.target.value})} placeholder="0.00" />
                      </div>
                      <div className="space-y-2">
                         <Label>Description</Label>
                         <Input value={transferData.description} onChange={e => setTransferData({...transferData, description: e.target.value})} placeholder="Reason for transfer" />
                      </div>
                      <Button onClick={handleTransfer} className="w-full bg-emerald-600 hover:bg-emerald-700">Confirm Transfer</Button>
                   </div>
                </DialogContent>
             </Dialog>
             <Button variant="outline" className="flex-1 bg-white/10 text-white border-white/20 hover:bg-white/20 gap-2">
                <ArrowDownLeft className="w-4 h-4" /> Request
             </Button>
          </div>
        </CardContent>
      </Card>

      <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
         <div className="p-4 border-b bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-800 flex items-center gap-2"><History className="w-4 h-4" /> Recent Transactions</h3>
         </div>
         <div className="divide-y max-h-[400px] overflow-y-auto">
            {transactions.map(tx => {
               const isCredit = tx.receiver_id === entityId;
               return (
                  <div key={tx.id} className="p-4 flex justify-between items-center hover:bg-slate-50 transition-colors">
                     <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isCredit ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                           {isCredit ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                        </div>
                        <div>
                           <p className="font-medium text-slate-900">{isCredit ? 'Received' : 'Sent'} {tx.transaction_type}</p>
                           <p className="text-xs text-slate-500">{new Date(tx.created_at).toLocaleDateString()} • {tx.description}</p>
                        </div>
                     </div>
                     <span className={`font-bold ${isCredit ? 'text-green-600' : 'text-slate-900'}`}>
                        {isCredit ? '+' : '-'}{formatPrice(tx.amount)}
                     </span>
                  </div>
               );
            })}
            {transactions.length === 0 && <p className="p-6 text-center text-slate-500 text-sm">No transactions found.</p>}
         </div>
      </div>
    </div>
  );
};

export default WalletSection;
