
import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const handleSession = useCallback(async (currentSession) => {
    setSession(currentSession);
    setUser(currentSession?.user ?? null);
    setLoading(false);
  }, []);

  useEffect(() => {
    const getSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;
        handleSession(session);
      } catch (error) {
        if (error.message?.includes("Refresh Token Not Found") || error.code === "refresh_token_not_found") {
            await supabase.auth.signOut();
            handleSession(null);
        } else {
            handleSession(null);
        }
      }
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_OUT') {
            setUser(null);
            setSession(null);
            localStorage.removeItem('fastpost-cart');
            localStorage.removeItem('fastpost-location');
        } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
            handleSession(session);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, [handleSession]);

  const signUp = useCallback(async (email, password, options) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options,
      });
      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Registration Failed",
        description: error.message || "Could not create account.",
      });
      return { data: null, error };
    }
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      let description = error.message;
      let title = "Login Failed";
      let variant = "destructive";

      if (error.message?.includes("Email not confirmed") || error.code === "email_not_confirmed") {
          title = "Email Verification Required";
          description = "Please verify your email address before logging in.";
          variant = "default";
      } else if (error.message?.includes("Invalid login credentials")) {
          description = "Incorrect email or password.";
      }

      toast({
        variant: variant,
        title: title,
        description: description,
      });
      return { data: null, error };
    }
  }, [toast]);

  const signOut = useCallback(async () => {
    try {
      // 1. Attempt Supabase SignOut
      const { error } = await supabase.auth.signOut();
      if (error) console.error("Supabase signout error (non-fatal):", error);
      
      // 2. Clear Local State immediately regardless of API result
      setSession(null);
      setUser(null);

      // 3. Clear Local Storage
      localStorage.removeItem('fastpost-cart');
      localStorage.removeItem('fastpost-location');
      localStorage.removeItem('supabase.auth.token'); // Clean up persistence if any
      
      toast({
        title: "Signed Out",
        description: "See you next time!",
      });
      
      // 4. Force reload to clear any in-memory states (optional but safer)
      // window.location.href = '/'; 
      
    } catch (error) {
      console.error("Logout critical error:", error);
      // Fallback cleanup
      setSession(null);
      setUser(null);
    }
  }, [toast]);

  const value = useMemo(() => ({
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
  }), [user, session, loading, signUp, signIn, signOut]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
