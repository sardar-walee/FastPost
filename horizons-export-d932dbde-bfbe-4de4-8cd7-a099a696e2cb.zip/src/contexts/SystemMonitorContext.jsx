
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '@/supabaseClient';
import { analyzeError, checkPerformance, checkSecurity } from '@/lib/aiAnalysisEngine';
import { useToast } from '@/components/ui/use-toast';

const SystemMonitorContext = createContext(undefined);

export const SystemMonitorProvider = ({ children }) => {
  const { toast } = useToast();
  const [logs, setLogs] = useState([]);
  const [metrics, setMetrics] = useState({ lcp: 0, cls: 0, fid: 0 });
  const [healthScore, setHealthScore] = useState(100);
  const [activeIssues, setActiveIssues] = useState(0);

  // --- Logging Mechanism ---
  const logError = useCallback(async (error, context = {}) => {
    const analysis = analyzeError(error, context);
    
    const newLog = {
      id: crypto.randomUUID(),
      message: analysis.originalError,
      category: analysis.category,
      severity: analysis.severity,
      ai_analysis: JSON.stringify({ analysis: analysis.analysis, suggestion: analysis.suggestion }),
      stack_trace: error.stack,
      created_at: new Date().toISOString(),
      resolved: false
    };

    setLogs(prev => [newLog, ...prev]);
    setActiveIssues(prev => prev + 1);
    setHealthScore(prev => Math.max(0, prev - (analysis.severity === 'critical' ? 20 : 5)));

    // Persist to DB (Fire and forget)
    try {
      await supabase.from('system_logs').insert({
        severity: newLog.severity,
        category: newLog.category,
        message: newLog.message,
        stack_trace: newLog.stack_trace,
        ai_analysis: newLog.ai_analysis,
        metadata: context
      });
    } catch (err) {
      console.error("Failed to log to DB:", err);
    }

    // Show Dev Toast if critical
    if (analysis.severity === 'critical') {
      console.error("CRITICAL SYSTEM ERROR:", analysis);
    }
  }, []);

  // --- Global Error Listeners ---
  useEffect(() => {
    const handleError = (event) => {
      logError(event.error || new Error(event.message), { type: 'uncaught_exception', source: event.filename });
    };

    const handleRejection = (event) => {
      logError(event.reason || new Error('Unhandled Promise Rejection'), { type: 'unhandled_rejection' });
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleRejection);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleRejection);
    };
  }, [logError]);

  // --- Performance Observer ---
  useEffect(() => {
    if (typeof PerformanceObserver === 'undefined') return;

    const observer = new PerformanceObserver((entryList) => {
      for (const entry of entryList.getEntries()) {
        if (entry.entryType === 'largest-contentful-paint') {
          setMetrics(prev => ({ ...prev, lcp: entry.startTime }));
        }
        if (entry.entryType === 'layout-shift') {
          setMetrics(prev => ({ ...prev, cls: prev.cls + entry.value }));
        }
      }
    });

    observer.observe({ type: 'largest-contentful-paint', buffered: true });
    observer.observe({ type: 'layout-shift', buffered: true });

    return () => observer.disconnect();
  }, []);

  // --- Periodic Health Check (Simulated "AI" Monitoring) ---
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Check Security
      const secIssues = checkSecurity();
      if (secIssues.length > 0) {
        secIssues.forEach(issue => {
             // Avoid duplicate logging logic here for simplicity in this demo
        });
      }

      // 2. Check Performance Thresholds
      const perfIssues = checkPerformance(metrics);
      if (perfIssues.length > 0) {
        // Log performance warnings if health is high (to avoid spamming)
        if (healthScore > 80) setHealthScore(h => h - 2);
      }

    }, 30000); // Check every 30s

    return () => clearInterval(interval);
  }, [metrics, healthScore]);

  // --- Auto-Fix Actions ---
  const applyFix = async (logId, actionType) => {
    const log = logs.find(l => l.id === logId);
    if (!log) return;

    let success = false;
    let message = '';

    switch (actionType) {
      case 'clear_cache':
        localStorage.clear();
        sessionStorage.clear();
        message = 'Cache cleared. Reloading recommended.';
        success = true;
        break;
      case 'reload':
        window.location.reload();
        break;
      case 'resolve':
        success = true;
        message = 'Issue marked as resolved.';
        break;
      default:
        message = 'Fix action not implemented for this type.';
    }

    if (success) {
      // Update Local State
      setLogs(prev => prev.map(l => l.id === logId ? { ...l, resolved: true } : l));
      setActiveIssues(prev => Math.max(0, prev - 1));
      setHealthScore(prev => Math.min(100, prev + 5));
      
      // Update DB
      await supabase.from('system_logs').update({ resolved: true }).eq('id', logId); // Assuming we map back to real DB ID if needed
      
      toast({ title: "Fix Applied", description: message });
    }
  };

  return (
    <SystemMonitorContext.Provider value={{ logs, metrics, healthScore, activeIssues, applyFix, logError }}>
      {children}
    </SystemMonitorContext.Provider>
  );
};

export const useSystemMonitor = () => {
  const context = useContext(SystemMonitorContext);
  if (context === undefined) {
    throw new Error('useSystemMonitor must be used within a SystemMonitorProvider');
  }
  return context;
};
